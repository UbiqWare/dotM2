package org.aspect.grails.services

import grails.transaction.Transactional
import org.aspect.grails.entities.User
import org.aspect.grails.services.AspectBaseService;

@Transactional
class AspectConfigService extends AspectBaseService {

}
