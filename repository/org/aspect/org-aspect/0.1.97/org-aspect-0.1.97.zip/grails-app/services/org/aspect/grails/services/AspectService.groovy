package org.aspect.grails.services

import grails.transaction.Transactional

@Transactional
class AspectService extends AspectBaseService {

	static scope = "request"

	List<String> aspects = []

	def setAspects(List<String> aspectsList) {
		aspects = aspectsList
		innerAspects = aspectEngine.buildInnerAspectsMap(aspects)
	}

}
