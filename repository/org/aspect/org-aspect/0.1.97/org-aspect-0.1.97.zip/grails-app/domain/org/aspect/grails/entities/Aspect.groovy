package org.aspect.grails.entities

import org.aspect.grails.annotations.AspectType;
import org.aspect.model.*;

@AspectType
class Aspect extends Entity {
	String detailAspectClassName
	String left
	String right
	Boolean isDefault = false
	String filter = ""
	String aggregateOf = ""
	
	String localName() {
		int dotOffset = detailAspectClassName.lastIndexOf('.') + 1
		(dotOffset > detailAspectClassName.size()) ? "" : detailAspectClassName.substring(dotOffset)
	}
	
	static constraints = {
		detailAspectClassName  	size:1..512, blank:false, nullable:false
		left  					size:1..128, blank:false, nullable:false
		right  					size:1..128, blank:false, nullable:false
		isDefault				nullable:false
		filter  				size:1..512, blank:true, nullable:true
		aggregateOf 			size:1..512, blank:true, nullable:true
	}
	
	static mapping = {
		tablePerHierarchy 	false
		left 				column:'left_id'
		right 				column:'right_id'
	}
	
	static aspectss = [
		security:null
		, relationship:null
	]
	
	static transients = ['aspectss']
}