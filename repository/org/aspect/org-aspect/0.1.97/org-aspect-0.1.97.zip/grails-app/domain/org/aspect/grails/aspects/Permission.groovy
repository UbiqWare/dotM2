package org.aspect.grails.aspects

import org.aspect.grails.annotations.Aspect;

/*
 * If exist an instance of this domain class for a user, it indicates this user has read permission
 */
@Aspect(isDefault=true, left="entityId", right="permissionEntityId", filter='((@permissionEntityId = $userId) || (@permissionEntityId = 0 && @entityId = $userId))')
class Permission extends org.aspect.core.entities.Aspect {
	
	Long     entityId
	Long     permissionEntityId
	Long     permissions = 0
	Long     permissionsMask = 0
	Long     inheritedPermissions = 0
	
	// Indicates if the user is one of the owners or not for every entity
	Boolean owner = false
	
	// Property provided for massive operations over permission aspect
	Long	permissionStatus
	
	Long efectivePermissions() {
		calculateEfectivePermissions(this)
	}
	
	static calculateEfectivePermissions(def permission) {
		(permission.permissions & permission.permissionsMask) | (permission.inheritedPermissions & ~permission.permissionsMask)
	}
	
    static constraints = {
		dateCreated 				nullable:true
		lastUpdated 				nullable:true
		createdBy 					nullable:true
		updatedBy 					nullable:true
		entityId 					nullable:false
		permissionEntityId			nullable:true
		permissionsMask				nullable:false
		permissionsMask				nullable:false
		inheritedPermissions		nullable:false
		owner						nullable:false
		permissionStatus			nullable:true
    }
	
	static mapping = {
		entityId			index:"permission_entityId_idx"
		permissionEntityId	index:"entity_permissionEntityId_idx"
		permissionStatus	index:"permission_status_idx"
	}

	
	
	/* permissionMask MAP
	 * Long <-> 64 bits
	 * Bit 1 -> Writer
	 * Bit 2 -> Executor
	 * Bit 3 -> Link children allowed
	 * Bit 4 -> Link parent allowed
	 *
	 * Candidates
	 * -> Content reader
	 * -> Content writer
	 * 
	 * Notes
	 * - Read permission is not needed. It's implicit if the domain class instance already exists
	 * - "Owner" permission, as it would be "Read permision" if it wasn't implicit, is a property for optimazing commom queries where it's involved
	 */

}
