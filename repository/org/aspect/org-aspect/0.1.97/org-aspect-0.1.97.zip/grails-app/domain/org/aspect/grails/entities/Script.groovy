package org.aspect.grails.entities

import org.aspect.grails.annotations.AspectType;

@AspectType
class Script extends Operation {

	String script
	
    static constraints = {
		script			nullable:false
    }
	
	static mapping = {
		tablePerHierarchy 	false
		script 			type:'text'
	}
}
