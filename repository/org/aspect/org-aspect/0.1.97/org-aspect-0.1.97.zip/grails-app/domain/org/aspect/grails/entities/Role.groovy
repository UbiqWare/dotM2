package org.aspect.grails.entities

import org.aspect.grails.annotations.AspectType;
import org.aspect.model.*

@AspectType
class Role extends Entity {
	Boolean propagatesPermission
	Long sequence = 0

	static constraints = {
		propagatesPermission 	nullable:false
	}
	
	static mapping = {
		tablePerHierarchy false
		sequence defaultValue:0
	}
}
