package org.aspect.grails.entities

import org.aspect.grails.annotations.AspectType;
import groovy.json.JsonBuilder
import groovy.json.JsonSlurper

public enum LTOperationStatus {
	READY					(0001)
	//, READY_SUSPENDED		(0002)
	//, BLOCKED				(1000)
	//, BLOCKED_SUSPENDED	(1001)
	, RUNNING				(2000)
	, FINISHED				(3000)
	, FINISHED_WITH_ERROR	(3001)
	//, INTERRUPTED			(8000)
	
	private final int v
	
	int value() { return v }
	
	public LTOperationStatus(int v) {
		this.v = v
	}
}

@AspectType
class LongTermOperation extends Entity {
	
	String 		args			= null
	String 		context			= null
	String 		result			= null
	Long 		status			= LTOperationStatus.READY.value()
	Operation 	operation		= null
	Long		operationId		= null
	Interpreter interpreter		= null
	Long		interpreterId	= null

	//static transients = ['entities', 'aspects', 'addToCache', 'liveArgs', 'liveContext']

	def static serialize(def o) {
		def r = new JsonBuilder(o).toString()
	}	
	
	def static deserialize(String s) {
		def r = new JsonSlurper().parseText(s)
	}
	
    static constraints = {
		args		 		nullable:true
		context		 		nullable:true
		result		 		nullable:true
		status 				nullable:false 
		operation			nullable:false
		operationId			nullable:true
		interpreter			nullable:true
		interpreterId		nullable:true
    }
	
	static mapping = {
		tablePerHierarchy 	false
		version 			true
		args 				type:'text'
		context				type:'text'
		result				type:'text'
		status				defaultValue:LTOperationStatus.READY.value()
		operation			column:'operation_id'
		operationId			column:'operation_id', insertable:false, updateable:false
		interpreter			column:'interpreter_id'
		interpreterId		column:'interpreter_id', insertable:false, updateable:false
	}

}
