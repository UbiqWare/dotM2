package org.aspect.grails.aspects
//
import org.aspect.grails.annotations.Aspect;

//
@Aspect(left="contentId")
class ContentData extends org.aspect.core.entities.Aspect {
	
	Long 	contentId
	byte[] 	data

    static constraints = {
		dateCreated 			nullable:true
		lastUpdated 			nullable:true
		createdBy 				nullable:true
		updatedBy 				nullable:true
		contentId 				nullable:false
		data					nullable:true
    }
	
	static mapping = {
		contentId			index:"security_entityId_idx"
		//// TODO check if this restriction should be set by configuration
		//data				maxSize:128 * 1024 * 1024
	}
}
