package org.aspect.grails.aspects
//
import org.aspect.grails.annotations.Aspect;
import org.aspect.grails.entities.Role;
import org.aspect.model.*;
//
public enum LinearizedDigraphStatus {
	DONE(1)
	, INPROGRESS(2)
	private final int v
	int value() { return v }
	public LinearizedDigraphStatus(int v) {
		this.v = v
	}
}
//
@Aspect(isDefault=false, left="graphId", right="childId")
class LinearizedDigraph extends org.aspect.core.entities.Aspect {
	
	Long graphId 		= 0
	Long childId
	Long parentId
	Long rootId
	Long ancestorId
	Long status 		= LinearizedDigraphStatus.DONE.value()
	
    static constraints = {
		dateCreated nullable:true
		lastUpdated nullable:true
		createdBy 	nullable:true
		updatedBy 	nullable:true
		graphId		nullable:true
		rootId		nullable:false
		parentId 	nullable:true
		childId 	nullable:false
		ancestorId 	nullable:true
		status 		nullable:true, defaultValue:LinearizedDigraphStatus.DONE.value()
    }
	
	static mapping = {
		graphId		index:"digraph_graph_id_idx", unique:false
		rootId		index:"digraph_root_id_idx", unique:false
		parentId	index:"digraph_parent_id_idx", unique:false
		childId		index:"digraph_child_id_idx", unique:false
		ancestorId	index:"digraph_ancestor_id_idx", unique:false
	}
}
