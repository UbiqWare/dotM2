package org.aspect.grails.entities

import org.aspect.grails.annotations.AspectType;
import org.aspect.model.*;

@AspectType
class Property extends Entity {

    static constraints = {
    }
}
