package org.aspect.grails.entities

import org.aspect.grails.annotations.AspectType;

@AspectType
class User extends Entity {
	
	String username
	String password
	String groups	// List of group ids. Small cache

	static constraints = {
		username blank:false, unique:true
		password blank:false
		groups nullable:true
	}
	
	static mapping = {
		tablePerHierarchy 	false
		version false
		password column:'password'
	}
	
	String groupsForInList() {
		// Just for assuring in string is well formed for aql in function 
		"${this?.groups ?: ''}${id}"
	}
}
