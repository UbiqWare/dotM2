package org.aspect.grails.entities

import org.aspect.grails.annotations.AspectType;

// TODO Process definition should provides hooks for suspend, resume , ... operations in order to allow process execution beyond just one single LTO

@AspectType
class Process extends Operation {

	// TODO Look at -> http://docs.groovy-lang.org/latest/html/documentation/template-engines.html
	// Both, signature and args belong to binding
	String 		definition		=	"" //'process { execute signature:signature, args:args }'

    static constraints = {
		definition 			nullable:false, blank:false
    }
	
	static mapping = {
		tablePerHierarchy 	false
		version 			false
		definition 			type:'text'
	}

}
