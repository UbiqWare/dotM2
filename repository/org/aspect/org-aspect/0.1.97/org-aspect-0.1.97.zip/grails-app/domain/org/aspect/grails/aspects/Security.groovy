package org.aspect.grails.aspects

import org.aspect.grails.annotations.Aspect;
import org.aspect.model.*; 

public enum SecurityProcessStatus {
	DONE(1)
	, INPROGRESS(2)
	, PENDING(3)
	
	private final int v
	
	int value() { return v }
	
	public SecurityProcessStatus(int v) {
		this.v = v
	}
}


@Aspect(isDefault=true, left="entityId")
class Security extends org.aspect.core.entities.Aspect {

	Long		entityId
	Boolean     inheritsPermission = false
	Boolean     propagatesPermission = false
	
	String		securityProcessId
	Long	 	securityProcessStatus = SecurityProcessStatus.DONE.value()
	
    static constraints = {
		dateCreated 			nullable:true
		lastUpdated 			nullable:true
		createdBy 				nullable:true
		updatedBy 				nullable:true
		
		inheritsPermission 		nullable:false
		propagatesPermission 	nullable:false
		securityProcessId		nullable:true, maxSize:64
		securityProcessStatus 	nullable:true, defaultValue:SecurityProcessStatus.DONE.value()
    }
	
	static mapping = {
	}

}
