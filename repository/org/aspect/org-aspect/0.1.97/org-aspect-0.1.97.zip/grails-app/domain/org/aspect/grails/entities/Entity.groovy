package org.aspect.grails.entities

import org.aspect.grails.annotations.AspectType;
import org.aspect.grails.entities.Type;
import org.aspect.grails.helpers.ClassName;

@AspectType(entityBase = true)
class Entity extends org.aspect.core.entities.Entity {
	String 	name
	String	hash =  null
	String	description = "default description"
	Type 	type = Type.types[ClassName.conventionMemberName(this.class.simpleName)]
	Long 	typeId
	
	static transients = ['entities', 'aspects', 'addToCache']
	
	static constraints = {
		dateCreated 		nullable:true
		lastUpdated 		nullable:true
		createdBy 			nullable:true
		updatedBy 			nullable:true
		name 				size:1..512, blank:false
		hash 				nullable:true
		description 		size:1..512, blank:false
		type 				nullable:true
		typeId 				nullable:true
	}
	
	static mapping = {
		tablePerHierarchy 	false
		version false
		type 				column:'type_id', index:"entity_typeId_idx", unique:false
		typeId 				column:'type_id', insertable:false, updateable:false
		name				index:"entity_name_idx"
		description			index:"entity_description_idx", unique:false
		dateCreated			index:"entity_dateCreated_idx", unique:false
		lastUpdated			index:"entity_lastUpdated_idx", unique:false
		createdBy			index:"entity_createdBy_idx", unique:false
		updatedBy			index:"entity_updatedBy_idx", unique:false
		hash				index:"entity_hash_idx", unique:false, size:0..64, blank:true, nullable:true
	}
	
	//
	def propertyMissing(String name, value) {
		if (aspects.containsKey(name)) {
			aspects[name] = value
		} else {
			throw new RuntimeException("Property ${name} not found in class ${this.class.name}")
		}
	}
	//
	def propertyMissing(String name) {
		if (aspects.containsKey(name)) {
			aspects[name]
		} else {
			throw new RuntimeException("Property ${name} not found in class ${this.class.name}")
		}
	}

	// Executed before an object is initially persisted to the database
	//def beforeInsert() {}
	
	// Executed before an object is updated
	//def beforeUpdate() {}
	
	// Executed before an object is deleted
	//def beforeDelete() {}
	
	// Executed before an object is validated
	//def beforeValidate() {}
	
	// Executed after an object is persisted to the database
	//def afterInsert() {} 
	
	// Executed after an object has been updated
	//def afterUpdate() {}
	
	// Executed after an object has been deleted
	//def afterDelete() {} 
	
	// Executed when an object is loaded from the database
	//def onLoad() {}
}

