package org.aspect.grails.entities

import org.aspect.grails.annotations.AspectType;
import org.aspect.grails.entities.Entity;

@AspectType(typeBase = true)
class Type extends Entity {
	
	String 	localName
	String 	localNamespace

	static constraints = {
		localNamespace 	nullable:false
		localName 		nullable:false
	}
	
	static mapping = {
		tablePerHierarchy false
		version false
	}

	static types = [
		base:null			// Base/root type. It has null in its type field
		, entity:null		// Entity type. First type
		, aspect:null		// Aspect type
		, operation:null	// Operation type
		, interpreter:null  // Interpreter type
		, script:null		// Script type
	]

	static transients = ['types']
	
	Boolean isBaseType() {
		this.name == types.base.name
	}
	
	String localFullName() {
		"${localNamespace}.${localName}"
	}

}