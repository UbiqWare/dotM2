package org.aspect.grails.aspects
//
import org.aspect.grails.annotations.Aspect
import org.aspect.grails.annotations.AspectProperty

@Aspect(aggregateOf='permission', left="entityId", filter='@permissionEntityId = $userId || in(@permissionEntityId, $userGroups)')
class Rights extends org.aspect.core.entities.Aspect {
	@AspectProperty(expression='@entityId')
	Long entityId

	@AspectProperty(expression='bitOr(@permissions & @permissionsMask)')
	Long permissions

	@AspectProperty(expression='sum(if(@permissionEntityId = $userId, @permissions, 0))')
	Long explicitPermissions

	@AspectProperty(expression='sum(@owner)')
	Boolean owner
}
