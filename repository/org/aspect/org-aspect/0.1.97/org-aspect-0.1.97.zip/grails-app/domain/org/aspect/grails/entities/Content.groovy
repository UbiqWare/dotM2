package org.aspect.grails.entities
import org.aspect.grails.annotations.AspectType;

public enum ContentStatus { 
	STABLE(1)
	, INPROGRESS(2)
	
	private final int v
	
	int value() { return v }
	
	public ContentStatus(int v) {
		this.v = v
	}
}

@AspectType
class Content extends Entity {
	String 				externalId
	Long 				size = 0
	Long 				status = ContentStatus.STABLE.value()
	
	ContentRepository 	contentRepository
	Long 				contentRepositoryId

    static constraints = {
		externalId 			size:0..512, blank:true, nullable:true
		contentRepository 	nullable:false
		contentRepositoryId	nullable:true
		status 				nullable:false 
    }
	
	static mapping = {
		size				defaultValue:0
		contentRepository	column:'content_repository_id'
		contentRepositoryId	column:'content_repository_id', insertable:false, updateable:false
		status				defaultValue:ContentStatus.STABLE.value()
	}
}


