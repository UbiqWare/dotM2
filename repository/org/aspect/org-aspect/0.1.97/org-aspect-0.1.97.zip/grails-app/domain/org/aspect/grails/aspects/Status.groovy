package org.aspect.grails.aspects

import org.aspect.grails.annotations.Aspect;
import org.aspect.model.*; 

public enum StatusEnum {
	CREATED(1)
	, DELETED(2)
	
	private final long v
	
	long value() { return v }
	
	public StatusEnum(long v) {
		this.v = v
	}
}


@Aspect(isDefault=true, left="entityId", filter='@status = $status')
class Status extends org.aspect.core.entities.Aspect {

	Long		entityId
	Long		status 		= StatusEnum.CREATED.value()
	
    static constraints = {
		dateCreated 			nullable:true
		lastUpdated 			nullable:true
		createdBy 				nullable:true
		updatedBy 				nullable:true
		
		status 					nullable:true, defaultValue:StatusEnum.CREATED.value()
    }
	
	static mapping = {
	}

}
