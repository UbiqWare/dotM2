package org.aspect.grails.aspects

import org.aspect.grails.annotations.Aspect;
import org.aspect.grails.entities.Role;
import org.aspect.model.*; 

@Aspect(isDefault=false, left="parentId", right="childId")
class Relationship extends org.aspect.core.entities.Aspect {
	Long parentId
	Long childId
	Role role
	Long roleId
	
    static constraints = {
		dateCreated nullable:true
		lastUpdated nullable:true
		createdBy 	nullable:true
		updatedBy 	nullable:true
		parentId 	nullable:false
		childId		nullable:false
		role		nullable:true
		roleId		nullable:true
    }
	
	static mapping = {
		role 		column:'role_id', index:"relationship_roleId_idx", unique:false
		roleId 		column:'role_id', insertable:false, updateable:false
		parentId	index:"relationship_parentId_idx", unique:false
		childId		index:"relationship_childId_idx", unique:false
	}

}
