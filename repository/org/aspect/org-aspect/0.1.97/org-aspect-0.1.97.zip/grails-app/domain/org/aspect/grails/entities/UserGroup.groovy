package org.aspect.grails.entities

import org.aspect.grails.annotations.AspectType;

@AspectType
class UserGroup extends Entity {

	String groupname
	String groups	// List of group ids. Small cache

	static constraints = {
		groupname blank:false, unique:true
		groups nullable:true
    }
	
	static mapping = {
		tablePerHierarchy 	false
		version false
	}
	
	String groupsForInList() {
		// Just for assuring in string is well formed for aql in function
		"${this?.groups ?: ''}${id}"
	}

}
