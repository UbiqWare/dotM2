package org.aspect.grails.entities

import org.aspect.grails.annotations.AspectType;

@AspectType
class ContentRepository extends Interpreter {
	
	String repositoryId
	String tempRepositoryId
	String versionRepositoryId 	// Adding when versioning was included in Aspects. Ut's the repo where versions will be stored. It could be "" indicating that
								// versions will be save in the same directory as the active version one
	String credentials
	Long blockSize

    static constraints = {
		repositoryId		size:0..512, blank:true, nullable:true
		tempRepositoryId	size:0..512, blank:true, nullable:true
		versionRepositoryId	size:0..512, blank:true, nullable:true
		credentials			size:0..512, blank:true, nullable:true
		blockSize			nullable:false
    }
	
	static mapping = {
		repositoryId		defaultValue:null
		tempRepositoryId	defaultValue:null
		versionRepositoryId	defaultValue:null
		blockSize			defaultValue: 4 * 1024 * 1024
	}
}
