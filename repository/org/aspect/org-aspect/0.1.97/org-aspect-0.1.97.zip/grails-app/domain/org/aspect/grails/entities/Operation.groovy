package org.aspect.grails.entities

import org.aspect.grails.annotations.AspectType;
import org.aspect.model.*

@AspectType
class Operation extends Entity {
	String 			localNamespace = "."
	String 			localName = "."
	String 			signature = java.util.UUID.randomUUID() as String
	String 			argsSignature = "{}"
	String 			defaultArgs = "{}"
	Boolean 		active = true
	Boolean 		deprecated = false
	Interpreter 	interpreter
	Long 			interpreterId
	String 			innerAspects = "false"
	String 			groups = "none"

	static constraints = {
		localNamespace	nullable:false, size:1..512
		localName		nullable:false, size:1..512
		signature		nullable:false, size:1..512
		interpreter		nullable:true
		interpreterId	nullable:true
 		argsSignature	nullable:false
		defaultArgs		nullable:false
		active			nullable:false
		deprecated		nullable:false
		innerAspects 	nullable:false
		groups 			nullable:false
   }
	
	static mapping = {
		tablePerHierarchy 	false
		interpreter			column:'interpreter_id'
		interpreterId		column:'interpreter_id', insertable:false, updateable:false
		signature			index:"entity_signature_idx", unique:true
		active				defaultValue:true
		deprecated			defaultValue:false
	}
	
	String localFullName() {
		"${localNamespace}.${localName}"
	}

}
