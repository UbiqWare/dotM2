package org.aspect

import static org.springframework.http.HttpStatus.*

import org.codehaus.groovy.grails.web.servlet.HttpHeaders
import org.springframework.http.HttpStatus

import grails.artefact.Artefact
import grails.rest.RestfulController
import grails.transaction.Transactional
import grails.util.GrailsNameUtils

import org.aspect.grails.services.AspectService;

// This is an example of how could look like an operation controller that consume Aspect's operation infrastructure 
class OperationController extends RestfulController {

	static scope = "request"
	static responseFormats = ['json', 'xml']
	static allowedMethods = [execute: "POST"]
	
	AspectService aspectService
	
	def execute() {
		//	POST http://host/example.project.app/operation/execute {"signature":"common.read", "args":{"entity":{"id":60}}}
		protect { 
			def signature = request.JSON?.signature ?: ""
			def args = request.JSON?.args ?: [:]
			def modifiers = request.JSON?.modifiers ?: [:]
			respond aspectService.execute(signature:signature, args:args, modifiers:modifiers) 
		}
	}
	
	protected def protect(closure) {
		try{
			closure()
		} catch (RuntimeException e) {
			badRequest(e.message)
			return
		}
	}

	protected void badRequest(message) {
		def model = [ success: false, msg: [ code: BAD_REQUEST.value, text: message]]
		respond model as Object, [model: model, status: BAD_REQUEST, view: 'error400']
	}

}
