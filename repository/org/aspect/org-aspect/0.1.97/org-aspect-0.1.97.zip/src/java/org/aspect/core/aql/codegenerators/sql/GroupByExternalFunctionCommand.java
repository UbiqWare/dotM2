package org.aspect.core.aql.codegenerators.sql;

import java.util.List;

public class GroupByExternalFunctionCommand extends ExternalFunctionStandard {

	@Override
    public StringBuilder toCode(ExpressionListCommand args, List<String> argsCode) {
		//
		StringBuilder groupFieldList = buildGroupByFieldList(argsCode.subList(1, argsCode.size() - 1));
        StringBuilder groupedNamedFieldList = buildGroupFieldList((ExpressionListCommand)args.commandList.get(args.commandList.size() - 1));
        code.append(" SELECT ").append(groupedNamedFieldList);
        code.append(" FROM (").append(argsCode.get(0)).append(") ").append(tableName);
        code.append(" GROUP BY ").append(groupFieldList);
		//
    	return code;
    }

    public StringBuilder buildGroupByFieldList(List<String> fieldList) {
    	//
        StringBuilder group = new StringBuilder();
    	String separator = "";
    	for (String argCode: fieldList) {
    		group.append(separator).append(argCode);
    		separator = ",";
    	}
    	return group;
    }
	
    StringBuilder buildGroupFieldList(ExpressionListCommand commandInitializeList) {
        StringBuilder group = new StringBuilder();
        String separator = "";
        for (Command fieldInit: commandInitializeList.commandList) {
            FieldInitializeCommand field = (FieldInitializeCommand) fieldInit;
            String propertyName = field.left.expression.value.toString().toLowerCase();
            functionCommand.addToSymbolTable(propertyName, propertyName);
        	group.append(separator);
        	String propertyValue = field.right.code.toString().toLowerCase();
        	//group.append(Command.getAliasByConvention(propertyValue, functionName, propertyName));
        	group.append(Command.getAliasByConvention(propertyValue, null, propertyName));
            separator = ", ";
        }
        return group;
    }
	
}
