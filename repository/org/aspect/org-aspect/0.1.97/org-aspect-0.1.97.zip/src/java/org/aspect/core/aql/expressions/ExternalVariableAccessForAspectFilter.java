package org.aspect.core.aql.expressions;

public class ExternalVariableAccessForAspectFilter extends Expression {

    public ExternalVariableAccessForAspectFilter(String variableName) {
        this.text = "$" + variableName;
        this.value = this.text;
        this.leftExpression = variableName;
        this.rightExpression = null;
    }

    public ExternalVariableAccessForAspectFilter(Expression variableAccess) {
        this(variableAccess.leftExpression.toString());
    }

    @Override
    public Expression clone() {
        return new ExternalVariableAccessForAspectFilter(leftExpression.toString());
    }
	
}
