package org.aspect.core.aql.expressions;

public class FieldOrderBy extends Expression {

    public FieldOrderBy(Expression expression, StringLiteral orderDirection) {
    	this.text = "orderByField()";
    	this.value = expression.value + " " + orderDirection.value;
    	this.leftExpression = expression;
    	this.rightExpression = orderDirection;
    }
    
	@Override
    public Expression clone() {
        Expression left = (this.leftExpression instanceof Expression) ? ((Expression)leftExpression).clone() : null;
        Expression right = (this.rightExpression instanceof Expression) ? ((Expression)rightExpression).clone() : null;
        return new FieldOrderBy(left, (StringLiteral)right);
    }
	
	
}
