package org.aspect.core.aql.expressions;

public class ExpressionAccessByRef extends Expression {
	
    public ExpressionAccessByRef(Expression expression) {
    	this.text = "(" + expression.text + ")";
    	this.value = text;
    	this.leftExpression = expression;
    	this.rightExpression = null;
    }

	@Override
    public Expression clone() {
        Expression left = (leftExpression instanceof Expression) ? ((Expression)leftExpression).clone() : null;
        Expression right = (rightExpression instanceof Expression) ? ((Expression)rightExpression).clone() : null;
        Expression e = new ExpressionAccessByRef(left);
        e.rightExpression = right;
        return e;
    }

}
