package org.aspect.core.aql.codegenerators.sql;

/* SQL Notes
 * LIKE is how SqlServer manages regular expressions
 * TODO See how H2, MySQL, PostgreSQL y Oracle manages this expresion
 */

public class PatternMatchingCommand extends Command {
	@Override
	public void toCode() {
        code.append("(").append(left.code).append(" LIKE ").append(right.code).append(")");
    }
}



