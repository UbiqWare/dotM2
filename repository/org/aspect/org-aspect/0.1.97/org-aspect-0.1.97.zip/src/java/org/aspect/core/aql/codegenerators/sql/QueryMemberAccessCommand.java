package org.aspect.core.aql.codegenerators.sql;

import org.aspect.core.aql.entites.PropertyType;

public class QueryMemberAccessCommand extends Command {
	@Override
	public void onBeforeLeftToCode() {
        // We get a table name id for all the tables involved
        tableName = codeGenerator.getNewTableId();
    	// Open a command context
        codeGenerator.openCommandContext(this);
        //
        code = new StringBuilder();
	}

	@Override
	public void onAfterToCode() {
        // Close a command context
        codeGenerator.closeCommandContext();
	}
	
	@Override
	public void toCode() {
		//
        code.append(" SELECT ").append(tableName).append(".* FROM (").append(right.code).append(")").append(tableName);
    }

	@Override
    public Command getCurrentCommandWithSymbolTable() {
        return this;
    }

	@Override
    public Command getCurrentCommandWithTableName() {
        return this;
    }

	@Override
	public PropertyType getPropertyByPAC(PropertyAccessCommand pac) {
		PropertyType p = right.getPropertyByPAC(pac);
		return p;
	}
	
}
