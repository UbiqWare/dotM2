package org.aspect.core.aql.entites;

import java.util.*;

public abstract class PersistentEntityType {

	public String name;

	public String alias;
	
    public PersistentPropertyType id;

    public PersistentEntityType(String name) {
    	this.name = name;
    	this.alias = name;
    }

    public PersistentEntityType(String name, String alias) {
    	this.name = name;
    	this.alias = alias;
    }
    
    
	private List<PersistentPropertyType> properties = new ArrayList<PersistentPropertyType>();

	public List<PersistentPropertyType> getProperties() {
		return properties;
	}

    public HashMap<String, PersistentPropertyType> propertiesMap = new HashMap<String, PersistentPropertyType>();

	public void addProperty(PersistentPropertyType property) {
		this.getProperties().add(property);
		this.propertiesMap.put(property.name, property);
	}
	public PersistentPropertyType getProperty(String name) {
		return this.propertiesMap.get(name);
	}

	public PersistentEntityType() {
	}

	abstract public PersistentPropertyType buildConstantProperty(PropertyType propertyType);
	
	abstract public PersistentPropertyType buildCalculatedProperty(PropertyType propertyType);
	
}
