package org.aspect.core.aql.codegenerators.sql;

import org.aspect.core.aql.SymbolTable;
import org.aspect.core.aql.entites.PropertyType;

public class ExternalFunctionAccessCommand extends Command {

	ExternalFunctionCommand externaFunctionCommand = null;
	
	@Override
    public Command getCurrentCommandWithEntityType() {
        return left;
    }
	
    @Override 
    public Command getCurrentCommandWithSymbolTable() {
        return this;
    }

    @Override 
    public Command getCurrentCommandWithTableName() {
        return this;
    }

    @Override 
    public Command getRelationAccess() {
        return (left == null) ? null : left.getRelationAccess();
    }

    @Override 
    public void onBeforeLeftToCode() {
        tableName = codeGenerator.getNewTableId();
        codeGenerator.openCommandContext(this);
    }

    @Override 
    public void onBeforeRightToCode() {
    	externaFunctionCommand = (ExternalFunctionCommand)this.left;
    }
    
    @Override
	public void addToSymbolTable(SymbolTable sourceSymbolTable) {
		symbolTable.addAll(sourceSymbolTable);
	}
   
    @Override 
    public void onAfterToCode() {
        codeGenerator.closeCommandContext();
    }

    //
    @Override 
    public void toCode() {
        if (externaFunctionCommand.function.isAggregated()) {
            code = externaFunctionCommand.code;
        } else {
            //
            boolean added = addRightPredicateWhereCondition();
            if (added) {
                code.append("SELECT ").append(tableName).append(".*").append(buildExtraSelectField()).append(" FROM (")
                	.append(externaFunctionCommand.code).append(")").append(tableName);
                code.append(buildWhereSentence(" WHERE ", ""));
            } else {
                tableName = externaFunctionCommand.tableName;
                code = externaFunctionCommand.code;
            }
        }
    }

	@Override
	public PropertyType getPropertyByPAC(PropertyAccessCommand pac) {
		PropertyType p = externaFunctionCommand.getPropertyByPAC(pac);
		return p;
	}
    
}
