package org.aspect.core.aql.codegenerators.sql;

import java.util.List;

public class ContextBitXorExternalFunctionCommand extends ExternalFunctionStandardAggregated {
    @Override
    public StringBuilder toCode(ExpressionListCommand args, List<String> argsCode) {
    	return code.append("BIT_XOR(").append(argsCode.get(0)).append(")");
    }
}
