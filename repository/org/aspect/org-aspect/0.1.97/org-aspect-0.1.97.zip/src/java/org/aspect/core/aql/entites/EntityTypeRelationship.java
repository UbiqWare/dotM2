package org.aspect.core.aql.entites;

//
import java.util.HashMap;
//


import org.aspect.core.aql.codegenerators.CodeGeneratorCommand;
import org.aspect.core.aql.codegenerators.sql.Command;

public abstract class EntityTypeRelationship {
	
	public EntityType left;
	public EntityType right;
	public String leftPropertyName;
	public String leftPropertyId;
	public String rawLeftPropertyName;

	public void set(EntityType left, EntityType right, String leftPropertyName, String leftPropertyId) {
		this.left = left;
		this.right = right;
		this.leftPropertyName = leftPropertyName;
		this.leftPropertyId = leftPropertyId;
		rawLeftPropertyName = BuildRawLeftPropertyName(leftPropertyName);
	}
	
	private String BuildRawLeftPropertyName(String leftName) {
		StringBuilder rawName = new StringBuilder();
		boolean lastCharIsUpperCase = false;
		for (int index = 0; index < leftName.length(); index++) {
			char ch = leftName.charAt(index);
			if (Character.isUpperCase(ch)) {
				if (!lastCharIsUpperCase)
					rawName.append(CodeGeneratorCommand.WORD_SEPARATOR);
				ch = Character.toLowerCase(ch);
				lastCharIsUpperCase = true;
			} else {
				lastCharIsUpperCase = false;
			}
			rawName.append(ch);
		}
		return rawName.toString();
	}

	public EntityTypeRelationship(EntityType right, String leftPropertyName, String leftPropertyId) {
		set(null, right, leftPropertyName, leftPropertyId);
	}

	public static final String PREFIX_SEPARATOR = "!";
	
	public abstract EntityTypeRelationship clone();
	
	public void buildFullName(PropertyFullNameArg args) {
		args.persistentProperty.buildFullName(args);
	}

	public void buildKeyFullName(PropertyFullNameArg args) {
		args.persistentProperty.buildKeyFullName(args);
	}

	public PropertyFullNameArg loadFullNameArg(PropertyType property,EntityType entityType, String fixedPrefix, HashMap<String, String> persistentEntityNameIdMap) {
        PropertyFullNameArg args = new PropertyFullNameArg();
        args.property = property;
        args.entityType = entityType;
        args.targetPET = null; 
        args.fixedPrefix = fixedPrefix; 
        args.treatIdAsOtherProperties = true;
        args.persistentEntityNameIdMap = persistentEntityNameIdMap;
        args.entityTypeRelationship = this;
		args.persistentEntity = right.getPersistentEntityType(args.property.persistentEntityName);
		args.persistentProperty = args.persistentEntity.getProperty(args.property.persistentPropertyName);
        return args;
	}
	
	public String getAliasForLeftPET(String petName, String prefix) {
		// TODO check
		return 	prefix + rawLeftPropertyName.toLowerCase() + Command.AGGREGATE_FIELD_SEPARATOR + petName.toLowerCase(); 
	}

	public abstract String getFullName(String persistentEntityName, String localPropertyName);
	
	public abstract String getFullAliasForLeftPET(PersistentEntityType entityPET);

	public abstract String getAliasForLeftPET(PersistentEntityType entityPET);
	
	public abstract String getAliasForLeftPET(String petName);
	
	
}
