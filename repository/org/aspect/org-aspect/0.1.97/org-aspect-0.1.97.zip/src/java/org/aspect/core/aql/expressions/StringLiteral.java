package org.aspect.core.aql.expressions;

public class StringLiteral extends Expression {

	public StringLiteral(String value) {
        this.value = value.substring(1, value.length() - 1);
        this.text = this.value.toString();
        this.leftExpression = this.value;
        this.rightExpression = null;
    }

	@Override
    public Expression clone() {
        return new StringLiteral("'" + value.toString() + "'");
    }

}
