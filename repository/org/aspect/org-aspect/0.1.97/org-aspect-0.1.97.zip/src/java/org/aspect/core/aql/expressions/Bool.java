package org.aspect.core.aql.expressions;

public class Bool extends Expression {
	
    public Bool(String value) {
        this.text = value.toString();
        this.value = new java.lang.Boolean(value);
        this.leftExpression = value;
        this.rightExpression = null;
    }

	public Bool(boolean value) {
        this.text = String.valueOf(value);
        this.value = new java.lang.Boolean(value);
        this.leftExpression = new java.lang.Boolean(value);
        this.rightExpression = null;
    }

	@Override
    public Expression clone() {
        return new Bool((Boolean)this.value);
    }
    
}
