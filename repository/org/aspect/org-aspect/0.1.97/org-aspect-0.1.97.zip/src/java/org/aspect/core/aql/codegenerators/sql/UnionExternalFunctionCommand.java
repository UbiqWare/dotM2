package org.aspect.core.aql.codegenerators.sql;

import java.util.List;

public class UnionExternalFunctionCommand extends ExternalFunctionStandard  {
    @Override
    public StringBuilder toCode(ExpressionListCommand args, List<String> argsCode) {
        // 
        code.append("SELECT ").append(tableName).append(".* FROM (");
        String union = "";
        for (String argCode: argsCode) {
            code.append(union + argCode);
            union = " UNION ";
        }
        code.append(")").append(tableName);
        return code;
    }
}
