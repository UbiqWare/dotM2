package org.aspect.core.aql.codegenerators.sql;

import java.util.List;

import org.aspect.core.aql.entites.FunctionByQueryEntityType;
import org.aspect.core.aql.expressions.ExternalFunction;

public class FunctionByQueryExternalFunctionCommand extends	ExternalFunctionStandard {
	ExternalFunction externalFunction;
	//
	FunctionByQueryEntityType funtionByQueryET;
	
	@Override
	public void onBeforeRightToCode() {
    	funtionByQueryET = functionCommand.codeGenerator.getSymbolTable().getFunctionByQuery(functionName);
	};
	
	@Override
    public void onBeforeLeftToCode() {
        functionCommand.codeGenerator.openCommandContext(functionCommand);
    	functionCommand.addArgsToSymbolTable = false;
    	functionCommand.positionToAddInSymbolTable = 0;
		functionName =  functionCommand.expression.leftExpression.toString();
    }
	

    @Override 
    public void onAfterArgToCode(Command command, int position) {
    	// If it's not the last argument, a new external variable is set in the function context/symbol table
    	if (position < funtionByQueryET.args.size() - 1) {
	    	String argName = funtionByQueryET.args.get(Integer.toBinaryString(position)).toString();
	    	String argValue = command.code.toString();
	    	functionCommand.symbolTable.setExternalVariable(argName, argValue);
    	}
    }
	
	@Override
    public StringBuilder toCode(ExpressionListCommand args, List<String> argsCode) {
		//
		code.append(argsCode.get(argsCode.size() - 1));
		//
    	return code;
    }

}
