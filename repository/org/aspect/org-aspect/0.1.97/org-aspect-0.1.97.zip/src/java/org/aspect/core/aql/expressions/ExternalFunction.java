package org.aspect.core.aql.expressions;

import org.aspect.core.aql.SymbolTable;
import org.aspect.core.aql.entites.FunctionByQueryEntityType;


public class ExternalFunction extends Expression {

    public String functionName;
    public SymbolTable symbolTable;
    public IExternalFunction externalFunction;

    public void init(String functionName, ExpressionList args, SymbolTable symbolTable) {
    	//
    	functionName = translateFunctionName(functionName, args);
        this.functionName = functionName;
        this.symbolTable = symbolTable;
        //
        this.externalFunction = (IExternalFunction)symbolTable.getNewExternalFunctionInstance(functionName);
        this.externalFunction.initialize(this);
        this.leftExpression = functionName;
        // If it is a FunctionByQueryEntityType, we add its body as an arg <-> delegate
    	FunctionByQueryEntityType funtionByQueryET = symbolTable.getFunctionByQuery(functionName);
    	if (funtionByQueryET != null) {
    		args.add(funtionByQueryET.expression.clone());
    	}
    	//
        this.rightExpression = this.externalFunction.buildArgs(args);
        this.text = this.functionName + "(" + args.value + ")";
        this.value = this.text;
    }

    public ExternalFunction(String functionName, ExpressionList args, SymbolTable symbolTable) {
    	init(functionName, args, symbolTable);
    }

    public ExternalFunction(String functionName, Expression arg1, SymbolTable symbolTable) {
        ExpressionList args = new ExpressionList();
        args.add(arg1);
        init(functionName, args, symbolTable);
    }

    public ExternalFunction(String functionName, Expression arg1, Expression arg2, SymbolTable symbolTable) {
        ExpressionList args = new ExpressionList();
        args.add(arg1);
        args.add(arg2);
        init(functionName, args, symbolTable);
    }

    public ExternalFunction(String functionName, Expression arg1, Expression arg2, Expression arg3, SymbolTable symbolTable) {
        ExpressionList args = new ExpressionList();
        args.add(arg1);
        args.add(arg2);
        args.add(arg3);
        init(functionName, args, symbolTable);
    }

    public ExternalFunction(String functionName, Expression arg1, Expression arg2, Expression arg3, Expression arg4, SymbolTable symbolTable) {
        ExpressionList args = new ExpressionList();
        args.add(arg1);
        args.add(arg2);
        args.add(arg3);
        args.add(arg4);
        init(functionName, args, symbolTable);
    }
    
    
    private String translateFunctionName(String currentName, ExpressionList args) {
    	// TODO Refactor using a map
    	String prefix = "";
    	if (currentName.equals("count") && args.getList().size() == 1) {
    		prefix = "context";
    	} else if (currentName.equals("sum") && args.getList().size() == 1) {
    		prefix = "context";
    	} else if (currentName.equals("min") && args.getList().size() == 1) {
    		prefix = "context";
    	} else if (currentName.equals("max") && args.getList().size() == 1) {
    		prefix = "context";
    	} else if (currentName.equals("avg") && args.getList().size() == 1) {
    		prefix = "context";
    	} else if (currentName.toLowerCase().equals("bitor") && args.getList().size() == 1) {
    		prefix = "context";
    	} else if (currentName.toLowerCase().equals("bitand") && args.getList().size() == 1) {
    		prefix = "context";
    	} else if (currentName.toLowerCase().equals("bitxor") && args.getList().size() == 1) {
    		prefix = "context";
    	}
    	return prefix + currentName;
	}

	public Expression clone() {
        return new ExternalFunction(leftExpression.toString(), ((ExpressionList)rightExpression), symbolTable);
    }

    public void expand() {
        rightExpression = externalFunction.expand(this, (ExpressionList)rightExpression);
        super.expand();
    }
	
}
