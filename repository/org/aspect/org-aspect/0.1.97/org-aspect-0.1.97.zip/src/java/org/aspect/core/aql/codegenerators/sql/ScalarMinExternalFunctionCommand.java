package org.aspect.core.aql.codegenerators.sql;

import java.util.List;

public class ScalarMinExternalFunctionCommand extends ExternalFunctionStandard {
    @Override
    public StringBuilder toCode(ExpressionListCommand args, List<String> argsCode) {
        return code.append("SELECT MIN(").append(argsCode.get(1)).append(") MIN_Min FROM (")
     		   .append(argsCode.get(0)).append(")").append(tableName);
    }
}
