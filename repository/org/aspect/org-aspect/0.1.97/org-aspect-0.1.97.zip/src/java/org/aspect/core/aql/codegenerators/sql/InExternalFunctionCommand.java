package org.aspect.core.aql.codegenerators.sql;

import java.util.List;

public class InExternalFunctionCommand extends ExternalFunctionStandardFieldAccess {
    @Override
    public StringBuilder toCode(ExpressionListCommand args, List<String> argsCode) {
    	//
    	code.append("(").append(argsCode.get(0)).append(" IN (");
    	//
    	String separator = "";
    	for (String argCode: argsCode.subList(1, argsCode.size())) {
    		code.append(separator).append(argCode);
    		separator = ",";
    	}
    	//
    	code.append("))");
    	return code;
    }
}
