package org.aspect.core.aql.codegenerators.sql;

import org.aspect.core.aql.expressions.PredicateAccess;
import org.aspect.core.aql.expressions.PropertyAccess;


public class PropertyAccessCommand extends Command {
	private boolean isPredicatePropertyAccess = false;
    String propertyName;
    int contextLevelAccess = 0;

    Command relationAccessCandidate = null;
    Command symbolTableAccessCandidate = null;
    Command fieldAccessCandidate = null;
	Command entityTypeCommand = null;
	//PropertyAccessCommand propertyAccessCommand = null;
    
	@Override
	public void onBeforeLeftToCode() {
		//
		if (!(expression.rightExpression instanceof PredicateAccess)) return;
		//
		isPredicatePropertyAccess = true;
	}
	
	void loadEntityTypeCommandInfo() {
    	entityTypeCommand = codeGenerator.peekEntityTypeCommand(contextLevelAccess);
	}
	
    void loadRelationAccessCandidateInfo() {
        relationAccessCandidate = codeGenerator.peekRelationAccessCommand(contextLevelAccess);
    }
    
    void loadSymbolTableAccessCandidateInfo() {
    	symbolTableAccessCandidate= findSymbolTableAccessAfterPropertyAccess(false);
    }
    
    void loadFieldAccessCandidateInfo(){
        fieldAccessCandidate = codeGenerator.peekTableNamedAccessCommand(contextLevelAccess);
    }
    
	@Override
	public String getTableNameByProperty(String localPersistentPropertyName, int side) {
        return findSymbolTableAccessAfterPropertyAccess(false).tableName;
	}
    
	Command findSymbolTableAccessAfterPropertyAccess(boolean refreshContextLevelAccess) {
		int contextLevel = contextLevelAccess;
		Command symbolTableAccessAfterPropertyAccess = codeGenerator.peekSymbolTableAccessCommand(contextLevel); 
		while (symbolTableAccessAfterPropertyAccess instanceof PropertyAccessCommand) { 
			contextLevel += 1 + ((PropertyAccessCommand)symbolTableAccessAfterPropertyAccess).contextLevelAccess; 
			symbolTableAccessAfterPropertyAccess = codeGenerator.peekSymbolTableAccessCommand(contextLevel);
		}
		if (refreshContextLevelAccess) contextLevelAccess = contextLevel;
		return symbolTableAccessAfterPropertyAccess; 
	}
	
	@Override
	public void onBeforeRightToCode() {
		//
		propertyName = expression.leftExpression.toString();
        contextLevelAccess = ((PropertyAccess)expression).contextLevelAccess;
		////
		//if (codeGenerator.getAspectFilterGeneration()) return;
		// Open a command context if it's a predicate access
		if (isPredicatePropertyAccess) { 
			codeGenerator.openCommandContext(this);
			return;
		}
        // 
        loadEntityTypeCommandInfo();
		loadFieldAccessCandidateInfo();
		loadRelationAccessCandidateInfo();
		loadSymbolTableAccessCandidateInfo();
	}

	
	@Override
	public void onAfterToCode() {
		////
		//if (codeGenerator.getAspectFilterGeneration()) return;
        // Close a command context if it's a predicate acccess
		if (isPredicatePropertyAccess)
	        codeGenerator.closeCommandContext();
	}

	@Override
	public void toCode() {
		if (isPredicatePropertyAccess) {
			code.append(right.code);
		//} else if (codeGenerator.getAspectFilterGeneration()) {
		//	// TODO propertyNameByConvention is not enought. We have to get name from original aspect property
		//	code.append("$$tablename$$." + Command.getPropertyNameByConvention(expression.leftExpression.toString()));
		} else {
			String fullPropertyPathName = symbolTableAccessCandidate.getFullPathPropertyName(this);
			String localTableName = symbolTableAccessCandidate.getCurrentTableName(this);
	        code.append(localTableName).append(".").append(fullPropertyPathName);
		}
    }

	@Override
    public String getCurrentTableName(PropertyAccessCommand source) {
		if (isPredicatePropertyAccess) 
			return symbolTableAccessCandidate.getCurrentTableName(source);
		return super.getCurrentTableName(source);
    }

	@Override
    public Command getCurrentCommandWithSymbolTable() {
        return this;
    }

	@Override
    public Command getCurrentCommandWithTableName() {
        return this;
    }


	public String getPropertyName() {
		return this.propertyName;
	}
}
