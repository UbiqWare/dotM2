package org.aspect.core.aql.codegenerators.sql;

import java.util.List;

public class IsNullExternalFunctionCommand extends ExternalFunctionStandardFieldAccess {
    @Override
    public StringBuilder toCode(ExpressionListCommand args, List<String> argsCode) {
        return code.append("(").append(argsCode.get(0)).append(" IS NULL)");
    }
}
