package org.aspect.core.aql.codegenerators.sql;

import java.util.List;

import org.aspect.core.aql.SymbolTable;
import org.aspect.core.aql.codegenerators.CodeGeneratorCommand;
import org.aspect.core.aql.entites.PropertyType;
import org.aspect.core.aql.expressions.Expression;
import org.aspect.core.aql.expressions.ExternalFunction;

public class ExternalFunctionCommand extends Command {

	public ExternalFunctionStandard function;

	public ExternalFunctionCommand() {
	}
	
	@Override
    public Command getCurrentCommandWithEntityType() {
        return this;
    }
	
    @Override 
    public Command getCurrentCommandWithSymbolTable() {
        return this;
    }
	
    @Override 
    public Command getCurrentCommandWithTableName() {
        return this;
    }

    @Override
    public void onBeforeLeftToCode() {
        //
        tableName = codeGenerator.getNewTableId();
        //
        function = (ExternalFunctionStandard) ((ExternalFunction)expression).externalFunction;
        function.functionCommand = this;
        function.tableName = tableName;
        //
        function.onBeforeLeftToCode();
    }
    
	@Override 
	public void onBeforeRightToCode() {
        function.onBeforeRightToCode();
	}
    
    @Override 
    public void onAfterToCode() {
        function.onAfterToCode();
    }
    
    @Override 
    public void onBeforeArgToCode(Expression expression, int position) {
        function.onBeforeArgToCode(expression, position);
    }

    ExpressionListCommand getArgsAsList() {
    	ExpressionListCommand listReturn = new ExpressionListCommand();
        if (right != null) {
            for (Command cmd: ((ExpressionListCommand)right).commandList) {
                listReturn.commandList.add(cmd);
            }
            for (Command cmd: listReturn.commandList) {
                if (cmd instanceof ExpressionListCommand) {
                    listReturn.getCodeList().add( ((ExpressionListCommand)cmd).getCodeListAsString());
                } else {
                    listReturn.getCodeList().add(cmd.code.toString());
                }
            }
        }
        return listReturn;
    }

    
    @Override
    public void toCode() {
    	ExpressionListCommand args = getArgsAsList();
        List<String> argsCode = args.getCodeList();
        code = function.toCode(args, argsCode);
    }

    @Override
	public void addToSymbolTable(String name, String value) {
		symbolTable.add(name.toLowerCase(), value);
		parent.addToSymbolTable(name, value);
	}

    @Override
	public void addToSymbolTable(SymbolTable sourceSymbolTable) {
		symbolTable.addAll(sourceSymbolTable);
		parent.addToSymbolTable(sourceSymbolTable);
	}
    
    
    boolean addArgsToSymbolTable = true;
    int positionToAddInSymbolTable = 0;
    boolean setEntityType = true;
    int positionToSetEntityType = 0;
    Command entityTypeCommand = null;
    
    @Override
    public void onAfterArgToCode(CodeGeneratorCommand command, int position) {
    	Command cmd = (Command) command;
    	if (addArgsToSymbolTable && positionToAddInSymbolTable == position) {
    		addToSymbolTable(cmd.getCurrentCommandWithSymbolTable().symbolTable);
		}
    	if (setEntityType && positionToSetEntityType == position) {
    		entityType = cmd.entityType;
    		parent.entityType = cmd.entityType;
    		entityTypeCommand = cmd;
		}
    	// TODO check
        function.onAfterArgToCode(cmd, position);
    }
   
    @Override
	public PropertyType getPropertyByPAC(PropertyAccessCommand pac) {
    	PropertyType p = null;
    	if (entityTypeCommand != null)
    		p = entityTypeCommand.getPropertyByPAC(pac);
    	if (p == null)
    		p = super.getPropertyByPAC(pac);
		if (p == null)
			p = this.function.getPropertyByPAC(pac);
		return p;
	}
    
}
