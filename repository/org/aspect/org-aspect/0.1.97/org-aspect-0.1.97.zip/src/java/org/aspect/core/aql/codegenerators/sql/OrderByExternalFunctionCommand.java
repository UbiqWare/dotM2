package org.aspect.core.aql.codegenerators.sql;

import java.util.List;

public class OrderByExternalFunctionCommand extends ExternalFunctionStandard /*ExternalFunctionStandardFieldAccess*/ {
    @Override
    public StringBuilder toCode(ExpressionListCommand args, List<String> argsCode) {
        code.append("SELECT ").append(tableName).append(".* FROM (").append(argsCode.get(0)).append(")")
        	.append(tableName).append(" ORDER BY ").append(argsCode.get(1));
        return code;
    }
}
