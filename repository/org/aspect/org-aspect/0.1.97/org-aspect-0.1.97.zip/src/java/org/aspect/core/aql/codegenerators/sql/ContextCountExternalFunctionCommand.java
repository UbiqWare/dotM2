package org.aspect.core.aql.codegenerators.sql;

import java.util.List;

public class ContextCountExternalFunctionCommand extends ExternalFunctionStandardAggregated {
    @Override
    public StringBuilder toCode(ExpressionListCommand args, List<String> argsCode) {
    	return code.append("COUNT(").append(argsCode.get(0)).append(")");
    }
}
