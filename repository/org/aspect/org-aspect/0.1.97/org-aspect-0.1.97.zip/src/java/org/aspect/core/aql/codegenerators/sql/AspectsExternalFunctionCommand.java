package org.aspect.core.aql.codegenerators.sql;

public class AspectsExternalFunctionCommand extends AspectExternalFunctionCommand {
	public AspectsExternalFunctionCommand() {
		aspectJoinType = " RIGHT JOIN ";
	}
}
