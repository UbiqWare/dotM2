package org.aspect.core.aql.expressions;

public class Not extends Expression {
	
    public Not(Expression value) {
    	this.text = "!";
        this.value = " !" + value.value;
        this.leftExpression = value;
        this.rightExpression = null;
    }

	@Override
    public Expression clone() {
        Expression left = (leftExpression instanceof Expression) ? ((Expression)leftExpression).clone() : null;
        return new Not(left);
    }

}
