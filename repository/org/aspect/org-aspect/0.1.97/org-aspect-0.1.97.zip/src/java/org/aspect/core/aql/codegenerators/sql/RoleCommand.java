package org.aspect.core.aql.codegenerators.sql;

import org.aspect.core.aql.entites.EntityType;

public class RoleCommand extends Command {
	@Override
	public void toCode() throws Exception {
		ExplicitRelationshipAccessCommand accesorCommand = (ExplicitRelationshipAccessCommand) codeGenerator.peekRelationAccessCommand();
        if (accesorCommand == null) 
        	throw new Exception("role() can't find an ExplicitRelationshipAccess");
        if (accesorCommand.relationshipTableName == "" || accesorCommand.relationshipTableName == null) 
        	throw new Exception("role() can't be used without a relation path");
        //
    	//EntityType entityET = codeGenerator.getSymbolTable().getBaseEntityType();
    	EntityType entityET = codeGenerator.getSymbolTable().getEntityType("role");
        code.append(accesorCommand.roleTableName).append(".").append(entityET.getProperty("name").persistentPropertyName);
    }
}
