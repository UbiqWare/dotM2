package org.aspect.core.aql.codegenerators.sql.entities;

import org.aspect.core.aql.entites.PersistentEntityType;
import org.aspect.core.aql.entites.PersistentPropertyType;
import org.aspect.core.aql.entites.PropertyType;

public class SqlPersistentEntityType extends PersistentEntityType {
	
    public SqlPersistentEntityType() {
    }
    
    public SqlPersistentEntityType(String name) {
    	super(name);
    }

    public SqlPersistentEntityType(String name, String alias) {
    	super(name, alias);
    }
    
    @Override
	public PersistentPropertyType buildConstantProperty(PropertyType propertyType) {
		return new SqlPersistentPropertyType(propertyType.persistentPropertyName, "constant");
	}
    
    
    @Override
	public PersistentPropertyType buildCalculatedProperty(PropertyType propertyType) {
		return new SqlPersistentPropertyType(propertyType.persistentPropertyName, "calculated");
    }

}
