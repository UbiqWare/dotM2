package org.aspect.core.aql.interpreters.sql;

//
import javax.sql.DataSource;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
//
import java.util.HashMap;
import java.util.Map;

import org.aspect.core.aql.SymbolTable;
import org.aspect.core.aql.codegenerators.sql.Command;
import org.aspect.core.aql.interpreters.AbstractIntepreter;
//
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class SqlInterpreter extends AbstractIntepreter {

    private static final Logger log = LoggerFactory.getLogger(SqlInterpreter.class);
	
	public SqlInterpreter(SymbolTable symbolTable) {
		super(symbolTable);
	}

	/**
	 * Connection object. It's assumed is open. Closing processs is made out this class
	 */
	Connection connection;
	
	@Override
	public void setApplicationContext(Object applicationContext) {
		//this.connection = (Connection) applicationContext;
		org.springframework.context.ApplicationContext context = (org.springframework.context.ApplicationContext) applicationContext;
		DataSource ds =  ((DataSource)context.getBean("dataSource"));
		try {
			connection = ds.getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/*
	public Connection getConnection() {
		return connection;
	}
	*/
	
	private String sqlQuery = "";
	
	public void interpret(String query) {
		this.sqlQuery = query;
		//
		Statement stmt = null;
		ResultSet rs = null;
		resultList = new ArrayList<HashMap<String, Object>>();
		//
		try {
			//
			stmt = connection.createStatement();
			rs = stmt.executeQuery(sqlQuery);
			//
            while (rs.next()) {
            	//
            	HashMap<String, Object> record = new HashMap<String, Object>();
        		ResultSetMetaData rsmd = rs.getMetaData();
        		int columnCount = rsmd.getColumnCount();
        		for (int i = 1; i <= columnCount; i++ ) {
        			String name = rsmd.getColumnLabel(i);
        			record.put(name, rs.getObject(name));
        		}
        		//
				resultList.add(transformRecord(record));
            }
		} catch (Exception e) {
			// TODO handle exceptions in detail
			log.error("Got an exception! ");
			log.error(e.getMessage());			
		} finally {
			try {
	        	if (rs != null) rs.close();
	        	if (stmt != null) stmt.close();
	      	} catch (Exception e) {
				// TODO handle exceptions in detail
				log.error("Got an exception! ");
				log.error(e.getMessage());			
	      	}
	    }	
	}
	
	public HashMap<String, Object> transformRecord(HashMap<String, Object> record) {
		// We transform every record
  		HashMap<String, Object> newRecord = new HashMap<String, Object>();
  		for (Map.Entry<String, Object> entry : record.entrySet()) {
  		    transformProperty(newRecord, entry.getKey(), entry.getValue());
  		}
  		// Set to null any map property that is an empty map
  		for (Map.Entry<String, Object> entry : newRecord.entrySet()) {
  			if (entry.getValue() instanceof Map && everyValueIsNull(entry.getValue())) {
  				newRecord.put(entry.getKey(), null);
  			}
  		}
  		
  		return newRecord;
  	}
	
	@SuppressWarnings("unchecked")
	public boolean everyValueIsNull(Object map) {
		if (map == null) return true;
		//
		boolean result = true;
  		for (Map.Entry<String, Object> entry : ((Map<String, Object>)map).entrySet()) {
  			if (entry.getValue() instanceof Map) {
  				result = result && everyValueIsNull(entry.getValue());
  			} else {
  				result = result && (entry.getValue() == null);
  			}
  		}
		return result;
	}
	
	// TODO
	@SuppressWarnings("unchecked")
	public HashMap<String, Object> transformProperty(HashMap<String, Object> record, String propertyName, Object propertyValue) {
		HashMap<String, Object> current = record;
		String[] parts = propertyName.split(Command.AGGREGATE_FIELD_SEPARATOR);
		if (parts.length > 1) {
			for (int i = 0; i < parts.length - 1; i++) {
				String processedName = transformPropertyNameByConvention(parts[i]);
				if (!current.containsKey(processedName)) {
					current.put(processedName, new HashMap<String, Object>());
				}
				current = (HashMap<String, Object>)current.get(processedName);
			}
		}
		//
		String[] fieldParts = parts[parts.length - 1].split(Command.FIELD_SEPARATOR);
		String processedName = "";
		for (int i = 1; i < fieldParts.length - 1; i++) {
			processedName = transformPropertyNameByConvention(fieldParts[i]);
			if (!current.containsKey(processedName)) {
				current.put(processedName, new HashMap<String, Object>());
			}
			current = (HashMap<String, Object>)current.get(processedName);
		}
		processedName = transformPropertyNameByConvention(fieldParts[fieldParts.length - 1]);
		current.put(processedName, propertyValue);
		//
		return record;
  	}
	
	
	// TODO 
	public String transformPropertyNameByConvention(String name) {
		String finalPropertydName = "";
		String[] parts = name.split(Command.WORD_SEPARATOR);
		for (int i = 0; i < parts.length; i++) {
			String subProperty = parts[i];
			if (subProperty.length() == 0) continue;
			finalPropertydName += (i == 0) ? subProperty.substring(0, 1).toLowerCase() : subProperty.substring(0, 1).toUpperCase();
			finalPropertydName += (subProperty.length() == 1) ? "" : subProperty.substring(1, subProperty.length()).toLowerCase();
		}
		return finalPropertydName;
	}
	
	
	// TODO -> getNullMaps(HashMap<Strign, Object> map)
	
	// TODO -> everythingIsNull(HashMap<Strign, Object> map)
	
	

}
