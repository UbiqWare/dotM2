package org.aspect.core.aql.expressions;

public class ExplicitRelationshipAccess extends Expression {
	
    public int dotDirection;
    
    public ExplicitRelationshipAccess(Expression left, Expression right, int dotDirection) {
    	this.text = ".";
    	this.value = left.value + "." + right.value;
    	this.leftExpression = left;
    	this.rightExpression = right;
        this.dotDirection = dotDirection;
    }

	@Override
    public Expression clone() {
        Expression left = (leftExpression instanceof Expression) ? ((Expression)leftExpression).clone() : null;
        Expression right = (rightExpression instanceof Expression) ? ((Expression)rightExpression).clone() : null;
        return new ExplicitRelationshipAccess(left, right, dotDirection);
    }

	protected Expression findRightPredicate(Expression expression) {
		Expression e = expression;
		boolean exit = false;
		do {
			if (e.rightExpression == null) {
				exit = true;
			} else {
				if (e.rightExpression instanceof PredicateAccess) 
					exit = true;
				e = (Expression)e.rightExpression;
			} 
		} while (!exit);
		return e;
	}
	
	protected void buildRightExpression(Expression root, Expression condition) {
    	Expression predicate = findRightPredicate(root);
		if (predicate instanceof PredicateAccess) {
			Expression predicateCondition = (Expression)predicate.leftExpression;
			predicate.leftExpression = new And(predicateCondition, condition);
		} else {
			predicate.rightExpression = new PredicateAccess(condition);
		}
	}
	
	@Override
    public void expand() {
        super.expand();
        switch (dotDirection) {
        	case 1:
        		// If dotDirection = 1 it means '->' has been used. We follow next pattern: e1[p1]->e2[p2] <-> (e1[p1])[parent()].e2[p2]
        		//left = Expression.buildExpressionByRef((Expression) leftExpression);
        		//left.rightExpression = new PredicateAccess(new Parent());
        		//leftExpression = left;
        		//
        		buildRightExpression((Expression)leftExpression, new Parent());
        		break;
            case -1:
            	// If dotDirection = -1 it means '<-' has been used. We follow next pattern: e1[p1]->e2[p2] <-> (e1[p1])[child()].e2[p2]
            	//left = Expression.buildExpressionByRef((Expression) leftExpression);
            	//left.rightExpression = new PredicateAccess(new Child());
            	//leftExpression = left;
        		buildRightExpression((Expression)leftExpression, new Child());
            	break;
            default:
            	// If _dotDirection == 0 it means '.' has been used
            break;
        }
    }

}
