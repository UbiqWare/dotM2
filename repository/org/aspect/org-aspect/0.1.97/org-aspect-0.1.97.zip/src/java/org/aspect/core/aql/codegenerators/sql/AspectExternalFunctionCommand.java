package org.aspect.core.aql.codegenerators.sql;

import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;

//



import org.aspect.core.aql.Aspect;
import org.aspect.core.aql.entites.EntityType;
import org.aspect.core.aql.entites.PropertyType;

public class AspectExternalFunctionCommand  extends ExternalFunctionStandard {

	String 	firstArgCode;
	Command firstCommand;
	String 	defaultAspectName;
	String 	aspectJoinType = " LEFT JOIN ";
	
	HashMap<String, Aspect> aspects = new HashMap<String, Aspect>();

    @Override
    public StringBuilder toCode(ExpressionListCommand args, List<String> argsCode) {
    	// 
        tableName = functionCommand.codeGenerator.getNewTableId();
        // Aspect info
        for (int i = 1; i < args.commandList.size(); i++) {
        	String aspectName = args.commandList.get(i).expression.value.toString();
            Aspect aspect = functionCommand.codeGenerator.getSymbolTable().getAspect(aspectName);
        	EntityType aspectET = functionCommand.codeGenerator.getSymbolTable().getEntityType(aspect.get("entityTypeName").toString());
        	aspectET = aspectET.clone();
            Aspect aspectInfo = new Aspect(aspectName, aspectET, aspect.properties);
            //
            functionCommand.assignTableIdToPersistentEntities(aspectInfo.entityType);
            //
            String entityTypePersistentName = aspectInfo.entityType.getHierarchyPersistentEntityTypes().get(0).name;
        	String aspectTableName = functionCommand.persistentEntityNameIdMap.get(entityTypePersistentName).toString();
            aspectInfo.properties.put("tableName", aspectTableName);
            aspects.put(aspectName,  aspectInfo);
        	//
        	PropertyType p = new PropertyType("className", entityTypePersistentName, "class_name", false); 
        	p.defaultValue = "'" + aspect.get("domainClassName").toString() + "'";
        	p.isConstant = true;
        	aspectET.addProperty(p);
            
        }
        // aql arg info
        firstArgCode = argsCode.get(0);
        firstCommand = args.commandList.get(0);
    	defaultAspectName = args.commandList.get(1).expression.value.toString();
    	// Building final code
		code.append(" SELECT ").append(buildSelectSentence());
		code.append(" FROM ").append(buildFromSentence());
		code.append(buildWhereSentence());    	
    	//
    	return code;
    }

    //
	private StringBuilder buildSelectSentence() {
    	StringBuilder select = new StringBuilder();
    	select.append(tableName).append(".*");
    	for (Entry<String, Aspect> entry: aspects.entrySet()) {
    		String prefix = Command.getPropertyNameByConvention(entry.getValue().name) + Command.AGGREGATE_FIELD_SEPARATOR;
        	select.append(", ");
        	select.append(functionCommand.buildSelectFromEntityType(entry.getValue().entityType, true, prefix));
    	}
		return select;
	}

	private StringBuilder buildFromSentence() {
    	StringBuilder from = new StringBuilder();
    	//
    	from.append(" (").append(firstArgCode).append(")").append(tableName);
    	// TODO: 	If an aspect has one or more Entity properties, like relationship, security should be checked
    	//			This could not happen if security is checked in MemberAccessCommand. Review
    	for (Entry<String, Aspect> entry: aspects.entrySet()) {
        	StringBuilder on = new StringBuilder();
        	Aspect aspect = entry.getValue();
        	String aspectTableName = aspect.get("tableName").toString();
        	String left = aspect.get("left").toString();
        	//
            on.append(" ON ").append(aspectTableName).append(".").append(aspect.entityType.getProperty(left).persistentPropertyName);
            on.append(" = ").append(tableName).append(".").append(Command.DEFAULT_FIELD_ID);
            //
        	StringBuilder aspectJoin = functionCommand.buildJoinFromEntityType(aspect.entityType, null, on);
            from.append(aspectJoinType).append(aspectJoin);
    	}
    	//
        return from;
	}
	
    private StringBuilder buildWhereSentence() {
    	StringBuilder where;
    	where = functionCommand.buildWhereSentence(" WHERE (", ")");
    	return where;
	}

    @Override
	public PropertyType getPropertyByPAC(PropertyAccessCommand pac) {
    	Aspect aspect = aspects.get(pac.propertyName);
    	if (aspect != null) {
    		pac.entityType = aspect.entityType;
    		String petName = aspect.entityType.getHierarchyPersistentEntityTypes().get(0).name; 
    		PropertyType p = new PropertyType(pac.propertyName, petName, petName);
    		p.isJoinRelationship = true;
    		return p;
    	} else {
        	aspect = aspects.get(defaultAspectName);
        	PropertyType p = functionCommand.entityTypeCommand.getPropertyByPAC(pac);
        	return p;
    	}
    }
}

