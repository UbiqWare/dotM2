package org.aspect.core.aql;

//
import java.util.HashMap;
import java.util.Map;
import org.aspect.core.aql.entites.EntityType;
import org.aspect.core.aql.entites.FunctionByQueryEntityType;
import org.aspect.core.aql.entites.PersistentEntityType;
import org.aspect.core.aql.entites.InnerAspect;

public class AqlContext {
    //
    public static final String	        USER_ID = "User";
    public static Map<String, String>   persistanceEngineNameMetadataMap = new HashMap<String, String>();
    //
    public String 				persistanceEngineName;
    public SymbolTable 			symbolTable = new SymbolTable();

    public AqlContext(String persistanceEngineName) {
        initialize(persistanceEngineName);
    }

    private AqlContext(boolean init) {
    }

    public AqlContext clone() {
        AqlContext newAqlContext = new AqlContext(false);
        newAqlContext.persistanceEngineName = persistanceEngineName;
        newAqlContext.symbolTable = symbolTable.clone();
        return newAqlContext;
    }

    public void initialize(String persistanceEngineName) {
        this.persistanceEngineName = persistanceEngineName;
        symbolTable = new SymbolTable();
    }

    public void set(String name, Object value) {
        symbolTable.set(name, value);
    }

    public Object get(String name) {
        return symbolTable.get(name);
    }

    public String getVariable(String name) {
        return symbolTable.getExternalVariable(name);
    }

    public void setVariable(String name, String value) {
        symbolTable.setExternalVariable(name, value);
    }

    public EntityType getEntityType(String name) {
        return symbolTable.getEntityType(name);
    }

    public void setEntityType(String name, EntityType entityType) {
        symbolTable.setEntityType(name, entityType);
    }

    public String getFunction(String functionName) {
        return symbolTable.getFunction(functionName);
    }

    public void setFunction(String functionName, String className) {
        symbolTable.setFunction(functionName, className);
    }

    public FunctionByQueryEntityType getFunctionByQuery(String functionName) {
        return symbolTable.getFunctionByQuery(functionName);
    }

    public void setFunctionByQuery(String functionName, FunctionByQueryEntityType entityType) {
        symbolTable.setFunctionByQuery(functionName, entityType);
    }

    public PersistentEntityType getPersistentEntityType(String name) {
        return symbolTable.getPersistentEntityType(name);
    }

    public void setPersistentEntityType(String name, PersistentEntityType persistentEntityType) {
        symbolTable.setPersistentEntityType(name, persistentEntityType);
    }

    public Aspect getAspect(String name) {
        return symbolTable.getAspect(name);
    }

    public void setAspect(String name, Aspect aspect) {
        symbolTable.setAspect(name, aspect);
    }

    public EntityType getBaseEntityType() {
        return symbolTable.getBaseEntityType();
    }

    public void setBaseEntityType(EntityType entityType) {
        symbolTable.setBaseEntityType(entityType);
    }

    public void removeInnerAspect(String innerAspect) {
        symbolTable.removeInnerAspect(innerAspect);
    }

    public void addInnerAspect(String innerAspectName) {
        symbolTable.addInnerAspect(innerAspectName);
    }

    public void addInnerAspect(String innerAspectName, Aspect innerAspect) {
        symbolTable.addInnerAspect(innerAspectName, innerAspect);
    }

    public Map<String, InnerAspect> getInnerAspects() {
        return symbolTable.getInnerAspects();
    }

    public void setInnerAspects(Map<String, InnerAspect> innerAspects) {
        symbolTable.setInnerAspects(innerAspects);
    }

    public InnerAspect newInnerAspect(String aspectName) {
        return symbolTable.newInnerAspect(aspectName);
    }

    public InnerAspect newInnerAspect(Aspect aspect) {
        return symbolTable.newInnerAspect(aspect);
    }

}
