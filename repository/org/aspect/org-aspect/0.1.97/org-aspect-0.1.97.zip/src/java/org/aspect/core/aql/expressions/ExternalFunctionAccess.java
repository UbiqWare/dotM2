package org.aspect.core.aql.expressions;

public class ExternalFunctionAccess extends Expression {

    public ExternalFunctionAccess(Expression functionExpression) {
    	this.text = functionExpression.value + "()";
    	this.value = functionExpression.value;
    	this.leftExpression = functionExpression;
    	this.rightExpression = null;
    }

    public ExternalFunctionAccess(Expression functionExpression, PredicateAccess predicate) {
    	this.text = functionExpression.value + "()";
    	this.value = functionExpression.value;
    	this.leftExpression = functionExpression;
    	this.rightExpression = predicate;
    }

	@Override
    public Expression clone() {
        Expression left = (leftExpression instanceof Expression) ? ((Expression)leftExpression).clone() : null;
        Expression right = (rightExpression instanceof Expression) ? ((Expression)rightExpression).clone() : null;
        return new ExternalFunctionAccess(left, (PredicateAccess)right);
    }
	
}
