package org.aspect.core.loaders;

public class JIRALoader {

}
