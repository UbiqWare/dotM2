package org.aspect.core.aql.codegenerators.sql;

public class PropertyAccessForAspectFilterCommand extends Command {
	@Override
	public void toCode() {
		// TODO propertyNameByConvention is not enought. We have to get name from original aspect property
		code.append("$$tablename$$." + Command.getPropertyNameByConvention(expression.leftExpression.toString()));
    }
}
