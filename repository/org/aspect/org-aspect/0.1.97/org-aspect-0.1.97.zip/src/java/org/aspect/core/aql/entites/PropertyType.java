// TODO Move to Core
package org.aspect.core.aql.entites;

import java.util.HashMap;
import org.aspect.core.aql.expressions.Expression;

public class PropertyType {
	public String name;
	public String embeddedName = null;
	public String persistentEntityName;
	public String persistentPropertyName;
	public boolean isPersisted = true;
	public boolean isJoinRelationship = true;
	public boolean isConstant = false;
	public boolean isEmbedded = false;
	public boolean isCalculated = false;
	public Expression expression = null;
	//
	public String defaultValue = "";
	HashMap<String, String> aliasMap = new HashMap<String, String>();
	
	public PropertyType(boolean isEmbedded, String name, String embeddedName, String persistentEntityName, String persistentPropertyName) {
		init(name, "", persistentEntityName, persistentPropertyName, true, false);
		this.isEmbedded = isEmbedded;
		this.embeddedName = embeddedName;
	}

	public PropertyType(String name, String aliasStringList, String persistentEntityName, String persistentPropertyName) {
		init(name, aliasStringList, persistentEntityName, persistentPropertyName, true, false);
	}

	public PropertyType(String name, String persistentEntityName, String persistentPropertyName) {
		init(name, "", persistentEntityName, persistentPropertyName, true, false);
	}

	public PropertyType(String name, String persistentEntityName, String persistentPropertyName, boolean isPersisted) {
		init(name, "", persistentEntityName, persistentPropertyName, isPersisted, false);
	}
	
	public PropertyType(String name, String persistentEntityName, String persistentPropertyName, Expression expression) {
		init(name, "", persistentEntityName, persistentPropertyName, false, false);
		this.expression = expression;
		this.isCalculated = true;
	}

	public void init(String name, String aliasStringList, String persistentEntityName, String persistentPropertyName, boolean isPersisted, boolean isConstant) {
		this.name = name;
		aliasMap.put(name,  name);
		for (String alias: aliasStringList.split(","))
			aliasMap.put(alias.trim(), name);
		this.persistentEntityName = persistentEntityName;
		this.persistentPropertyName = persistentPropertyName;
		this.isPersisted = isPersisted;
		this.isConstant = isConstant;
	}
	
	public PropertyType clone() {
		PropertyType clonedProperty = new PropertyType(name, persistentEntityName, persistentPropertyName, isPersisted);
		clonedProperty.isJoinRelationship = isJoinRelationship;
		clonedProperty.isEmbedded = isEmbedded;
		clonedProperty.embeddedName = embeddedName; 
		clonedProperty.aliasMap.putAll(aliasMap);
		clonedProperty.isCalculated = isCalculated;
		clonedProperty.expression = expression;
		return clonedProperty;
	}
	
	public void buildFullName(PropertyFullNameArg args) {
		if (args.targetPET != null && args.persistentEntity.name != args.targetPET.name) {
			args.propertyFullName = "";
		} else {
			args.persistentProperty.buildFullName(args);
		}
	}

	public void buildKeyFullName(PropertyFullNameArg args) {
		args.persistentProperty.buildKeyFullName(args);
	}

	public PropertyFullNameArg loadFullNameArg(EntityType entityType, PersistentEntityType targetPET, boolean treatIdAsOtherProperties, String fixedPrefix, HashMap<String, String> persistentEntityNameIdMap) {
        PropertyFullNameArg args = new PropertyFullNameArg();
        args.entityType = entityType;
        args.targetPET = targetPET; 
        args.fixedPrefix = fixedPrefix; 
        args.treatIdAsOtherProperties = treatIdAsOtherProperties;
        args.property = this;
        args.persistentEntityNameIdMap = persistentEntityNameIdMap;
        //
		PersistentEntityType persistentEntity = args.entityType.getPersistentEntityType(persistentEntityName);
		args.persistentEntity = persistentEntity;
		if (isConstant) {
			args.persistentProperty = persistentEntity.buildConstantProperty(this);
		} else if (isCalculated) {
			args.persistentProperty = persistentEntity.buildCalculatedProperty(this);
		} else {
			args.persistentProperty = persistentEntity.getProperty(persistentPropertyName);
		}
		//PersistentPropertyType persistentProperty = null;
		//if (!isConstant) persistentProperty = persistentEntity.getProperty(persistentPropertyName);
		//else persistentProperty = persistentEntity.buildConstantProperty(this);
		//args.persistentProperty = persistentProperty;
        //
        return args;
	}
}
