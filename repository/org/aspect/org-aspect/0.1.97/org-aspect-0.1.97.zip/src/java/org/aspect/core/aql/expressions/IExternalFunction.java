package org.aspect.core.aql.expressions;

public interface IExternalFunction {
	//
    void initialize(Expression baseExpression);
    //
    ExpressionList buildArgs(ExpressionList args);
    //
    ExpressionList expand(Expression baseExpression, ExpressionList args);
    //
    boolean isAggregated();
}
