package org.aspect.core.aql.entites;

import java.util.HashMap;

import org.aspect.core.aql.expressions.Expression;

public class FunctionByQueryEntityType extends QueryEntityType {

	public HashMap<String, String> args;
	
	public FunctionByQueryEntityType(String name, Expression expression, HashMap<String, String> args) {
		super(name, expression);
		this.args = args;
	}
	
}
