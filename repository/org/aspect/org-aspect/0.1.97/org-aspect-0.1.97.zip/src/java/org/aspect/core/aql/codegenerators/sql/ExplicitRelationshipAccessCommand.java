package org.aspect.core.aql.codegenerators.sql;

import java.util.HashMap;
import java.util.Map.Entry;

import org.aspect.core.aql.Aspect;
import org.aspect.core.aql.codegenerators.sql.entities.SqlEntityTypeRelationship;
import org.aspect.core.aql.entites.EntityType;
import org.aspect.core.aql.entites.PersistentEntityType;
import org.aspect.core.aql.entites.PropertyType;

public class ExplicitRelationshipAccessCommand extends Command {

	String relationshipTableName;
    String roleTableName;
	Aspect relationshipAspect = null;
	EntityType relationshipET = null;
	EntityType roleET = null;
	StringBuilder selectFromEntityType;

	@Override
    public void onBeforeLeftToCode() {
    	//
        relationshipAspect = codeGenerator.getSymbolTable().getAspect("relationship");
    	relationshipET = codeGenerator.getSymbolTable().getEntityType("relationship");
    	roleET = codeGenerator.getSymbolTable().getEntityType("role");
    	entityType = codeGenerator.getSymbolTable().getEntityType(relationshipAspect.get("entityTypeName").toString());
    	// 
    	assignTableIdToPersistentEntities(entityType, persistentEntityNameIdMap);
    	//
    	selectFromEntityType = buildSelectFromEntityType(entityType, true, "relationship" + Command.AGGREGATE_FIELD_SEPARATOR);
    	//
        leftTableName = codeGenerator.getNewTableId();
        rightTableName = codeGenerator.getNewTableId();
        PersistentEntityType basePET = relationshipET.getHierarchyPersistentEntityTypes().get(0);
        relationshipTableName = persistentEntityNameIdMap.get(basePET.name).toString();
        //
        PersistentEntityType rolePET = roleET.getHierarchyPersistentEntityTypes().get(0);
        //String roleTableNameKey = SqlEntityTypeRelationship.getFullAlias("relationshipAspect", "role", rolePET.name);
        String roleTableNameKey = SqlEntityTypeRelationship.getFullAlias("relationship", "role", rolePET.name);
        roleTableName = persistentEntityNameIdMap.get(roleTableNameKey).toString();
        //
        codeGenerator.openCommandContext(this);
    }

	@Override
	public void onAfterToCode() {
        codeGenerator.closeCommandContext();
	}

	@Override
	public void toCode() {
		code.append(" SELECT ").append(buildSelectSentence());
		code.append(" FROM ").append(buildFromSentence());
		code.append(buildWhereSentence());
    }
		
    private StringBuilder buildWhereSentence() {
    	return buildWhereSentence(" WHERE (", ")");
	}

	protected StringBuilder buildFromSentence() {
    	StringBuilder from = new StringBuilder();
    	StringBuilder on = new StringBuilder();
    	PersistentEntityType entityPET = codeGenerator.getSymbolTable().getBaseEntityType().getHierarchyPersistentEntityTypes().get(0);
    	String parent = relationshipAspect.get("left").toString(); 
    	String child = relationshipAspect.get("right").toString(); 
    	EntityType relationshipET = relationshipAspect.entityType;
    	//
        from.append(" (").append(right.code).append(") ").append(rightTableName);
        on.append(" ON ").append(rightTableName).append(".").append(entityPET.id.name);
        on.append("  IN (").append(relationshipTableName).append(".");
        on.append(relationshipET.getProperty(parent).persistentPropertyName).append(", ");
        on.append(relationshipTableName).append(".");
        on.append(relationshipET.getProperty(child).persistentPropertyName).append(")");
    	//
    	StringBuilder aspectJoin = buildJoinFromEntityType(entityType, null, on);
        from.append(" INNER JOIN ").append(aspectJoin);
        from.append("   INNER JOIN (").append(left.code).append(") ").append(leftTableName);
        from.append("   ON ").append(leftTableName).append(".").append(entityPET.id.name);
        from.append(" IN (").append(relationshipTableName).append(".");
        from.append(relationshipET.getProperty(parent).persistentPropertyName).append(", ");
        from.append(relationshipTableName).append(".");
        from.append(relationshipET.getProperty(child).persistentPropertyName).append(")");
        from.append(" AND ").append(rightTableName).append(".").append(entityPET.id.name).append(" <> ");
        from.append(leftTableName).append(".").append(entityPET.id.name);
        return from;
	}

	
	protected StringBuilder buildRelationshipLeftSide() {
		//
		StringBuilder select = new StringBuilder();
		String aliasName = "left";// + Command.AGGREGATE_FIELD_SEPARATOR;
		HashMap<String, String> leftProperties = new HashMap<String, String>(); 
		// First getting all left side properties and copying them in the symboltable, adding prefix to their name
		Command leftCommand = left.getCurrentCommandWithSymbolTable();
		for (Entry<String, Object> property: leftCommand.symbolTable.get().entrySet()) {
			String newKey = property.getValue().toString();
			String newValue = aliasName + Command.AGGREGATE_FIELD_SEPARATOR + property.getValue();
			symbolTable.add(newValue, newValue); // Yes, both args are the same, the new one value
			leftProperties.put(newKey, newValue);
        }
		// Next, generate select clause like buildSelectFromEntityType does
		for (Entry<String, String> property: leftProperties.entrySet()) {
            select.append(", ").append(leftTableName).append(".").append(property.getKey()).append(" ").append(property.getValue());
        }
        //
		return select;
	}
	
	protected StringBuilder buildSelectSentence() {
    	//
    	StringBuilder select = new StringBuilder();
        // Composing relationshipCommand symboltable. First step, copying all symbols in rightCommand
        symbolTable.addAll(right.getCurrentCommandWithSymbolTable().symbolTable);
        select.append(rightTableName).append(".*, ");
		select.append(selectFromEntityType);
		if (codeGenerator.getGraphRequired()) {
			select.append(buildRelationshipLeftSide());
		}
        select.append(buildExtraSelectField());
		return select;
	}

	@Override
	public Command getCurrentCommandWithSymbolTable() {
    	return this;
    }

	@Override
    public Command getCurrentCommandWithTableName() {
        return this;
    }

	@Override
	public Command getRelationAccess() {
        return this;
    }
    

	@Override
	public boolean isNamedSubquery() {
		return false;
	}
	
	@Override
	public PropertyType getPropertyByPAC(PropertyAccessCommand pac) {
		PropertyType p = null;
		Command peekCommand = codeGenerator.peekCommandContext();
		if (!(peekCommand instanceof PropertyAccessCommand)) {
    		pac.entityType = right.entityType;
			p = right.getPropertyByPAC(pac);
		} else {
			String propertyName = pac.propertyName;
    		p = new PropertyType(propertyName, propertyName, propertyName);
			p.isJoinRelationship = true;
			//PropertyAccessCommand command = (PropertyAccessCommand)peekCommand;
			if (propertyName.equals("right")) {
	    		pac.entityType = right.entityType;
	    		p = right.getPropertyByPAC(pac);
			} else if (propertyName.equals("left")) {
	    		pac.entityType = left.entityType;
	    		p = left.getPropertyByPAC(pac);
			} else if (propertyName.equals(relationshipAspect.name)) {
	    		pac.entityType = relationshipET;
			//} else if (command.propertyName.equals("left")) {
	    	//	p = left.getPropertyByPAC(pac);
			//} else if (command.propertyName.equals(relationshipAspect.name)) {
	    	//	pac.entityType = relationshipET;
			} else { // It could be a join field of right, like @type
	    		p = right.getPropertyByPAC(pac);
			}
		}
		return p;
	}

	@Override
    public String getCurrentTableName(PropertyAccessCommand source) {
    	if (!(codeGenerator.peekCommandContext() instanceof Command)) {
			return rightTableName;
    	} else {
        	// source == null only from ExistFunction
    		//if (source == null) return rightTableName;
    		//
			PropertyAccessCommand pac = (PropertyAccessCommand)codeGenerator.peekCommandContext();
			if (pac.propertyName.equals("role")) {
				return roleTableName;
			} else if (pac.propertyName.equals(relationshipAspect.name)) {
				return relationshipTableName;
			} else if (pac.propertyName.equals("left")) {
				return leftTableName;
			} else {// by default -> pac.propertyName.equals("right"))
				return rightTableName;
			}
    	}
    }
    
}
