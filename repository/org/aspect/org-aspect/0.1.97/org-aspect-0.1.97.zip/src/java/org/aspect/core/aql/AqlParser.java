// $ANTLR 3.4 Aql.g 2015-10-23 12:47:58

	package org.aspect.core.aql;
	import org.aspect.core.aql.expressions.*;


import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

import org.antlr.runtime.tree.*;


@SuppressWarnings({"all", "warnings", "unchecked"})
public class AqlParser extends Parser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "ASC", "DESC", "DIGIT", "EXPONENT", "FLOAT", "ID", "IDENTIFIER", "IDKEY", "INT", "INTEGER", "STRING_LITERAL", "WS", "'!'", "'!='", "'$'", "'&&'", "'&'", "'('", "')'", "'*'", "'+'", "','", "'-'", "'->'", "'.'", "'.@'", "'/'", "':'", "'<'", "'<-'", "'<='", "'='", "'=~'", "'>'", "'>='", "'@'", "'['", "']'", "'^'", "'false'", "'true'", "'{'", "'|'", "'||'", "'}'", "'~'"
    };

    public static final int EOF=-1;
    public static final int T__16=16;
    public static final int T__17=17;
    public static final int T__18=18;
    public static final int T__19=19;
    public static final int T__20=20;
    public static final int T__21=21;
    public static final int T__22=22;
    public static final int T__23=23;
    public static final int T__24=24;
    public static final int T__25=25;
    public static final int T__26=26;
    public static final int T__27=27;
    public static final int T__28=28;
    public static final int T__29=29;
    public static final int T__30=30;
    public static final int T__31=31;
    public static final int T__32=32;
    public static final int T__33=33;
    public static final int T__34=34;
    public static final int T__35=35;
    public static final int T__36=36;
    public static final int T__37=37;
    public static final int T__38=38;
    public static final int T__39=39;
    public static final int T__40=40;
    public static final int T__41=41;
    public static final int T__42=42;
    public static final int T__43=43;
    public static final int T__44=44;
    public static final int T__45=45;
    public static final int T__46=46;
    public static final int T__47=47;
    public static final int T__48=48;
    public static final int T__49=49;
    public static final int ASC=4;
    public static final int DESC=5;
    public static final int DIGIT=6;
    public static final int EXPONENT=7;
    public static final int FLOAT=8;
    public static final int ID=9;
    public static final int IDENTIFIER=10;
    public static final int IDKEY=11;
    public static final int INT=12;
    public static final int INTEGER=13;
    public static final int STRING_LITERAL=14;
    public static final int WS=15;

    // delegates
    public Parser[] getDelegates() {
        return new Parser[] {};
    }

    // delegators


    public AqlParser(TokenStream input) {
        this(input, new RecognizerSharedState());
    }
    public AqlParser(TokenStream input, RecognizerSharedState state) {
        super(input, state);
    }

protected TreeAdaptor adaptor = new CommonTreeAdaptor();

public void setTreeAdaptor(TreeAdaptor adaptor) {
    this.adaptor = adaptor;
}
public TreeAdaptor getTreeAdaptor() {
    return adaptor;
}
    public String[] getTokenNames() { return AqlParser.tokenNames; }
    public String getGrammarFileName() { return "Aql.g"; }


    		public SymbolTable symbolTable;


    public static class queryExpression_return extends ParserRuleReturnScope {
        public Expression value;
        Object tree;
        public Object getTree() { return tree; }
    };


    // $ANTLR start "queryExpression"
    // Aql.g:49:8: public queryExpression returns [Expression value] : expressionReturn= expression ;
    public final AqlParser.queryExpression_return queryExpression() throws RecognitionException {
        AqlParser.queryExpression_return retval = new AqlParser.queryExpression_return();
        retval.start = input.LT(1);


        Object root_0 = null;

        AqlParser.expression_return expressionReturn =null;



        try {
            // Aql.g:50:2: (expressionReturn= expression )
            // Aql.g:51:2: expressionReturn= expression
            {
            root_0 = (Object)adaptor.nil();


            pushFollow(FOLLOW_expression_in_queryExpression393);
            expressionReturn=expression();

            state._fsp--;

            adaptor.addChild(root_0, expressionReturn.getTree());

             retval.value = (expressionReturn!=null?expressionReturn.value:null); 

            }

            retval.stop = input.LT(-1);


            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }

        finally {
        	// do for sure before leaving
        }
        return retval;
    }
    // $ANTLR end "queryExpression"


    public static class expression_return extends ParserRuleReturnScope {
        public Expression value;
        Object tree;
        public Object getTree() { return tree; }
    };


    // $ANTLR start "expression"
    // Aql.g:54:1: expression returns [Expression value] : navigateExpressionReturn= navigateExpression ;
    public final AqlParser.expression_return expression() throws RecognitionException {
        AqlParser.expression_return retval = new AqlParser.expression_return();
        retval.start = input.LT(1);


        Object root_0 = null;

        AqlParser.navigateExpression_return navigateExpressionReturn =null;



        try {
            // Aql.g:55:2: (navigateExpressionReturn= navigateExpression )
            // Aql.g:56:2: navigateExpressionReturn= navigateExpression
            {
            root_0 = (Object)adaptor.nil();


            pushFollow(FOLLOW_navigateExpression_in_expression417);
            navigateExpressionReturn=navigateExpression();

            state._fsp--;

            adaptor.addChild(root_0, navigateExpressionReturn.getTree());

             retval.value = (navigateExpressionReturn!=null?navigateExpressionReturn.value:null); 

            }

            retval.stop = input.LT(-1);


            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }

        finally {
        	// do for sure before leaving
        }
        return retval;
    }
    // $ANTLR end "expression"


    public static class navigateExpression_return extends ParserRuleReturnScope {
        public Expression value;
        Object tree;
        public Object getTree() { return tree; }
    };


    // $ANTLR start "navigateExpression"
    // Aql.g:59:1: navigateExpression returns [Expression value] :orExpressionReturn= orExpression ( ( ( '.' | '->' | '<-' ) orExpressionReturn= orExpression ) | ( '.@' propertyName= IDENTIFIER ( '[' orExpressionReturn= orExpression ']' |) ) )* ;
    public final AqlParser.navigateExpression_return navigateExpression() throws RecognitionException {
        AqlParser.navigateExpression_return retval = new AqlParser.navigateExpression_return();
        retval.start = input.LT(1);


        Object root_0 = null;

        Token propertyName=null;
        Token char_literal1=null;
        Token string_literal2=null;
        Token string_literal3=null;
        Token string_literal4=null;
        Token char_literal5=null;
        Token char_literal6=null;
        AqlParser.orExpression_return orExpressionReturn =null;


        Object propertyName_tree=null;
        Object char_literal1_tree=null;
        Object string_literal2_tree=null;
        Object string_literal3_tree=null;
        Object string_literal4_tree=null;
        Object char_literal5_tree=null;
        Object char_literal6_tree=null;

        try {
            // Aql.g:60:2: (orExpressionReturn= orExpression ( ( ( '.' | '->' | '<-' ) orExpressionReturn= orExpression ) | ( '.@' propertyName= IDENTIFIER ( '[' orExpressionReturn= orExpression ']' |) ) )* )
            // Aql.g:60:4: orExpressionReturn= orExpression ( ( ( '.' | '->' | '<-' ) orExpressionReturn= orExpression ) | ( '.@' propertyName= IDENTIFIER ( '[' orExpressionReturn= orExpression ']' |) ) )*
            {
            root_0 = (Object)adaptor.nil();


            int navigateDirection = 0; 

            pushFollow(FOLLOW_orExpression_in_navigateExpression442);
            orExpressionReturn=orExpression();

            state._fsp--;

            adaptor.addChild(root_0, orExpressionReturn.getTree());

             retval.value = (orExpressionReturn!=null?orExpressionReturn.value:null);

            // Aql.g:62:2: ( ( ( '.' | '->' | '<-' ) orExpressionReturn= orExpression ) | ( '.@' propertyName= IDENTIFIER ( '[' orExpressionReturn= orExpression ']' |) ) )*
            loop3:
            do {
                int alt3=3;
                int LA3_0 = input.LA(1);

                if ( ((LA3_0 >= 27 && LA3_0 <= 28)||LA3_0==33) ) {
                    alt3=1;
                }
                else if ( (LA3_0==29) ) {
                    alt3=2;
                }


                switch (alt3) {
            	case 1 :
            	    // Aql.g:63:3: ( ( '.' | '->' | '<-' ) orExpressionReturn= orExpression )
            	    {
            	    // Aql.g:63:3: ( ( '.' | '->' | '<-' ) orExpressionReturn= orExpression )
            	    // Aql.g:63:5: ( '.' | '->' | '<-' ) orExpressionReturn= orExpression
            	    {
            	    // Aql.g:63:5: ( '.' | '->' | '<-' )
            	    int alt1=3;
            	    switch ( input.LA(1) ) {
            	    case 28:
            	        {
            	        alt1=1;
            	        }
            	        break;
            	    case 27:
            	        {
            	        alt1=2;
            	        }
            	        break;
            	    case 33:
            	        {
            	        alt1=3;
            	        }
            	        break;
            	    default:
            	        NoViableAltException nvae =
            	            new NoViableAltException("", 1, 0, input);

            	        throw nvae;

            	    }

            	    switch (alt1) {
            	        case 1 :
            	            // Aql.g:63:7: '.'
            	            {
            	            char_literal1=(Token)match(input,28,FOLLOW_28_in_navigateExpression455); 
            	            char_literal1_tree = 
            	            (Object)adaptor.create(char_literal1)
            	            ;
            	            adaptor.addChild(root_0, char_literal1_tree);


            	            }
            	            break;
            	        case 2 :
            	            // Aql.g:63:13: '->'
            	            {
            	            string_literal2=(Token)match(input,27,FOLLOW_27_in_navigateExpression459); 
            	            string_literal2_tree = 
            	            (Object)adaptor.create(string_literal2)
            	            ;
            	            adaptor.addChild(root_0, string_literal2_tree);


            	            navigateDirection = 1;

            	            }
            	            break;
            	        case 3 :
            	            // Aql.g:63:45: '<-'
            	            {
            	            string_literal3=(Token)match(input,33,FOLLOW_33_in_navigateExpression465); 
            	            string_literal3_tree = 
            	            (Object)adaptor.create(string_literal3)
            	            ;
            	            adaptor.addChild(root_0, string_literal3_tree);


            	            navigateDirection = -1;

            	            }
            	            break;

            	    }


            	    pushFollow(FOLLOW_orExpression_in_navigateExpression479);
            	    orExpressionReturn=orExpression();

            	    state._fsp--;

            	    adaptor.addChild(root_0, orExpressionReturn.getTree());

            	     retval.value = new ExplicitRelationshipAccess(retval.value, (orExpressionReturn!=null?orExpressionReturn.value:null), navigateDirection); 

            	    }


            	    }
            	    break;
            	case 2 :
            	    // Aql.g:66:5: ( '.@' propertyName= IDENTIFIER ( '[' orExpressionReturn= orExpression ']' |) )
            	    {
            	    // Aql.g:66:5: ( '.@' propertyName= IDENTIFIER ( '[' orExpressionReturn= orExpression ']' |) )
            	    // Aql.g:66:7: '.@' propertyName= IDENTIFIER ( '[' orExpressionReturn= orExpression ']' |)
            	    {
            	    string_literal4=(Token)match(input,29,FOLLOW_29_in_navigateExpression494); 
            	    string_literal4_tree = 
            	    (Object)adaptor.create(string_literal4)
            	    ;
            	    adaptor.addChild(root_0, string_literal4_tree);


            	    propertyName=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_navigateExpression500); 
            	    propertyName_tree = 
            	    (Object)adaptor.create(propertyName)
            	    ;
            	    adaptor.addChild(root_0, propertyName_tree);


            	    // Aql.g:67:6: ( '[' orExpressionReturn= orExpression ']' |)
            	    int alt2=2;
            	    int LA2_0 = input.LA(1);

            	    if ( (LA2_0==40) ) {
            	        alt2=1;
            	    }
            	    else if ( (LA2_0==EOF||LA2_0==22||LA2_0==25||(LA2_0 >= 27 && LA2_0 <= 29)||LA2_0==33||LA2_0==48) ) {
            	        alt2=2;
            	    }
            	    else {
            	        NoViableAltException nvae =
            	            new NoViableAltException("", 2, 0, input);

            	        throw nvae;

            	    }
            	    switch (alt2) {
            	        case 1 :
            	            // Aql.g:67:9: '[' orExpressionReturn= orExpression ']'
            	            {
            	            char_literal5=(Token)match(input,40,FOLLOW_40_in_navigateExpression510); 
            	            char_literal5_tree = 
            	            (Object)adaptor.create(char_literal5)
            	            ;
            	            adaptor.addChild(root_0, char_literal5_tree);


            	            pushFollow(FOLLOW_orExpression_in_navigateExpression516);
            	            orExpressionReturn=orExpression();

            	            state._fsp--;

            	            adaptor.addChild(root_0, orExpressionReturn.getTree());

            	            char_literal6=(Token)match(input,41,FOLLOW_41_in_navigateExpression518); 
            	            char_literal6_tree = 
            	            (Object)adaptor.create(char_literal6)
            	            ;
            	            adaptor.addChild(root_0, char_literal6_tree);


            	             retval.value = new InnerRelationshipAccess(retval.value, new MemberAccessByPropertyName((propertyName!=null?propertyName.getText():null), new PredicateAccess((orExpressionReturn!=null?orExpressionReturn.value:null)))); 

            	            }
            	            break;
            	        case 2 :
            	            // Aql.g:68:19: 
            	            {
            	             retval.value = new InnerRelationshipAccess(retval.value, new MemberAccessByPropertyName((propertyName!=null?propertyName.getText():null), null)); 

            	            }
            	            break;

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop3;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);


            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }

        finally {
        	// do for sure before leaving
        }
        return retval;
    }
    // $ANTLR end "navigateExpression"


    public static class orExpression_return extends ParserRuleReturnScope {
        public Expression value;
        Object tree;
        public Object getTree() { return tree; }
    };


    // $ANTLR start "orExpression"
    // Aql.g:75:1: orExpression returns [Expression value] : andExpressionReturn= andExpression ( '||' rightExpressionReturn= andExpression )* ;
    public final AqlParser.orExpression_return orExpression() throws RecognitionException {
        AqlParser.orExpression_return retval = new AqlParser.orExpression_return();
        retval.start = input.LT(1);


        Object root_0 = null;

        Token string_literal7=null;
        AqlParser.andExpression_return andExpressionReturn =null;

        AqlParser.andExpression_return rightExpressionReturn =null;


        Object string_literal7_tree=null;

        try {
            // Aql.g:76:2: (andExpressionReturn= andExpression ( '||' rightExpressionReturn= andExpression )* )
            // Aql.g:77:2: andExpressionReturn= andExpression ( '||' rightExpressionReturn= andExpression )*
            {
            root_0 = (Object)adaptor.nil();


            pushFollow(FOLLOW_andExpression_in_orExpression583);
            andExpressionReturn=andExpression();

            state._fsp--;

            adaptor.addChild(root_0, andExpressionReturn.getTree());

             retval.value = (andExpressionReturn!=null?andExpressionReturn.value:null); 

            // Aql.g:78:2: ( '||' rightExpressionReturn= andExpression )*
            loop4:
            do {
                int alt4=2;
                int LA4_0 = input.LA(1);

                if ( (LA4_0==47) ) {
                    alt4=1;
                }


                switch (alt4) {
            	case 1 :
            	    // Aql.g:78:4: '||' rightExpressionReturn= andExpression
            	    {
            	    string_literal7=(Token)match(input,47,FOLLOW_47_in_orExpression593); 
            	    string_literal7_tree = 
            	    (Object)adaptor.create(string_literal7)
            	    ;
            	    adaptor.addChild(root_0, string_literal7_tree);


            	    pushFollow(FOLLOW_andExpression_in_orExpression599);
            	    rightExpressionReturn=andExpression();

            	    state._fsp--;

            	    adaptor.addChild(root_0, rightExpressionReturn.getTree());

            	     retval.value = new Or(retval.value, (rightExpressionReturn!=null?rightExpressionReturn.value:null)); 

            	    }
            	    break;

            	default :
            	    break loop4;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);


            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }

        finally {
        	// do for sure before leaving
        }
        return retval;
    }
    // $ANTLR end "orExpression"


    public static class andExpression_return extends ParserRuleReturnScope {
        public Expression value;
        Object tree;
        public Object getTree() { return tree; }
    };


    // $ANTLR start "andExpression"
    // Aql.g:81:1: andExpression returns [Expression value] : expressionReturn= bitOrExpression ( '&&' rightExpressionReturn= bitOrExpression )* ;
    public final AqlParser.andExpression_return andExpression() throws RecognitionException {
        AqlParser.andExpression_return retval = new AqlParser.andExpression_return();
        retval.start = input.LT(1);


        Object root_0 = null;

        Token string_literal8=null;
        AqlParser.bitOrExpression_return expressionReturn =null;

        AqlParser.bitOrExpression_return rightExpressionReturn =null;


        Object string_literal8_tree=null;

        try {
            // Aql.g:82:2: (expressionReturn= bitOrExpression ( '&&' rightExpressionReturn= bitOrExpression )* )
            // Aql.g:83:2: expressionReturn= bitOrExpression ( '&&' rightExpressionReturn= bitOrExpression )*
            {
            root_0 = (Object)adaptor.nil();


            pushFollow(FOLLOW_bitOrExpression_in_andExpression627);
            expressionReturn=bitOrExpression();

            state._fsp--;

            adaptor.addChild(root_0, expressionReturn.getTree());

             retval.value = (expressionReturn!=null?expressionReturn.value:null); 

            // Aql.g:84:2: ( '&&' rightExpressionReturn= bitOrExpression )*
            loop5:
            do {
                int alt5=2;
                int LA5_0 = input.LA(1);

                if ( (LA5_0==19) ) {
                    alt5=1;
                }


                switch (alt5) {
            	case 1 :
            	    // Aql.g:84:4: '&&' rightExpressionReturn= bitOrExpression
            	    {
            	    string_literal8=(Token)match(input,19,FOLLOW_19_in_andExpression639); 
            	    string_literal8_tree = 
            	    (Object)adaptor.create(string_literal8)
            	    ;
            	    adaptor.addChild(root_0, string_literal8_tree);


            	    pushFollow(FOLLOW_bitOrExpression_in_andExpression645);
            	    rightExpressionReturn=bitOrExpression();

            	    state._fsp--;

            	    adaptor.addChild(root_0, rightExpressionReturn.getTree());

            	     retval.value = new And(retval.value, (rightExpressionReturn!=null?rightExpressionReturn.value:null));

            	    }
            	    break;

            	default :
            	    break loop5;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);


            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }

        finally {
        	// do for sure before leaving
        }
        return retval;
    }
    // $ANTLR end "andExpression"


    public static class bitOrExpression_return extends ParserRuleReturnScope {
        public Expression value;
        Object tree;
        public Object getTree() { return tree; }
    };


    // $ANTLR start "bitOrExpression"
    // Aql.g:87:1: bitOrExpression returns [Expression value] : expressionReturn= bitXorExpression ( '|' rightExpressionReturn= bitXorExpression )* ;
    public final AqlParser.bitOrExpression_return bitOrExpression() throws RecognitionException {
        AqlParser.bitOrExpression_return retval = new AqlParser.bitOrExpression_return();
        retval.start = input.LT(1);


        Object root_0 = null;

        Token char_literal9=null;
        AqlParser.bitXorExpression_return expressionReturn =null;

        AqlParser.bitXorExpression_return rightExpressionReturn =null;


        Object char_literal9_tree=null;

        try {
            // Aql.g:88:2: (expressionReturn= bitXorExpression ( '|' rightExpressionReturn= bitXorExpression )* )
            // Aql.g:89:2: expressionReturn= bitXorExpression ( '|' rightExpressionReturn= bitXorExpression )*
            {
            root_0 = (Object)adaptor.nil();


            pushFollow(FOLLOW_bitXorExpression_in_bitOrExpression673);
            expressionReturn=bitXorExpression();

            state._fsp--;

            adaptor.addChild(root_0, expressionReturn.getTree());

             retval.value = (expressionReturn!=null?expressionReturn.value:null); 

            // Aql.g:90:2: ( '|' rightExpressionReturn= bitXorExpression )*
            loop6:
            do {
                int alt6=2;
                int LA6_0 = input.LA(1);

                if ( (LA6_0==46) ) {
                    alt6=1;
                }


                switch (alt6) {
            	case 1 :
            	    // Aql.g:90:4: '|' rightExpressionReturn= bitXorExpression
            	    {
            	    char_literal9=(Token)match(input,46,FOLLOW_46_in_bitOrExpression684); 
            	    char_literal9_tree = 
            	    (Object)adaptor.create(char_literal9)
            	    ;
            	    adaptor.addChild(root_0, char_literal9_tree);


            	    pushFollow(FOLLOW_bitXorExpression_in_bitOrExpression690);
            	    rightExpressionReturn=bitXorExpression();

            	    state._fsp--;

            	    adaptor.addChild(root_0, rightExpressionReturn.getTree());

            	     retval.value = new BitOr(retval.value, (rightExpressionReturn!=null?rightExpressionReturn.value:null));

            	    }
            	    break;

            	default :
            	    break loop6;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);


            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }

        finally {
        	// do for sure before leaving
        }
        return retval;
    }
    // $ANTLR end "bitOrExpression"


    public static class bitXorExpression_return extends ParserRuleReturnScope {
        public Expression value;
        Object tree;
        public Object getTree() { return tree; }
    };


    // $ANTLR start "bitXorExpression"
    // Aql.g:93:1: bitXorExpression returns [Expression value] : expressionReturn= bitAndExpression ( '^' rightExpressionReturn= bitAndExpression )* ;
    public final AqlParser.bitXorExpression_return bitXorExpression() throws RecognitionException {
        AqlParser.bitXorExpression_return retval = new AqlParser.bitXorExpression_return();
        retval.start = input.LT(1);


        Object root_0 = null;

        Token char_literal10=null;
        AqlParser.bitAndExpression_return expressionReturn =null;

        AqlParser.bitAndExpression_return rightExpressionReturn =null;


        Object char_literal10_tree=null;

        try {
            // Aql.g:94:2: (expressionReturn= bitAndExpression ( '^' rightExpressionReturn= bitAndExpression )* )
            // Aql.g:95:2: expressionReturn= bitAndExpression ( '^' rightExpressionReturn= bitAndExpression )*
            {
            root_0 = (Object)adaptor.nil();


            pushFollow(FOLLOW_bitAndExpression_in_bitXorExpression718);
            expressionReturn=bitAndExpression();

            state._fsp--;

            adaptor.addChild(root_0, expressionReturn.getTree());

             retval.value = (expressionReturn!=null?expressionReturn.value:null); 

            // Aql.g:96:2: ( '^' rightExpressionReturn= bitAndExpression )*
            loop7:
            do {
                int alt7=2;
                int LA7_0 = input.LA(1);

                if ( (LA7_0==42) ) {
                    alt7=1;
                }


                switch (alt7) {
            	case 1 :
            	    // Aql.g:96:4: '^' rightExpressionReturn= bitAndExpression
            	    {
            	    char_literal10=(Token)match(input,42,FOLLOW_42_in_bitXorExpression729); 
            	    char_literal10_tree = 
            	    (Object)adaptor.create(char_literal10)
            	    ;
            	    adaptor.addChild(root_0, char_literal10_tree);


            	    pushFollow(FOLLOW_bitAndExpression_in_bitXorExpression735);
            	    rightExpressionReturn=bitAndExpression();

            	    state._fsp--;

            	    adaptor.addChild(root_0, rightExpressionReturn.getTree());

            	     retval.value = new BitXor(retval.value, (rightExpressionReturn!=null?rightExpressionReturn.value:null));

            	    }
            	    break;

            	default :
            	    break loop7;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);


            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }

        finally {
        	// do for sure before leaving
        }
        return retval;
    }
    // $ANTLR end "bitXorExpression"


    public static class bitAndExpression_return extends ParserRuleReturnScope {
        public Expression value;
        Object tree;
        public Object getTree() { return tree; }
    };


    // $ANTLR start "bitAndExpression"
    // Aql.g:99:1: bitAndExpression returns [Expression value] : expressionReturn= equalExpression ( '&' rightExpressionReturn= equalExpression )* ;
    public final AqlParser.bitAndExpression_return bitAndExpression() throws RecognitionException {
        AqlParser.bitAndExpression_return retval = new AqlParser.bitAndExpression_return();
        retval.start = input.LT(1);


        Object root_0 = null;

        Token char_literal11=null;
        AqlParser.equalExpression_return expressionReturn =null;

        AqlParser.equalExpression_return rightExpressionReturn =null;


        Object char_literal11_tree=null;

        try {
            // Aql.g:100:2: (expressionReturn= equalExpression ( '&' rightExpressionReturn= equalExpression )* )
            // Aql.g:101:2: expressionReturn= equalExpression ( '&' rightExpressionReturn= equalExpression )*
            {
            root_0 = (Object)adaptor.nil();


            pushFollow(FOLLOW_equalExpression_in_bitAndExpression764);
            expressionReturn=equalExpression();

            state._fsp--;

            adaptor.addChild(root_0, expressionReturn.getTree());

             retval.value = (expressionReturn!=null?expressionReturn.value:null); 

            // Aql.g:102:2: ( '&' rightExpressionReturn= equalExpression )*
            loop8:
            do {
                int alt8=2;
                int LA8_0 = input.LA(1);

                if ( (LA8_0==20) ) {
                    alt8=1;
                }


                switch (alt8) {
            	case 1 :
            	    // Aql.g:102:4: '&' rightExpressionReturn= equalExpression
            	    {
            	    char_literal11=(Token)match(input,20,FOLLOW_20_in_bitAndExpression776); 
            	    char_literal11_tree = 
            	    (Object)adaptor.create(char_literal11)
            	    ;
            	    adaptor.addChild(root_0, char_literal11_tree);


            	    pushFollow(FOLLOW_equalExpression_in_bitAndExpression782);
            	    rightExpressionReturn=equalExpression();

            	    state._fsp--;

            	    adaptor.addChild(root_0, rightExpressionReturn.getTree());

            	     retval.value = new BitAnd(retval.value, (rightExpressionReturn!=null?rightExpressionReturn.value:null));

            	    }
            	    break;

            	default :
            	    break loop8;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);


            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }

        finally {
        	// do for sure before leaving
        }
        return retval;
    }
    // $ANTLR end "bitAndExpression"


    public static class equalExpression_return extends ParserRuleReturnScope {
        public Expression value;
        Object tree;
        public Object getTree() { return tree; }
    };


    // $ANTLR start "equalExpression"
    // Aql.g:105:1: equalExpression returns [Expression value] : plusExpressionReturn= plusExpression ( '=' rigthExpressionReturn= plusExpression | '!=' rigthExpressionReturn= plusExpression | '=~' rigthExpressionReturn= plusExpression | '>' rigthExpressionReturn= plusExpression | '<' rigthExpressionReturn= plusExpression | '>=' rigthExpressionReturn= plusExpression | '<=' rigthExpressionReturn= plusExpression )* ;
    public final AqlParser.equalExpression_return equalExpression() throws RecognitionException {
        AqlParser.equalExpression_return retval = new AqlParser.equalExpression_return();
        retval.start = input.LT(1);


        Object root_0 = null;

        Token char_literal12=null;
        Token string_literal13=null;
        Token string_literal14=null;
        Token char_literal15=null;
        Token char_literal16=null;
        Token string_literal17=null;
        Token string_literal18=null;
        AqlParser.plusExpression_return plusExpressionReturn =null;

        AqlParser.plusExpression_return rigthExpressionReturn =null;


        Object char_literal12_tree=null;
        Object string_literal13_tree=null;
        Object string_literal14_tree=null;
        Object char_literal15_tree=null;
        Object char_literal16_tree=null;
        Object string_literal17_tree=null;
        Object string_literal18_tree=null;

        try {
            // Aql.g:106:2: (plusExpressionReturn= plusExpression ( '=' rigthExpressionReturn= plusExpression | '!=' rigthExpressionReturn= plusExpression | '=~' rigthExpressionReturn= plusExpression | '>' rigthExpressionReturn= plusExpression | '<' rigthExpressionReturn= plusExpression | '>=' rigthExpressionReturn= plusExpression | '<=' rigthExpressionReturn= plusExpression )* )
            // Aql.g:107:2: plusExpressionReturn= plusExpression ( '=' rigthExpressionReturn= plusExpression | '!=' rigthExpressionReturn= plusExpression | '=~' rigthExpressionReturn= plusExpression | '>' rigthExpressionReturn= plusExpression | '<' rigthExpressionReturn= plusExpression | '>=' rigthExpressionReturn= plusExpression | '<=' rigthExpressionReturn= plusExpression )*
            {
            root_0 = (Object)adaptor.nil();


            pushFollow(FOLLOW_plusExpression_in_equalExpression811);
            plusExpressionReturn=plusExpression();

            state._fsp--;

            adaptor.addChild(root_0, plusExpressionReturn.getTree());

             retval.value = (plusExpressionReturn!=null?plusExpressionReturn.value:null); 

            // Aql.g:108:2: ( '=' rigthExpressionReturn= plusExpression | '!=' rigthExpressionReturn= plusExpression | '=~' rigthExpressionReturn= plusExpression | '>' rigthExpressionReturn= plusExpression | '<' rigthExpressionReturn= plusExpression | '>=' rigthExpressionReturn= plusExpression | '<=' rigthExpressionReturn= plusExpression )*
            loop9:
            do {
                int alt9=8;
                switch ( input.LA(1) ) {
                case 35:
                    {
                    alt9=1;
                    }
                    break;
                case 17:
                    {
                    alt9=2;
                    }
                    break;
                case 36:
                    {
                    alt9=3;
                    }
                    break;
                case 37:
                    {
                    alt9=4;
                    }
                    break;
                case 32:
                    {
                    alt9=5;
                    }
                    break;
                case 38:
                    {
                    alt9=6;
                    }
                    break;
                case 34:
                    {
                    alt9=7;
                    }
                    break;

                }

                switch (alt9) {
            	case 1 :
            	    // Aql.g:108:4: '=' rigthExpressionReturn= plusExpression
            	    {
            	    char_literal12=(Token)match(input,35,FOLLOW_35_in_equalExpression822); 
            	    char_literal12_tree = 
            	    (Object)adaptor.create(char_literal12)
            	    ;
            	    adaptor.addChild(root_0, char_literal12_tree);


            	    pushFollow(FOLLOW_plusExpression_in_equalExpression828);
            	    rigthExpressionReturn=plusExpression();

            	    state._fsp--;

            	    adaptor.addChild(root_0, rigthExpressionReturn.getTree());

            	     retval.value = new Equals(retval.value, (rigthExpressionReturn!=null?rigthExpressionReturn.value:null));

            	    }
            	    break;
            	case 2 :
            	    // Aql.g:109:5: '!=' rigthExpressionReturn= plusExpression
            	    {
            	    string_literal13=(Token)match(input,17,FOLLOW_17_in_equalExpression837); 
            	    string_literal13_tree = 
            	    (Object)adaptor.create(string_literal13)
            	    ;
            	    adaptor.addChild(root_0, string_literal13_tree);


            	    pushFollow(FOLLOW_plusExpression_in_equalExpression843);
            	    rigthExpressionReturn=plusExpression();

            	    state._fsp--;

            	    adaptor.addChild(root_0, rigthExpressionReturn.getTree());

            	     retval.value = new NotEquals(retval.value, (rigthExpressionReturn!=null?rigthExpressionReturn.value:null));

            	    }
            	    break;
            	case 3 :
            	    // Aql.g:110:5: '=~' rigthExpressionReturn= plusExpression
            	    {
            	    string_literal14=(Token)match(input,36,FOLLOW_36_in_equalExpression851); 
            	    string_literal14_tree = 
            	    (Object)adaptor.create(string_literal14)
            	    ;
            	    adaptor.addChild(root_0, string_literal14_tree);


            	    pushFollow(FOLLOW_plusExpression_in_equalExpression857);
            	    rigthExpressionReturn=plusExpression();

            	    state._fsp--;

            	    adaptor.addChild(root_0, rigthExpressionReturn.getTree());

            	     retval.value = new PatternMatching(retval.value, (rigthExpressionReturn!=null?rigthExpressionReturn.value:null));

            	    }
            	    break;
            	case 4 :
            	    // Aql.g:111:5: '>' rigthExpressionReturn= plusExpression
            	    {
            	    char_literal15=(Token)match(input,37,FOLLOW_37_in_equalExpression865); 
            	    char_literal15_tree = 
            	    (Object)adaptor.create(char_literal15)
            	    ;
            	    adaptor.addChild(root_0, char_literal15_tree);


            	    pushFollow(FOLLOW_plusExpression_in_equalExpression871);
            	    rigthExpressionReturn=plusExpression();

            	    state._fsp--;

            	    adaptor.addChild(root_0, rigthExpressionReturn.getTree());

            	     retval.value = new GT(retval.value, (rigthExpressionReturn!=null?rigthExpressionReturn.value:null));

            	    }
            	    break;
            	case 5 :
            	    // Aql.g:112:5: '<' rigthExpressionReturn= plusExpression
            	    {
            	    char_literal16=(Token)match(input,32,FOLLOW_32_in_equalExpression879); 
            	    char_literal16_tree = 
            	    (Object)adaptor.create(char_literal16)
            	    ;
            	    adaptor.addChild(root_0, char_literal16_tree);


            	    pushFollow(FOLLOW_plusExpression_in_equalExpression885);
            	    rigthExpressionReturn=plusExpression();

            	    state._fsp--;

            	    adaptor.addChild(root_0, rigthExpressionReturn.getTree());

            	     retval.value = new LT(retval.value, (rigthExpressionReturn!=null?rigthExpressionReturn.value:null));

            	    }
            	    break;
            	case 6 :
            	    // Aql.g:113:5: '>=' rigthExpressionReturn= plusExpression
            	    {
            	    string_literal17=(Token)match(input,38,FOLLOW_38_in_equalExpression893); 
            	    string_literal17_tree = 
            	    (Object)adaptor.create(string_literal17)
            	    ;
            	    adaptor.addChild(root_0, string_literal17_tree);


            	    pushFollow(FOLLOW_plusExpression_in_equalExpression899);
            	    rigthExpressionReturn=plusExpression();

            	    state._fsp--;

            	    adaptor.addChild(root_0, rigthExpressionReturn.getTree());

            	     retval.value = new GTOrEQ(retval.value, (rigthExpressionReturn!=null?rigthExpressionReturn.value:null));

            	    }
            	    break;
            	case 7 :
            	    // Aql.g:114:5: '<=' rigthExpressionReturn= plusExpression
            	    {
            	    string_literal18=(Token)match(input,34,FOLLOW_34_in_equalExpression907); 
            	    string_literal18_tree = 
            	    (Object)adaptor.create(string_literal18)
            	    ;
            	    adaptor.addChild(root_0, string_literal18_tree);


            	    pushFollow(FOLLOW_plusExpression_in_equalExpression913);
            	    rigthExpressionReturn=plusExpression();

            	    state._fsp--;

            	    adaptor.addChild(root_0, rigthExpressionReturn.getTree());

            	     retval.value = new LTOrEQ(retval.value, (rigthExpressionReturn!=null?rigthExpressionReturn.value:null));

            	    }
            	    break;

            	default :
            	    break loop9;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);


            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }

        finally {
        	// do for sure before leaving
        }
        return retval;
    }
    // $ANTLR end "equalExpression"


    public static class plusExpression_return extends ParserRuleReturnScope {
        public Expression value;
        Object tree;
        public Object getTree() { return tree; }
    };


    // $ANTLR start "plusExpression"
    // Aql.g:118:1: plusExpression returns [Expression value] : multiplyExpressionReturn= multiplyExpression ( '+' rigthExpressionReturn= multiplyExpression | '-' rigthExpressionReturn= multiplyExpression )* ;
    public final AqlParser.plusExpression_return plusExpression() throws RecognitionException {
        AqlParser.plusExpression_return retval = new AqlParser.plusExpression_return();
        retval.start = input.LT(1);


        Object root_0 = null;

        Token char_literal19=null;
        Token char_literal20=null;
        AqlParser.multiplyExpression_return multiplyExpressionReturn =null;

        AqlParser.multiplyExpression_return rigthExpressionReturn =null;


        Object char_literal19_tree=null;
        Object char_literal20_tree=null;

        try {
            // Aql.g:119:2: (multiplyExpressionReturn= multiplyExpression ( '+' rigthExpressionReturn= multiplyExpression | '-' rigthExpressionReturn= multiplyExpression )* )
            // Aql.g:120:2: multiplyExpressionReturn= multiplyExpression ( '+' rigthExpressionReturn= multiplyExpression | '-' rigthExpressionReturn= multiplyExpression )*
            {
            root_0 = (Object)adaptor.nil();


            pushFollow(FOLLOW_multiplyExpression_in_plusExpression941);
            multiplyExpressionReturn=multiplyExpression();

            state._fsp--;

            adaptor.addChild(root_0, multiplyExpressionReturn.getTree());

             retval.value = (multiplyExpressionReturn!=null?multiplyExpressionReturn.value:null); 

            // Aql.g:121:2: ( '+' rigthExpressionReturn= multiplyExpression | '-' rigthExpressionReturn= multiplyExpression )*
            loop10:
            do {
                int alt10=3;
                int LA10_0 = input.LA(1);

                if ( (LA10_0==24) ) {
                    alt10=1;
                }
                else if ( (LA10_0==26) ) {
                    alt10=2;
                }


                switch (alt10) {
            	case 1 :
            	    // Aql.g:121:4: '+' rigthExpressionReturn= multiplyExpression
            	    {
            	    char_literal19=(Token)match(input,24,FOLLOW_24_in_plusExpression951); 
            	    char_literal19_tree = 
            	    (Object)adaptor.create(char_literal19)
            	    ;
            	    adaptor.addChild(root_0, char_literal19_tree);


            	    pushFollow(FOLLOW_multiplyExpression_in_plusExpression957);
            	    rigthExpressionReturn=multiplyExpression();

            	    state._fsp--;

            	    adaptor.addChild(root_0, rigthExpressionReturn.getTree());

            	     retval.value = new Plus(retval.value, (rigthExpressionReturn!=null?rigthExpressionReturn.value:null));

            	    }
            	    break;
            	case 2 :
            	    // Aql.g:122:5: '-' rigthExpressionReturn= multiplyExpression
            	    {
            	    char_literal20=(Token)match(input,26,FOLLOW_26_in_plusExpression967); 
            	    char_literal20_tree = 
            	    (Object)adaptor.create(char_literal20)
            	    ;
            	    adaptor.addChild(root_0, char_literal20_tree);


            	    pushFollow(FOLLOW_multiplyExpression_in_plusExpression973);
            	    rigthExpressionReturn=multiplyExpression();

            	    state._fsp--;

            	    adaptor.addChild(root_0, rigthExpressionReturn.getTree());

            	     retval.value = new Minus(retval.value, (rigthExpressionReturn!=null?rigthExpressionReturn.value:null));

            	    }
            	    break;

            	default :
            	    break loop10;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);


            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }

        finally {
        	// do for sure before leaving
        }
        return retval;
    }
    // $ANTLR end "plusExpression"


    public static class multiplyExpression_return extends ParserRuleReturnScope {
        public Expression value;
        Object tree;
        public Object getTree() { return tree; }
    };


    // $ANTLR start "multiplyExpression"
    // Aql.g:126:1: multiplyExpression returns [Expression value] : unaryExpressionReturn= unaryExpresion ( '*' rigthExpressionReturn= unaryExpresion | '/' rigthExpressionReturn= unaryExpresion )* ;
    public final AqlParser.multiplyExpression_return multiplyExpression() throws RecognitionException {
        AqlParser.multiplyExpression_return retval = new AqlParser.multiplyExpression_return();
        retval.start = input.LT(1);


        Object root_0 = null;

        Token char_literal21=null;
        Token char_literal22=null;
        AqlParser.unaryExpresion_return unaryExpressionReturn =null;

        AqlParser.unaryExpresion_return rigthExpressionReturn =null;


        Object char_literal21_tree=null;
        Object char_literal22_tree=null;

        try {
            // Aql.g:127:2: (unaryExpressionReturn= unaryExpresion ( '*' rigthExpressionReturn= unaryExpresion | '/' rigthExpressionReturn= unaryExpresion )* )
            // Aql.g:128:2: unaryExpressionReturn= unaryExpresion ( '*' rigthExpressionReturn= unaryExpresion | '/' rigthExpressionReturn= unaryExpresion )*
            {
            root_0 = (Object)adaptor.nil();


            pushFollow(FOLLOW_unaryExpresion_in_multiplyExpression1002);
            unaryExpressionReturn=unaryExpresion();

            state._fsp--;

            adaptor.addChild(root_0, unaryExpressionReturn.getTree());

             retval.value = (unaryExpressionReturn!=null?unaryExpressionReturn.value:null); 

            // Aql.g:129:2: ( '*' rigthExpressionReturn= unaryExpresion | '/' rigthExpressionReturn= unaryExpresion )*
            loop11:
            do {
                int alt11=3;
                int LA11_0 = input.LA(1);

                if ( (LA11_0==23) ) {
                    alt11=1;
                }
                else if ( (LA11_0==30) ) {
                    alt11=2;
                }


                switch (alt11) {
            	case 1 :
            	    // Aql.g:129:4: '*' rigthExpressionReturn= unaryExpresion
            	    {
            	    char_literal21=(Token)match(input,23,FOLLOW_23_in_multiplyExpression1009); 
            	    char_literal21_tree = 
            	    (Object)adaptor.create(char_literal21)
            	    ;
            	    adaptor.addChild(root_0, char_literal21_tree);


            	    pushFollow(FOLLOW_unaryExpresion_in_multiplyExpression1015);
            	    rigthExpressionReturn=unaryExpresion();

            	    state._fsp--;

            	    adaptor.addChild(root_0, rigthExpressionReturn.getTree());

            	     retval.value = new Multiply(retval.value, (rigthExpressionReturn!=null?rigthExpressionReturn.value:null));

            	    }
            	    break;
            	case 2 :
            	    // Aql.g:130:5: '/' rigthExpressionReturn= unaryExpresion
            	    {
            	    char_literal22=(Token)match(input,30,FOLLOW_30_in_multiplyExpression1025); 
            	    char_literal22_tree = 
            	    (Object)adaptor.create(char_literal22)
            	    ;
            	    adaptor.addChild(root_0, char_literal22_tree);


            	    pushFollow(FOLLOW_unaryExpresion_in_multiplyExpression1031);
            	    rigthExpressionReturn=unaryExpresion();

            	    state._fsp--;

            	    adaptor.addChild(root_0, rigthExpressionReturn.getTree());

            	     retval.value = new Div(retval.value, (rigthExpressionReturn!=null?rigthExpressionReturn.value:null));

            	    }
            	    break;

            	default :
            	    break loop11;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);


            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }

        finally {
        	// do for sure before leaving
        }
        return retval;
    }
    // $ANTLR end "multiplyExpression"


    public static class unaryExpresion_return extends ParserRuleReturnScope {
        public Expression value;
        Object tree;
        public Object getTree() { return tree; }
    };


    // $ANTLR start "unaryExpresion"
    // Aql.g:134:1: unaryExpresion returns [Expression value] : ( '-' predicateExpressionReturn= predicateExpression | '!' predicateExpressionReturn= predicateExpression | '~' predicateExpressionReturn= predicateExpression |predicateExpressionReturn= predicateExpression );
    public final AqlParser.unaryExpresion_return unaryExpresion() throws RecognitionException {
        AqlParser.unaryExpresion_return retval = new AqlParser.unaryExpresion_return();
        retval.start = input.LT(1);


        Object root_0 = null;

        Token char_literal23=null;
        Token char_literal24=null;
        Token char_literal25=null;
        AqlParser.predicateExpression_return predicateExpressionReturn =null;


        Object char_literal23_tree=null;
        Object char_literal24_tree=null;
        Object char_literal25_tree=null;

        try {
            // Aql.g:135:2: ( '-' predicateExpressionReturn= predicateExpression | '!' predicateExpressionReturn= predicateExpression | '~' predicateExpressionReturn= predicateExpression |predicateExpressionReturn= predicateExpression )
            int alt12=4;
            switch ( input.LA(1) ) {
            case 26:
                {
                alt12=1;
                }
                break;
            case 16:
                {
                alt12=2;
                }
                break;
            case 49:
                {
                alt12=3;
                }
                break;
            case FLOAT:
            case IDENTIFIER:
            case INTEGER:
            case STRING_LITERAL:
            case 18:
            case 21:
            case 39:
            case 43:
            case 44:
            case 45:
                {
                alt12=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 12, 0, input);

                throw nvae;

            }

            switch (alt12) {
                case 1 :
                    // Aql.g:136:2: '-' predicateExpressionReturn= predicateExpression
                    {
                    root_0 = (Object)adaptor.nil();


                    char_literal23=(Token)match(input,26,FOLLOW_26_in_unaryExpresion1054); 
                    char_literal23_tree = 
                    (Object)adaptor.create(char_literal23)
                    ;
                    adaptor.addChild(root_0, char_literal23_tree);


                    pushFollow(FOLLOW_predicateExpression_in_unaryExpresion1061);
                    predicateExpressionReturn=predicateExpression();

                    state._fsp--;

                    adaptor.addChild(root_0, predicateExpressionReturn.getTree());

                     retval.value = new Multiply((predicateExpressionReturn!=null?predicateExpressionReturn.value:null), new Int(-1)); 

                    }
                    break;
                case 2 :
                    // Aql.g:137:4: '!' predicateExpressionReturn= predicateExpression
                    {
                    root_0 = (Object)adaptor.nil();


                    char_literal24=(Token)match(input,16,FOLLOW_16_in_unaryExpresion1068); 
                    char_literal24_tree = 
                    (Object)adaptor.create(char_literal24)
                    ;
                    adaptor.addChild(root_0, char_literal24_tree);


                    pushFollow(FOLLOW_predicateExpression_in_unaryExpresion1075);
                    predicateExpressionReturn=predicateExpression();

                    state._fsp--;

                    adaptor.addChild(root_0, predicateExpressionReturn.getTree());

                     retval.value = new Not((predicateExpressionReturn!=null?predicateExpressionReturn.value:null)); 

                    }
                    break;
                case 3 :
                    // Aql.g:138:4: '~' predicateExpressionReturn= predicateExpression
                    {
                    root_0 = (Object)adaptor.nil();


                    char_literal25=(Token)match(input,49,FOLLOW_49_in_unaryExpresion1082); 
                    char_literal25_tree = 
                    (Object)adaptor.create(char_literal25)
                    ;
                    adaptor.addChild(root_0, char_literal25_tree);


                    pushFollow(FOLLOW_predicateExpression_in_unaryExpresion1089);
                    predicateExpressionReturn=predicateExpression();

                    state._fsp--;

                    adaptor.addChild(root_0, predicateExpressionReturn.getTree());

                     retval.value = new BitNot((predicateExpressionReturn!=null?predicateExpressionReturn.value:null)); 

                    }
                    break;
                case 4 :
                    // Aql.g:139:6: predicateExpressionReturn= predicateExpression
                    {
                    root_0 = (Object)adaptor.nil();


                    pushFollow(FOLLOW_predicateExpression_in_unaryExpresion1102);
                    predicateExpressionReturn=predicateExpression();

                    state._fsp--;

                    adaptor.addChild(root_0, predicateExpressionReturn.getTree());

                     retval.value = (predicateExpressionReturn!=null?predicateExpressionReturn.value:null); 

                    }
                    break;

            }
            retval.stop = input.LT(-1);


            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }

        finally {
        	// do for sure before leaving
        }
        return retval;
    }
    // $ANTLR end "unaryExpresion"


    public static class predicateExpression_return extends ParserRuleReturnScope {
        public Expression value;
        Object tree;
        public Object getTree() { return tree; }
    };


    // $ANTLR start "predicateExpression"
    // Aql.g:142:1: predicateExpression returns [Expression value] : atomExpressionReturn= atomExpression ( '[' orExpressionReturn= orExpression ']' )? ;
    public final AqlParser.predicateExpression_return predicateExpression() throws RecognitionException {
        AqlParser.predicateExpression_return retval = new AqlParser.predicateExpression_return();
        retval.start = input.LT(1);


        Object root_0 = null;

        Token char_literal26=null;
        Token char_literal27=null;
        AqlParser.atomExpression_return atomExpressionReturn =null;

        AqlParser.orExpression_return orExpressionReturn =null;


        Object char_literal26_tree=null;
        Object char_literal27_tree=null;

        try {
            // Aql.g:143:2: (atomExpressionReturn= atomExpression ( '[' orExpressionReturn= orExpression ']' )? )
            // Aql.g:144:2: atomExpressionReturn= atomExpression ( '[' orExpressionReturn= orExpression ']' )?
            {
            root_0 = (Object)adaptor.nil();


            pushFollow(FOLLOW_atomExpression_in_predicateExpression1128);
            atomExpressionReturn=atomExpression();

            state._fsp--;

            adaptor.addChild(root_0, atomExpressionReturn.getTree());

             retval.value = (atomExpressionReturn!=null?atomExpressionReturn.value:null); 

            // Aql.g:145:2: ( '[' orExpressionReturn= orExpression ']' )?
            int alt13=2;
            int LA13_0 = input.LA(1);

            if ( (LA13_0==40) ) {
                alt13=1;
            }
            switch (alt13) {
                case 1 :
                    // Aql.g:145:4: '[' orExpressionReturn= orExpression ']'
                    {
                    char_literal26=(Token)match(input,40,FOLLOW_40_in_predicateExpression1137); 
                    char_literal26_tree = 
                    (Object)adaptor.create(char_literal26)
                    ;
                    adaptor.addChild(root_0, char_literal26_tree);


                    pushFollow(FOLLOW_orExpression_in_predicateExpression1145);
                    orExpressionReturn=orExpression();

                    state._fsp--;

                    adaptor.addChild(root_0, orExpressionReturn.getTree());

                    char_literal27=(Token)match(input,41,FOLLOW_41_in_predicateExpression1151); 
                    char_literal27_tree = 
                    (Object)adaptor.create(char_literal27)
                    ;
                    adaptor.addChild(root_0, char_literal27_tree);


                     retval.value.rightExpression = new PredicateAccess((orExpressionReturn!=null?orExpressionReturn.value:null));

                    }
                    break;

            }


            }

            retval.stop = input.LT(-1);


            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }

        finally {
        	// do for sure before leaving
        }
        return retval;
    }
    // $ANTLR end "predicateExpression"


    public static class atomExpression_return extends ParserRuleReturnScope {
        public Expression value;
        Object tree;
        public Object getTree() { return tree; }
    };


    // $ANTLR start "atomExpression"
    // Aql.g:152:1: atomExpression returns [Expression value] : ( 'true' | 'false' |stringLiteral= STRING_LITERAL |intLiteral= INTEGER |floatLiteral= FLOAT | '$' externalItemName= IDENTIFIER |exprFieldList= fieldList | '(' expressionReturn= expression ')' |role= IDENTIFIER ( '(' (exprList1= expressionList )? ')' |) | '@' propertyAccessReturn= propertyAccess );
    public final AqlParser.atomExpression_return atomExpression() throws RecognitionException {
        AqlParser.atomExpression_return retval = new AqlParser.atomExpression_return();
        retval.start = input.LT(1);


        Object root_0 = null;

        Token stringLiteral=null;
        Token intLiteral=null;
        Token floatLiteral=null;
        Token externalItemName=null;
        Token role=null;
        Token string_literal28=null;
        Token string_literal29=null;
        Token char_literal30=null;
        Token char_literal31=null;
        Token char_literal32=null;
        Token char_literal33=null;
        Token char_literal34=null;
        Token char_literal35=null;
        AqlParser.fieldList_return exprFieldList =null;

        AqlParser.expression_return expressionReturn =null;

        AqlParser.expressionList_return exprList1 =null;

        AqlParser.propertyAccess_return propertyAccessReturn =null;


        Object stringLiteral_tree=null;
        Object intLiteral_tree=null;
        Object floatLiteral_tree=null;
        Object externalItemName_tree=null;
        Object role_tree=null;
        Object string_literal28_tree=null;
        Object string_literal29_tree=null;
        Object char_literal30_tree=null;
        Object char_literal31_tree=null;
        Object char_literal32_tree=null;
        Object char_literal33_tree=null;
        Object char_literal34_tree=null;
        Object char_literal35_tree=null;

        try {
            // Aql.g:153:2: ( 'true' | 'false' |stringLiteral= STRING_LITERAL |intLiteral= INTEGER |floatLiteral= FLOAT | '$' externalItemName= IDENTIFIER |exprFieldList= fieldList | '(' expressionReturn= expression ')' |role= IDENTIFIER ( '(' (exprList1= expressionList )? ')' |) | '@' propertyAccessReturn= propertyAccess )
            int alt16=10;
            switch ( input.LA(1) ) {
            case 44:
                {
                alt16=1;
                }
                break;
            case 43:
                {
                alt16=2;
                }
                break;
            case STRING_LITERAL:
                {
                alt16=3;
                }
                break;
            case INTEGER:
                {
                alt16=4;
                }
                break;
            case FLOAT:
                {
                alt16=5;
                }
                break;
            case 18:
                {
                alt16=6;
                }
                break;
            case 45:
                {
                alt16=7;
                }
                break;
            case 21:
                {
                alt16=8;
                }
                break;
            case IDENTIFIER:
                {
                alt16=9;
                }
                break;
            case 39:
                {
                alt16=10;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 16, 0, input);

                throw nvae;

            }

            switch (alt16) {
                case 1 :
                    // Aql.g:154:2: 'true'
                    {
                    root_0 = (Object)adaptor.nil();


                    string_literal28=(Token)match(input,44,FOLLOW_44_in_atomExpression1185); 
                    string_literal28_tree = 
                    (Object)adaptor.create(string_literal28)
                    ;
                    adaptor.addChild(root_0, string_literal28_tree);


                     retval.value = new Bool(true); 

                    }
                    break;
                case 2 :
                    // Aql.g:155:4: 'false'
                    {
                    root_0 = (Object)adaptor.nil();


                    string_literal29=(Token)match(input,43,FOLLOW_43_in_atomExpression1201); 
                    string_literal29_tree = 
                    (Object)adaptor.create(string_literal29)
                    ;
                    adaptor.addChild(root_0, string_literal29_tree);


                     retval.value = new Bool(false); 

                    }
                    break;
                case 3 :
                    // Aql.g:156:4: stringLiteral= STRING_LITERAL
                    {
                    root_0 = (Object)adaptor.nil();


                    stringLiteral=(Token)match(input,STRING_LITERAL,FOLLOW_STRING_LITERAL_in_atomExpression1220); 
                    stringLiteral_tree = 
                    (Object)adaptor.create(stringLiteral)
                    ;
                    adaptor.addChild(root_0, stringLiteral_tree);


                     retval.value = new StringLiteral((stringLiteral!=null?stringLiteral.getText():null));

                    }
                    break;
                case 4 :
                    // Aql.g:157:4: intLiteral= INTEGER
                    {
                    root_0 = (Object)adaptor.nil();


                    intLiteral=(Token)match(input,INTEGER,FOLLOW_INTEGER_in_atomExpression1233); 
                    intLiteral_tree = 
                    (Object)adaptor.create(intLiteral)
                    ;
                    adaptor.addChild(root_0, intLiteral_tree);


                     retval.value = new org.aspect.core.aql.expressions.Int((intLiteral!=null?intLiteral.getText():null)); 

                    }
                    break;
                case 5 :
                    // Aql.g:158:4: floatLiteral= FLOAT
                    {
                    root_0 = (Object)adaptor.nil();


                    floatLiteral=(Token)match(input,FLOAT,FOLLOW_FLOAT_in_atomExpression1249); 
                    floatLiteral_tree = 
                    (Object)adaptor.create(floatLiteral)
                    ;
                    adaptor.addChild(root_0, floatLiteral_tree);


                     retval.value = new org.aspect.core.aql.expressions.Float((floatLiteral!=null?floatLiteral.getText():null)); 

                    }
                    break;
                case 6 :
                    // Aql.g:159:4: '$' externalItemName= IDENTIFIER
                    {
                    root_0 = (Object)adaptor.nil();


                    char_literal30=(Token)match(input,18,FOLLOW_18_in_atomExpression1261); 
                    char_literal30_tree = 
                    (Object)adaptor.create(char_literal30)
                    ;
                    adaptor.addChild(root_0, char_literal30_tree);


                    externalItemName=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_atomExpression1267); 
                    externalItemName_tree = 
                    (Object)adaptor.create(externalItemName)
                    ;
                    adaptor.addChild(root_0, externalItemName_tree);


                     retval.value = new ExternalVariableAccess((externalItemName!=null?externalItemName.getText():null));

                    }
                    break;
                case 7 :
                    // Aql.g:160:4: exprFieldList= fieldList
                    {
                    root_0 = (Object)adaptor.nil();


                    pushFollow(FOLLOW_fieldList_in_atomExpression1280);
                    exprFieldList=fieldList();

                    state._fsp--;

                    adaptor.addChild(root_0, exprFieldList.getTree());

                     retval.value = (exprFieldList!=null?exprFieldList.value:null); 

                    }
                    break;
                case 8 :
                    // Aql.g:161:4: '(' expressionReturn= expression ')'
                    {
                    root_0 = (Object)adaptor.nil();


                    char_literal31=(Token)match(input,21,FOLLOW_21_in_atomExpression1291); 
                    char_literal31_tree = 
                    (Object)adaptor.create(char_literal31)
                    ;
                    adaptor.addChild(root_0, char_literal31_tree);


                    pushFollow(FOLLOW_expression_in_atomExpression1297);
                    expressionReturn=expression();

                    state._fsp--;

                    adaptor.addChild(root_0, expressionReturn.getTree());

                    char_literal32=(Token)match(input,22,FOLLOW_22_in_atomExpression1299); 
                    char_literal32_tree = 
                    (Object)adaptor.create(char_literal32)
                    ;
                    adaptor.addChild(root_0, char_literal32_tree);


                     retval.value = Expression.buildExpressionByRef((expressionReturn!=null?expressionReturn.value:null)); 

                    }
                    break;
                case 9 :
                    // Aql.g:162:4: role= IDENTIFIER ( '(' (exprList1= expressionList )? ')' |)
                    {
                    root_0 = (Object)adaptor.nil();


                    role=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_atomExpression1311); 
                    role_tree = 
                    (Object)adaptor.create(role)
                    ;
                    adaptor.addChild(root_0, role_tree);


                    // Aql.g:162:22: ( '(' (exprList1= expressionList )? ')' |)
                    int alt15=2;
                    int LA15_0 = input.LA(1);

                    if ( (LA15_0==21) ) {
                        alt15=1;
                    }
                    else if ( (LA15_0==EOF||(LA15_0 >= ASC && LA15_0 <= DESC)||LA15_0==17||(LA15_0 >= 19 && LA15_0 <= 20)||(LA15_0 >= 22 && LA15_0 <= 38)||(LA15_0 >= 40 && LA15_0 <= 42)||(LA15_0 >= 46 && LA15_0 <= 48)) ) {
                        alt15=2;
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 15, 0, input);

                        throw nvae;

                    }
                    switch (alt15) {
                        case 1 :
                            // Aql.g:163:3: '(' (exprList1= expressionList )? ')'
                            {
                            char_literal33=(Token)match(input,21,FOLLOW_21_in_atomExpression1317); 
                            char_literal33_tree = 
                            (Object)adaptor.create(char_literal33)
                            ;
                            adaptor.addChild(root_0, char_literal33_tree);


                            // Aql.g:163:7: (exprList1= expressionList )?
                            int alt14=2;
                            int LA14_0 = input.LA(1);

                            if ( (LA14_0==FLOAT||LA14_0==IDENTIFIER||(LA14_0 >= INTEGER && LA14_0 <= STRING_LITERAL)||LA14_0==16||LA14_0==18||LA14_0==21||LA14_0==26||LA14_0==39||(LA14_0 >= 43 && LA14_0 <= 45)||LA14_0==49) ) {
                                alt14=1;
                            }
                            switch (alt14) {
                                case 1 :
                                    // Aql.g:163:8: exprList1= expressionList
                                    {
                                    pushFollow(FOLLOW_expressionList_in_atomExpression1324);
                                    exprList1=expressionList();

                                    state._fsp--;

                                    adaptor.addChild(root_0, exprList1.getTree());

                                    }
                                    break;

                            }


                            char_literal34=(Token)match(input,22,FOLLOW_22_in_atomExpression1328); 
                            char_literal34_tree = 
                            (Object)adaptor.create(char_literal34)
                            ;
                            adaptor.addChild(root_0, char_literal34_tree);


                             retval.value = Expression.buildFunctionAccess((role!=null?role.getText():null), (exprList1!=null?exprList1.value:null), symbolTable); 

                            }
                            break;
                        case 2 :
                            // Aql.g:164:14: 
                            {
                             retval.value = Expression.buildMemberAccess((role!=null?role.getText():null), symbolTable);

                            }
                            break;

                    }


                    }
                    break;
                case 10 :
                    // Aql.g:166:4: '@' propertyAccessReturn= propertyAccess
                    {
                    root_0 = (Object)adaptor.nil();


                    char_literal35=(Token)match(input,39,FOLLOW_39_in_atomExpression1353); 
                    char_literal35_tree = 
                    (Object)adaptor.create(char_literal35)
                    ;
                    adaptor.addChild(root_0, char_literal35_tree);


                    pushFollow(FOLLOW_propertyAccess_in_atomExpression1359);
                    propertyAccessReturn=propertyAccess();

                    state._fsp--;

                    adaptor.addChild(root_0, propertyAccessReturn.getTree());

                     retval.value = (propertyAccessReturn!=null?propertyAccessReturn.value:null); 

                    }
                    break;

            }
            retval.stop = input.LT(-1);


            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }

        finally {
        	// do for sure before leaving
        }
        return retval;
    }
    // $ANTLR end "atomExpression"


    public static class propertyAccess_return extends ParserRuleReturnScope {
        public Expression value;
        Object tree;
        public Object getTree() { return tree; }
    };


    // $ANTLR start "propertyAccess"
    // Aql.g:169:1: propertyAccess returns [Expression value] : ( ':' )* role= IDENTIFIER ;
    public final AqlParser.propertyAccess_return propertyAccess() throws RecognitionException {
        AqlParser.propertyAccess_return retval = new AqlParser.propertyAccess_return();
        retval.start = input.LT(1);


        Object root_0 = null;

        Token role=null;
        Token char_literal36=null;

        Object role_tree=null;
        Object char_literal36_tree=null;

         int contextLevelAccess = 0; 
        try {
            // Aql.g:171:2: ( ( ':' )* role= IDENTIFIER )
            // Aql.g:172:2: ( ':' )* role= IDENTIFIER
            {
            root_0 = (Object)adaptor.nil();


            // Aql.g:172:2: ( ':' )*
            loop17:
            do {
                int alt17=2;
                int LA17_0 = input.LA(1);

                if ( (LA17_0==31) ) {
                    alt17=1;
                }


                switch (alt17) {
            	case 1 :
            	    // Aql.g:172:4: ':'
            	    {
            	    char_literal36=(Token)match(input,31,FOLLOW_31_in_propertyAccess1386); 
            	    char_literal36_tree = 
            	    (Object)adaptor.create(char_literal36)
            	    ;
            	    adaptor.addChild(root_0, char_literal36_tree);


            	     contextLevelAccess++; 

            	    }
            	    break;

            	default :
            	    break loop17;
                }
            } while (true);


            role=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_propertyAccess1398); 
            role_tree = 
            (Object)adaptor.create(role)
            ;
            adaptor.addChild(root_0, role_tree);


             retval.value = new PropertyAccess((role!=null?role.getText():null), contextLevelAccess); 

            }

            retval.stop = input.LT(-1);


            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }

        finally {
        	// do for sure before leaving
        }
        return retval;
    }
    // $ANTLR end "propertyAccess"


    public static class expressionList_return extends ParserRuleReturnScope {
        public ExpressionList value;
        Object tree;
        public Object getTree() { return tree; }
    };


    // $ANTLR start "expressionList"
    // Aql.g:177:1: expressionList returns [ExpressionList value] : element= expression ( ',' element= expression )* ;
    public final AqlParser.expressionList_return expressionList() throws RecognitionException {
        AqlParser.expressionList_return retval = new AqlParser.expressionList_return();
        retval.start = input.LT(1);


        Object root_0 = null;

        Token char_literal37=null;
        AqlParser.expression_return element =null;


        Object char_literal37_tree=null;

         retval.value = new ExpressionList(); 
        try {
            // Aql.g:179:2: (element= expression ( ',' element= expression )* )
            // Aql.g:180:2: element= expression ( ',' element= expression )*
            {
            root_0 = (Object)adaptor.nil();


            pushFollow(FOLLOW_expression_in_expressionList1429);
            element=expression();

            state._fsp--;

            adaptor.addChild(root_0, element.getTree());

             retval.value.add((element!=null?element.value:null)); 

            // Aql.g:181:2: ( ',' element= expression )*
            loop18:
            do {
                int alt18=2;
                int LA18_0 = input.LA(1);

                if ( (LA18_0==25) ) {
                    alt18=1;
                }


                switch (alt18) {
            	case 1 :
            	    // Aql.g:181:4: ',' element= expression
            	    {
            	    char_literal37=(Token)match(input,25,FOLLOW_25_in_expressionList1437); 
            	    char_literal37_tree = 
            	    (Object)adaptor.create(char_literal37)
            	    ;
            	    adaptor.addChild(root_0, char_literal37_tree);


            	    pushFollow(FOLLOW_expression_in_expressionList1443);
            	    element=expression();

            	    state._fsp--;

            	    adaptor.addChild(root_0, element.getTree());

            	     retval.value.add((element!=null?element.value:null)); 

            	    }
            	    break;

            	default :
            	    break loop18;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);


            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }

        finally {
        	// do for sure before leaving
        }
        return retval;
    }
    // $ANTLR end "expressionList"


    public static class fieldList_return extends ParserRuleReturnScope {
        public ExpressionList value;
        Object tree;
        public Object getTree() { return tree; }
    };


    // $ANTLR start "fieldList"
    // Aql.g:184:1: fieldList returns [ExpressionList value] : '{' fieldExpression= orExpression ( ASC | DESC | ':' valueExpression= expression ) ( ',' fieldExpression= orExpression ( ASC | DESC | ':' valueExpression= expression ) )* '}' ;
    public final AqlParser.fieldList_return fieldList() throws RecognitionException {
        AqlParser.fieldList_return retval = new AqlParser.fieldList_return();
        retval.start = input.LT(1);


        Object root_0 = null;

        Token char_literal38=null;
        Token ASC39=null;
        Token DESC40=null;
        Token char_literal41=null;
        Token char_literal42=null;
        Token ASC43=null;
        Token DESC44=null;
        Token char_literal45=null;
        Token char_literal46=null;
        AqlParser.orExpression_return fieldExpression =null;

        AqlParser.expression_return valueExpression =null;


        Object char_literal38_tree=null;
        Object ASC39_tree=null;
        Object DESC40_tree=null;
        Object char_literal41_tree=null;
        Object char_literal42_tree=null;
        Object ASC43_tree=null;
        Object DESC44_tree=null;
        Object char_literal45_tree=null;
        Object char_literal46_tree=null;

         retval.value = new ExpressionList(); 
        try {
            // Aql.g:186:2: ( '{' fieldExpression= orExpression ( ASC | DESC | ':' valueExpression= expression ) ( ',' fieldExpression= orExpression ( ASC | DESC | ':' valueExpression= expression ) )* '}' )
            // Aql.g:187:2: '{' fieldExpression= orExpression ( ASC | DESC | ':' valueExpression= expression ) ( ',' fieldExpression= orExpression ( ASC | DESC | ':' valueExpression= expression ) )* '}'
            {
            root_0 = (Object)adaptor.nil();


            char_literal38=(Token)match(input,45,FOLLOW_45_in_fieldList1471); 
            char_literal38_tree = 
            (Object)adaptor.create(char_literal38)
            ;
            adaptor.addChild(root_0, char_literal38_tree);


            pushFollow(FOLLOW_orExpression_in_fieldList1478);
            fieldExpression=orExpression();

            state._fsp--;

            adaptor.addChild(root_0, fieldExpression.getTree());

            // Aql.g:189:3: ( ASC | DESC | ':' valueExpression= expression )
            int alt19=3;
            switch ( input.LA(1) ) {
            case ASC:
                {
                alt19=1;
                }
                break;
            case DESC:
                {
                alt19=2;
                }
                break;
            case 31:
                {
                alt19=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 19, 0, input);

                throw nvae;

            }

            switch (alt19) {
                case 1 :
                    // Aql.g:189:5: ASC
                    {
                    ASC39=(Token)match(input,ASC,FOLLOW_ASC_in_fieldList1485); 
                    ASC39_tree = 
                    (Object)adaptor.create(ASC39)
                    ;
                    adaptor.addChild(root_0, ASC39_tree);


                    retval.value.add(new FieldOrderBy((fieldExpression!=null?fieldExpression.value:null), new StringLiteral ("'ASC'")));

                    }
                    break;
                case 2 :
                    // Aql.g:190:7: DESC
                    {
                    DESC40=(Token)match(input,DESC,FOLLOW_DESC_in_fieldList1504); 
                    DESC40_tree = 
                    (Object)adaptor.create(DESC40)
                    ;
                    adaptor.addChild(root_0, DESC40_tree);


                    retval.value.add(new FieldOrderBy((fieldExpression!=null?fieldExpression.value:null), new StringLiteral ("'DESC'")));

                    }
                    break;
                case 3 :
                    // Aql.g:191:7: ':' valueExpression= expression
                    {
                    char_literal41=(Token)match(input,31,FOLLOW_31_in_fieldList1522); 
                    char_literal41_tree = 
                    (Object)adaptor.create(char_literal41)
                    ;
                    adaptor.addChild(root_0, char_literal41_tree);


                    pushFollow(FOLLOW_expression_in_fieldList1528);
                    valueExpression=expression();

                    state._fsp--;

                    adaptor.addChild(root_0, valueExpression.getTree());

                    retval.value.add(new FieldInitialize(new StringLiteral((fieldExpression!=null?input.toString(fieldExpression.start,fieldExpression.stop):null)), (valueExpression!=null?valueExpression.value:null)));

                    }
                    break;

            }


            // Aql.g:193:2: ( ',' fieldExpression= orExpression ( ASC | DESC | ':' valueExpression= expression ) )*
            loop21:
            do {
                int alt21=2;
                int LA21_0 = input.LA(1);

                if ( (LA21_0==25) ) {
                    alt21=1;
                }


                switch (alt21) {
            	case 1 :
            	    // Aql.g:193:4: ',' fieldExpression= orExpression ( ASC | DESC | ':' valueExpression= expression )
            	    {
            	    char_literal42=(Token)match(input,25,FOLLOW_25_in_fieldList1540); 
            	    char_literal42_tree = 
            	    (Object)adaptor.create(char_literal42)
            	    ;
            	    adaptor.addChild(root_0, char_literal42_tree);


            	    pushFollow(FOLLOW_orExpression_in_fieldList1546);
            	    fieldExpression=orExpression();

            	    state._fsp--;

            	    adaptor.addChild(root_0, fieldExpression.getTree());

            	    // Aql.g:194:3: ( ASC | DESC | ':' valueExpression= expression )
            	    int alt20=3;
            	    switch ( input.LA(1) ) {
            	    case ASC:
            	        {
            	        alt20=1;
            	        }
            	        break;
            	    case DESC:
            	        {
            	        alt20=2;
            	        }
            	        break;
            	    case 31:
            	        {
            	        alt20=3;
            	        }
            	        break;
            	    default:
            	        NoViableAltException nvae =
            	            new NoViableAltException("", 20, 0, input);

            	        throw nvae;

            	    }

            	    switch (alt20) {
            	        case 1 :
            	            // Aql.g:194:5: ASC
            	            {
            	            ASC43=(Token)match(input,ASC,FOLLOW_ASC_in_fieldList1553); 
            	            ASC43_tree = 
            	            (Object)adaptor.create(ASC43)
            	            ;
            	            adaptor.addChild(root_0, ASC43_tree);


            	            retval.value.add(new FieldOrderBy((fieldExpression!=null?fieldExpression.value:null), new StringLiteral ("'ASC'")));

            	            }
            	            break;
            	        case 2 :
            	            // Aql.g:195:7: DESC
            	            {
            	            DESC44=(Token)match(input,DESC,FOLLOW_DESC_in_fieldList1567); 
            	            DESC44_tree = 
            	            (Object)adaptor.create(DESC44)
            	            ;
            	            adaptor.addChild(root_0, DESC44_tree);


            	            retval.value.add(new FieldOrderBy((fieldExpression!=null?fieldExpression.value:null), new StringLiteral ("'DESC'")));

            	            }
            	            break;
            	        case 3 :
            	            // Aql.g:196:7: ':' valueExpression= expression
            	            {
            	            char_literal45=(Token)match(input,31,FOLLOW_31_in_fieldList1579); 
            	            char_literal45_tree = 
            	            (Object)adaptor.create(char_literal45)
            	            ;
            	            adaptor.addChild(root_0, char_literal45_tree);


            	            pushFollow(FOLLOW_expression_in_fieldList1585);
            	            valueExpression=expression();

            	            state._fsp--;

            	            adaptor.addChild(root_0, valueExpression.getTree());

            	            retval.value.add(new FieldInitialize(new StringLiteral((fieldExpression!=null?input.toString(fieldExpression.start,fieldExpression.stop):null)), (valueExpression!=null?valueExpression.value:null)));

            	            }
            	            break;

            	    }


            	    }
            	    break;

            	default :
            	    break loop21;
                }
            } while (true);


            char_literal46=(Token)match(input,48,FOLLOW_48_in_fieldList1599); 
            char_literal46_tree = 
            (Object)adaptor.create(char_literal46)
            ;
            adaptor.addChild(root_0, char_literal46_tree);


            }

            retval.stop = input.LT(-1);


            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }

        finally {
        	// do for sure before leaving
        }
        return retval;
    }
    // $ANTLR end "fieldList"

    // Delegated rules


 

    public static final BitSet FOLLOW_expression_in_queryExpression393 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_navigateExpression_in_expression417 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_orExpression_in_navigateExpression442 = new BitSet(new long[]{0x0000000238000002L});
    public static final BitSet FOLLOW_28_in_navigateExpression455 = new BitSet(new long[]{0x0002388004256500L});
    public static final BitSet FOLLOW_27_in_navigateExpression459 = new BitSet(new long[]{0x0002388004256500L});
    public static final BitSet FOLLOW_33_in_navigateExpression465 = new BitSet(new long[]{0x0002388004256500L});
    public static final BitSet FOLLOW_orExpression_in_navigateExpression479 = new BitSet(new long[]{0x0000000238000002L});
    public static final BitSet FOLLOW_29_in_navigateExpression494 = new BitSet(new long[]{0x0000000000000400L});
    public static final BitSet FOLLOW_IDENTIFIER_in_navigateExpression500 = new BitSet(new long[]{0x0000010238000002L});
    public static final BitSet FOLLOW_40_in_navigateExpression510 = new BitSet(new long[]{0x0002388004256500L});
    public static final BitSet FOLLOW_orExpression_in_navigateExpression516 = new BitSet(new long[]{0x0000020000000000L});
    public static final BitSet FOLLOW_41_in_navigateExpression518 = new BitSet(new long[]{0x0000000238000002L});
    public static final BitSet FOLLOW_andExpression_in_orExpression583 = new BitSet(new long[]{0x0000800000000002L});
    public static final BitSet FOLLOW_47_in_orExpression593 = new BitSet(new long[]{0x0002388004256500L});
    public static final BitSet FOLLOW_andExpression_in_orExpression599 = new BitSet(new long[]{0x0000800000000002L});
    public static final BitSet FOLLOW_bitOrExpression_in_andExpression627 = new BitSet(new long[]{0x0000000000080002L});
    public static final BitSet FOLLOW_19_in_andExpression639 = new BitSet(new long[]{0x0002388004256500L});
    public static final BitSet FOLLOW_bitOrExpression_in_andExpression645 = new BitSet(new long[]{0x0000000000080002L});
    public static final BitSet FOLLOW_bitXorExpression_in_bitOrExpression673 = new BitSet(new long[]{0x0000400000000002L});
    public static final BitSet FOLLOW_46_in_bitOrExpression684 = new BitSet(new long[]{0x0002388004256500L});
    public static final BitSet FOLLOW_bitXorExpression_in_bitOrExpression690 = new BitSet(new long[]{0x0000400000000002L});
    public static final BitSet FOLLOW_bitAndExpression_in_bitXorExpression718 = new BitSet(new long[]{0x0000040000000002L});
    public static final BitSet FOLLOW_42_in_bitXorExpression729 = new BitSet(new long[]{0x0002388004256500L});
    public static final BitSet FOLLOW_bitAndExpression_in_bitXorExpression735 = new BitSet(new long[]{0x0000040000000002L});
    public static final BitSet FOLLOW_equalExpression_in_bitAndExpression764 = new BitSet(new long[]{0x0000000000100002L});
    public static final BitSet FOLLOW_20_in_bitAndExpression776 = new BitSet(new long[]{0x0002388004256500L});
    public static final BitSet FOLLOW_equalExpression_in_bitAndExpression782 = new BitSet(new long[]{0x0000000000100002L});
    public static final BitSet FOLLOW_plusExpression_in_equalExpression811 = new BitSet(new long[]{0x0000007D00020002L});
    public static final BitSet FOLLOW_35_in_equalExpression822 = new BitSet(new long[]{0x0002388004256500L});
    public static final BitSet FOLLOW_plusExpression_in_equalExpression828 = new BitSet(new long[]{0x0000007D00020002L});
    public static final BitSet FOLLOW_17_in_equalExpression837 = new BitSet(new long[]{0x0002388004256500L});
    public static final BitSet FOLLOW_plusExpression_in_equalExpression843 = new BitSet(new long[]{0x0000007D00020002L});
    public static final BitSet FOLLOW_36_in_equalExpression851 = new BitSet(new long[]{0x0002388004256500L});
    public static final BitSet FOLLOW_plusExpression_in_equalExpression857 = new BitSet(new long[]{0x0000007D00020002L});
    public static final BitSet FOLLOW_37_in_equalExpression865 = new BitSet(new long[]{0x0002388004256500L});
    public static final BitSet FOLLOW_plusExpression_in_equalExpression871 = new BitSet(new long[]{0x0000007D00020002L});
    public static final BitSet FOLLOW_32_in_equalExpression879 = new BitSet(new long[]{0x0002388004256500L});
    public static final BitSet FOLLOW_plusExpression_in_equalExpression885 = new BitSet(new long[]{0x0000007D00020002L});
    public static final BitSet FOLLOW_38_in_equalExpression893 = new BitSet(new long[]{0x0002388004256500L});
    public static final BitSet FOLLOW_plusExpression_in_equalExpression899 = new BitSet(new long[]{0x0000007D00020002L});
    public static final BitSet FOLLOW_34_in_equalExpression907 = new BitSet(new long[]{0x0002388004256500L});
    public static final BitSet FOLLOW_plusExpression_in_equalExpression913 = new BitSet(new long[]{0x0000007D00020002L});
    public static final BitSet FOLLOW_multiplyExpression_in_plusExpression941 = new BitSet(new long[]{0x0000000005000002L});
    public static final BitSet FOLLOW_24_in_plusExpression951 = new BitSet(new long[]{0x0002388004256500L});
    public static final BitSet FOLLOW_multiplyExpression_in_plusExpression957 = new BitSet(new long[]{0x0000000005000002L});
    public static final BitSet FOLLOW_26_in_plusExpression967 = new BitSet(new long[]{0x0002388004256500L});
    public static final BitSet FOLLOW_multiplyExpression_in_plusExpression973 = new BitSet(new long[]{0x0000000005000002L});
    public static final BitSet FOLLOW_unaryExpresion_in_multiplyExpression1002 = new BitSet(new long[]{0x0000000040800002L});
    public static final BitSet FOLLOW_23_in_multiplyExpression1009 = new BitSet(new long[]{0x0002388004256500L});
    public static final BitSet FOLLOW_unaryExpresion_in_multiplyExpression1015 = new BitSet(new long[]{0x0000000040800002L});
    public static final BitSet FOLLOW_30_in_multiplyExpression1025 = new BitSet(new long[]{0x0002388004256500L});
    public static final BitSet FOLLOW_unaryExpresion_in_multiplyExpression1031 = new BitSet(new long[]{0x0000000040800002L});
    public static final BitSet FOLLOW_26_in_unaryExpresion1054 = new BitSet(new long[]{0x0000388000246500L});
    public static final BitSet FOLLOW_predicateExpression_in_unaryExpresion1061 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_16_in_unaryExpresion1068 = new BitSet(new long[]{0x0000388000246500L});
    public static final BitSet FOLLOW_predicateExpression_in_unaryExpresion1075 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_49_in_unaryExpresion1082 = new BitSet(new long[]{0x0000388000246500L});
    public static final BitSet FOLLOW_predicateExpression_in_unaryExpresion1089 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_predicateExpression_in_unaryExpresion1102 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_atomExpression_in_predicateExpression1128 = new BitSet(new long[]{0x0000010000000002L});
    public static final BitSet FOLLOW_40_in_predicateExpression1137 = new BitSet(new long[]{0x0002388004256500L});
    public static final BitSet FOLLOW_orExpression_in_predicateExpression1145 = new BitSet(new long[]{0x0000020000000000L});
    public static final BitSet FOLLOW_41_in_predicateExpression1151 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_44_in_atomExpression1185 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_43_in_atomExpression1201 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_STRING_LITERAL_in_atomExpression1220 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_INTEGER_in_atomExpression1233 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_FLOAT_in_atomExpression1249 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_18_in_atomExpression1261 = new BitSet(new long[]{0x0000000000000400L});
    public static final BitSet FOLLOW_IDENTIFIER_in_atomExpression1267 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_fieldList_in_atomExpression1280 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_21_in_atomExpression1291 = new BitSet(new long[]{0x0002388004256500L});
    public static final BitSet FOLLOW_expression_in_atomExpression1297 = new BitSet(new long[]{0x0000000000400000L});
    public static final BitSet FOLLOW_22_in_atomExpression1299 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_IDENTIFIER_in_atomExpression1311 = new BitSet(new long[]{0x0000000000200002L});
    public static final BitSet FOLLOW_21_in_atomExpression1317 = new BitSet(new long[]{0x0002388004656500L});
    public static final BitSet FOLLOW_expressionList_in_atomExpression1324 = new BitSet(new long[]{0x0000000000400000L});
    public static final BitSet FOLLOW_22_in_atomExpression1328 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_39_in_atomExpression1353 = new BitSet(new long[]{0x0000000080000400L});
    public static final BitSet FOLLOW_propertyAccess_in_atomExpression1359 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_31_in_propertyAccess1386 = new BitSet(new long[]{0x0000000080000400L});
    public static final BitSet FOLLOW_IDENTIFIER_in_propertyAccess1398 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_expression_in_expressionList1429 = new BitSet(new long[]{0x0000000002000002L});
    public static final BitSet FOLLOW_25_in_expressionList1437 = new BitSet(new long[]{0x0002388004256500L});
    public static final BitSet FOLLOW_expression_in_expressionList1443 = new BitSet(new long[]{0x0000000002000002L});
    public static final BitSet FOLLOW_45_in_fieldList1471 = new BitSet(new long[]{0x0002388004256500L});
    public static final BitSet FOLLOW_orExpression_in_fieldList1478 = new BitSet(new long[]{0x0000000080000030L});
    public static final BitSet FOLLOW_ASC_in_fieldList1485 = new BitSet(new long[]{0x0001000002000000L});
    public static final BitSet FOLLOW_DESC_in_fieldList1504 = new BitSet(new long[]{0x0001000002000000L});
    public static final BitSet FOLLOW_31_in_fieldList1522 = new BitSet(new long[]{0x0002388004256500L});
    public static final BitSet FOLLOW_expression_in_fieldList1528 = new BitSet(new long[]{0x0001000002000000L});
    public static final BitSet FOLLOW_25_in_fieldList1540 = new BitSet(new long[]{0x0002388004256500L});
    public static final BitSet FOLLOW_orExpression_in_fieldList1546 = new BitSet(new long[]{0x0000000080000030L});
    public static final BitSet FOLLOW_ASC_in_fieldList1553 = new BitSet(new long[]{0x0001000002000000L});
    public static final BitSet FOLLOW_DESC_in_fieldList1567 = new BitSet(new long[]{0x0001000002000000L});
    public static final BitSet FOLLOW_31_in_fieldList1579 = new BitSet(new long[]{0x0002388004256500L});
    public static final BitSet FOLLOW_expression_in_fieldList1585 = new BitSet(new long[]{0x0001000002000000L});
    public static final BitSet FOLLOW_48_in_fieldList1599 = new BitSet(new long[]{0x0000000000000002L});

}