package org.aspect.core.aql.codegenerators.sql.sqlserver;

import java.util.List;

import org.aspect.core.aql.codegenerators.sql.ExpressionListCommand;
import org.aspect.core.aql.codegenerators.sql.ExternalFunctionStandard;

public class TopExternalFunctionCommand extends ExternalFunctionStandard {
    @Override
    public StringBuilder toCode(ExpressionListCommand args, List<String> argsCode) {
    	return code.append("SELECT TOP ").append(argsCode.get(1)).append(" ").append(tableName).append(".* FROM (")
    			   .append(argsCode.get(0)).append(")").append(tableName);
    }
}
