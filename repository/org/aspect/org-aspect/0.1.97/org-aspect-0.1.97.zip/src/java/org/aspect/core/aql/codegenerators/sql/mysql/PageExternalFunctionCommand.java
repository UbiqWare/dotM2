package org.aspect.core.aql.codegenerators.sql.mysql;

import java.util.List;

import org.aspect.core.aql.codegenerators.sql.ExpressionListCommand;
import org.aspect.core.aql.codegenerators.sql.ExternalFunctionStandard;

// Info in -> http://www.slideshare.net/slideshow/view?login=Eweaver&preview=no&slideid=1&title=efficient-pagination-using-mysql
public class PageExternalFunctionCommand extends ExternalFunctionStandard {
    @Override
    public StringBuilder toCode(ExpressionListCommand args, List<String> argsCode) {
    	// TODO Get ".id" from metadata
        String orderBy = " ORDER BY " + tableName + ".id";
        // If the criteria is specified, we include it
        if (argsCode.size() == 4) {
            orderBy = " ORDER BY " + argsCode.get(3).trim();
        }
        //
        code.append("SELECT ").append(tableName).append(".* FROM (").append(argsCode.get(0).trim()).append( ") ").append(tableName)
        	.append(orderBy).append(" LIMIT ").append(argsCode.get(1).trim()).append(", ").append(argsCode.get(2).trim());
        //
        return code;    
    }

}

