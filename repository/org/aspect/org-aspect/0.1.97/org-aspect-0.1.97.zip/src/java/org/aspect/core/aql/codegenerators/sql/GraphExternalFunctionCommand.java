package org.aspect.core.aql.codegenerators.sql;

import java.util.List;

public class GraphExternalFunctionCommand extends ExternalFunctionStandard {
    boolean graphRequiredCopy;
    
    @Override
    public void onBeforeLeftToCode() {
        graphRequiredCopy = functionCommand.codeGenerator.getGraphRequired();
        functionCommand.codeGenerator.setGraphRequired(true);
    }

    @Override
    public void onAfterToCode() {
        functionCommand.codeGenerator.setGraphRequired(graphRequiredCopy);
    }
	
	
    @Override
    public StringBuilder toCode(ExpressionListCommand args, List<String> argsCode) {
    	return code.append(argsCode.get(0));
    }

}
