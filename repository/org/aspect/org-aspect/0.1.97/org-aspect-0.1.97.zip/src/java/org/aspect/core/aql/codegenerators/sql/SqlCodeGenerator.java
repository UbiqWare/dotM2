package org.aspect.core.aql.codegenerators.sql;

import java.util.Stack;

import org.aspect.core.aql.SymbolTable;
import org.aspect.core.aql.codegenerators.CodeGenerator;
import org.aspect.core.aql.expressions.*;
import org.aspect.core.loaders.DomainClassDefaultLoader;

public class SqlCodeGenerator extends CodeGenerator {

	public static final String H2 			= "H2";
	public static final String HSQL 		= "HSQL";
	public static final String DB2 			= "H2";
	public static final String MYSQL 		= "MYSQL";
	public static final String MS_SQL 		= "MS_SQL";
	public static final String ORACLE 		= "ORACLE";
	public static final String POSTGRESQL 	= "POSTGRESQL";
    public static final String GRAPH_REQUIRED_ID = "$$graph_required$$";

    public Stack<Command> commandStack = new Stack<Command>();
    StringBuilder code;
    private Expression expression;
    private boolean aspectFilterGeneration = false;
    private SymbolTable symbolTable;
    private Object engine = null;
    private int tableId = 0;

    public SqlCodeGenerator(SymbolTable symbolTable) {
    	init(symbolTable);
    }

    /**/
    @Override
    public void buildBuiltinTypes() {
    	DomainClassDefaultLoader defaultLoader = new DomainClassDefaultLoader(getSymbolTable());
    	defaultLoader.buildBuiltinTypes();
    }
    
	@Override
	public CodeGenerator init(SymbolTable symbolTable) {
		//
		setSymbolTable(symbolTable);
        // TODO: move
        addExternalFunctions();
        // 
        setGraphRequired(false);
        //
        return this;
	}

	@Override
    public StringBuilder toCode() throws Exception {
		// Creating buffer for returning code
		code = new StringBuilder();
		// Reseting counter for tablename
		resetTableId();
    	// All the expressions are expanded
    	expression.expand();
        // Recursive call in order to generate all the SqlCode 
        toCodeRecursive(expression, null);
        // returning code buffer
        return code;
    }    

    private Expression getExpressionDependingOnGenerationState(Object expressionObject) {
        Expression expression = (Expression)expressionObject;
        // Expression substitutions
        if (getAspectFilterGeneration()) {
            if (expression instanceof PropertyAccess) {
                expression = new PropertyAccessForAspectFilter(expression);
            //} else if (expression instanceof ExternalVariableAccess) {
            //    expression = new ExternalVariableAccessForAspectFilter(expression);
            }
        }
        return expression;
    }

    Command toCodeRecursive(Object expressionObject, Command parentCommand) throws Exception {
    	// If expression is null, we've reached a terminal. We return
        if (!(expressionObject instanceof Expression)) return null;
        Expression expression = getExpressionDependingOnGenerationState(expressionObject);
    	Command command = null;
        try {
            // A right command is instantiated according to the expression. Injection is made
        	command = Command.createCommandFromExpression(expression);
        	//
            command.parent = parentCommand;
            command.setCodeGenerator(this);
            // notify OnBeforeLeftToCode event
            command.onBeforeLeftToCode();
            // Left command is treated
            command.left = toCodeRecursive(expression.leftExpression, command);
            // notify OnBeforeRightToCode event
            command.onBeforeRightToCode();
            // Right command is treated
            command.right = toCodeRecursive(expression.rightExpression, command);
            // Current command code is calculated once left has been treated
            command.toCode();
            // If it's a final node, code is added to the code generator
            if (command.parent == null) {
                addCode(command.code);
            }
            // notify OnAfterToCode event
            command.onAfterToCode();
        } catch (Exception e) {
        	throw e;
        }
        //
        return command;
    }
    
    public void addCode(String codeToAdd) {
    	code.append(codeToAdd);
    }

    public void addCode(StringBuilder codeToAdd) {
    	code.append(codeToAdd);
    }


    @Override
    public void setSymbolTable(SymbolTable value) {
        this.symbolTable = value;
    }

    @Override
    public SymbolTable getSymbolTable() {
        return symbolTable;
    }

    @Override
    public void setExpression(Expression value) {
    	this.expression = value;
    }

	@Override
    public Expression getExpression() {
    	return expression;
    }

	@Override
    public void setAspectFilterGeneration(boolean aspectFilterGeneration) {
		this.aspectFilterGeneration = aspectFilterGeneration;
	}

	@Override
    public boolean getAspectFilterGeneration() {
		return aspectFilterGeneration;
	}

    //
	@Override
    public void setEngine(Object engine) {
    	this.engine = engine;
    }
    //
	@Override
    public Object getEngine() {
    	return engine;
    }

	//
	public final static String rootNameSpace = "org.aspect.core.aql.codegenerators.sql."; 
    
    public void addExternalFunctions() {
    	// TODO make this add configurable depending on DB source: SqlServer, MySql, H2, Oracle ...
    	symbolTable.setFunction("top", 			rootNameSpace + "TopExternalFunctionCommand");
    	symbolTable.setFunction("count", 		rootNameSpace + "ScalarCountExternalFunctionCommand");
    	symbolTable.setFunction("sum", 			rootNameSpace + "ScalarSumExternalFunctionCommand");
    	symbolTable.setFunction("avg", 			rootNameSpace + "ScalarAvgExternalFunctionCommand");
    	symbolTable.setFunction("min", 			rootNameSpace + "ScalarMinExternalFunctionCommand");
    	symbolTable.setFunction("max", 			rootNameSpace + "ScalarMaxExternalFunctionCommand");
        symbolTable.setFunction("in", 			rootNameSpace + "InExternalFunctionCommand");
        symbolTable.setFunction("isnull", 		rootNameSpace + "IsNullExternalFunctionCommand");
        symbolTable.setFunction("if", 			rootNameSpace + "IfExternalFunctionCommand");
        symbolTable.setFunction("union", 		rootNameSpace + "UnionExternalFunctionCommand");
        symbolTable.setFunction("select", 		rootNameSpace + "SelectExternalFunctionCommand");
        symbolTable.setFunction("inset", 		rootNameSpace + "InSetExternalFunctionCommand");
        symbolTable.setFunction("orderby", 		rootNameSpace + "OrderByExternalFunctionCommand");
        symbolTable.setFunction("group", 		rootNameSpace + "GroupExternalFunctionCommand");
        symbolTable.setFunction("exist", 		rootNameSpace + "ExistExternalFunctionCommand");
        symbolTable.setFunction("graph", 		rootNameSpace + "GraphExternalFunctionCommand");
        symbolTable.setFunction("a", 			rootNameSpace + "AspectExternalFunctionCommand");
        symbolTable.setFunction("aspect", 		rootNameSpace + "AspectExternalFunctionCommand");
        symbolTable.setFunction("aspects", 		rootNameSpace + "AspectsExternalFunctionCommand");
        symbolTable.setFunction("groupBy", 		rootNameSpace + "GroupByExternalFunctionCommand");
        symbolTable.setFunction("groupby", 		rootNameSpace + "GroupByExternalFunctionCommand");
    	symbolTable.setFunction("contextcount", rootNameSpace + "ContextCountExternalFunctionCommand");
    	symbolTable.setFunction("contextsum", 	rootNameSpace + "ContextSumExternalFunctionCommand");
    	// Just for MySQL so far. 23/10/2015
    	symbolTable.setFunction("contextbitOr",		rootNameSpace + "ContextBitOrExternalFunctionCommand");
    	symbolTable.setFunction("contextbitAnd", 	rootNameSpace + "ContextBitAndExternalFunctionCommand");
    	symbolTable.setFunction("contextbitXor", 	rootNameSpace + "ContextBitXorExternalFunctionCommand");
    	symbolTable.setFunction("contextbitor",		rootNameSpace + "ContextBitOrExternalFunctionCommand");
    	symbolTable.setFunction("contextbitand", 	rootNameSpace + "ContextBitAndExternalFunctionCommand");
    	symbolTable.setFunction("contextbitxor", 	rootNameSpace + "ContextBitXorExternalFunctionCommand");
        // TODO: Pending of being implemented
    	symbolTable.setFunction("contextmin", rootNameSpace + "ContextMinExternalFunctionCommand");
    	symbolTable.setFunction("contextmax", rootNameSpace + "ContextMaxExternalFunctionCommand");
    	symbolTable.setFunction("contextavg", rootNameSpace + "ContextAvgExternalFunctionCommand");
   	    // TODO: Move this logic/responsability
    	String target = symbolTable.getTargetPersistenceEngineTypeName();
    	if (target.equals(H2)) {
            symbolTable.setFunction("page", rootNameSpace + "h2.PageExternalFunctionCommand");
    	} else if (target.equals(MS_SQL)) {
        	symbolTable.setFunction("top", 	rootNameSpace + "sqlserver.TopExternalFunctionCommand");
            symbolTable.setFunction("page", rootNameSpace + "sqlserver.PageExternalFunctionCommand");
    	} else if (target.equals(MYSQL)) {
            symbolTable.setFunction("page", rootNameSpace + "mysql.PageExternalFunctionCommand");
    	} else {
            symbolTable.setFunction("page", rootNameSpace + "h2.PageExternalFunctionCommand");
    	}
    }
	
    void setGraphRequired(Boolean value) {
        symbolTable.add(GRAPH_REQUIRED_ID, value);
    }
    
    Boolean getGraphRequired() {
        return (Boolean)symbolTable.get(GRAPH_REQUIRED_ID);
    }

    public String getNewTableId() {
        this.tableId++;
        return "T" + this.tableId;
    }
    
    public void resetTableId() {
    	this.tableId = 0;
    }
    
    Command peekCommandContext(int level) {
        return commandStack.get(commandStack.size() - 1 - level);
    }

    Command peekCommandContext() {
        return peekCommandContext(0);
    }
    
    Command tryCommandContext(int level) {
        if (commandStack.size() > level)
            return peekCommandContext(level);
        else
            return null;
    }
    
    void openCommandContext(Command command) { 
    	commandStack.push(command); 
    }
    
    Command closeCommandContext() { 
    	return commandStack.pop(); 
    }

    int getContextLevel(Command target) {
		int level = 0;
		Command current = peekCommandContext(level);
		while (current != target) {
			current = peekCommandContext(++level);
		}
		return level;
    }
    
    Command peekRelationAccessCommand(int level) {
        Command command = peekCommandContext(level);
        int byRefCount = 0;
        boolean exit = false;
        do {
            Command commandCandidate = command.getRelationAccess();
            if (command == commandCandidate) {
                exit = true;
            } else {
                if (commandCandidate != null) {
                    command = commandCandidate;
                    exit = true;
                } else {
                    if (command != null) {
                        command = command.parent;
                        if (command != null)
                        	byRefCount += command.isReferenceAccess() ? 1 : 0;
                    }
                }
            }
        } while (command != null && !exit);
        if (command != null && byRefCount > 0) command = null;
        return command;
    }

    Command peekEntityTypeCommand() {
        return peekCommandContext(0).getCurrentCommandWithEntityType();
    }

    Command peekEntityTypeCommand(int level) {
        return peekCommandContext(level).getCurrentCommandWithEntityType();
    }
    
    Command peekSymbolTableAccessCommand() {
        return peekCommandContext(0).getCurrentCommandWithSymbolTable();
    }

    Command peekSymbolTableAccessCommand(int level) {
        return peekCommandContext(level).getCurrentCommandWithSymbolTable();
    }
    
    Command peekTableNamedAccessCommand() {
        return peekTableNamedAccessCommand(0);
    }

    Command peekTableNamedAccessCommand(int level) {
        return peekCommandContext(level).getCurrentCommandWithTableName();
    }

    Command peekRelationAccessCommand() {
        return peekRelationAccessCommand(0);
    }
    
}
