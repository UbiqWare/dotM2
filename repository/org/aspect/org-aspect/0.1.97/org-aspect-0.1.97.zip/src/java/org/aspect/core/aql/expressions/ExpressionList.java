package org.aspect.core.aql.expressions;
import java.util.*;

public class ExpressionList extends Expression {

	public ExpressionList() {
        this.text = "expressionList()";
        this.value = "";
        this.leftExpression = this.list;
        this.rightExpression = null;
    }

    List<Expression> list = new ArrayList<Expression>();
    
    public void add(Expression item) {
        if (item == null) return;
        this.list.add(item);
        if (this.list.size() == 1) {
            this.value = item.value;
        } else {
            this.value += ", " + item.value;
        }
    }
    
    public List<Expression> getList() {
        return this.list;
    }

    @Override
    public Expression clone() {
        ExpressionList cloneList = new ExpressionList();
        for (Expression item: this.list)
            cloneList.add(item.clone());
        return cloneList;
    }

	
}
