package org.aspect.core.aql.codegenerators.sql;

import org.aspect.core.aql.codegenerators.sql.entities.SqlPersistentEntityType;

public class MemberAccessByPropertyNameCommand extends MemberAccessCommand {

	@Override
    protected void loadEntityTypeInfo() {
		// We got the EntityType of the property which name is in the right expression
		entityType = parent.left.entityType.getRelationshipByName(expression.leftExpression.toString()).right;
    	// We get the first, reference point, SQLPersistenEntityType
    	if (entityType == null) {
    		throw new RuntimeException("'" + expression.text + "' not found in symbol table");
    	}
    	//
    	firstPET = (SqlPersistentEntityType) entityType.getHierarchyPersistentEntityTypes().get(0);
    	// Assign tableId to all the persistentEntities
    	assignTableIdToPersistentEntities(entityType, persistentEntityNameIdMap);
	}
	
}
