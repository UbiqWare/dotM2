package org.aspect.core.aql.codegenerators;

import org.aspect.core.aql.expressions.Expression;

public interface CodeGeneratorCommand {
	//
	public static final String WORD_SEPARATOR = "_";
	//
    public CodeGeneratorCommand getCurrentCommandWithEntityType();
    //
    public CodeGeneratorCommand getCurrentCommandWithSymbolTable();
    //
    public CodeGeneratorCommand getCurrentCommandWithTableName();
    //
    public CodeGeneratorCommand getRelationAccess();
    //
	public void toCode() throws Exception;
	//
	public void onBeforeLeftToCode();
	//
	public void onBeforeRightToCode();
	//
	public void onAfterToCode();
	//
    public void onBeforeArgToCode(Expression expression, int position);
    //
    public void onAfterArgToCode(CodeGeneratorCommand command, int position);
    //
	public CodeGenerator getCodeGenerator();
	//
	public void setCodeGenerator(CodeGenerator value);
}
