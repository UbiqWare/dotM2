package org.aspect.core.aql.codegenerators.sql.entities;

import org.aspect.core.aql.codegenerators.sql.Command;
import org.aspect.core.aql.entites.PersistentPropertyType;
import org.aspect.core.aql.entites.PropertyFullNameArg;
import org.aspect.core.aql.entites.PropertyType;

public class SqlPersistentPropertyType extends PersistentPropertyType {
	
	public SqlPersistentPropertyType(String name, String alias, String type) {
		super(name, alias, type);
	}

	public SqlPersistentPropertyType(String name, String type) {
		super(name, name, type);
	}
	
	@Override
	public void buildFullName(PropertyFullNameArg args) {
		PropertyType property = args.property;
    	String conventionalPropertyName = Command.getPropertyNameByConvention(property.name);
		if (property.isConstant) {
            args.propertyFullName = args.fixedPrefix + property.persistentEntityName + Command.FIELD_SEPARATOR + conventionalPropertyName;
            args.code.append(property.defaultValue + " " + args.propertyFullName);
		} else if (property.isCalculated) {
            String prefix = args.persistentEntityNameIdMap.get(args.persistentEntity.name) + ".";
            args.propertyFullName = args.fixedPrefix + property.persistentEntityName + Command.FIELD_SEPARATOR + conventionalPropertyName;
           	args.code.append(prefix + args.persistentProperty.name + " " + args.propertyFullName);
        } else if (args.entityTypeRelationship == null) {
        	args.propertyFullName = conventionalPropertyName;
            if (args.persistentProperty.name != args.persistentEntity.id.name || args.treatIdAsOtherProperties) {
        		args.propertyFullName = args.fixedPrefix + args.persistentEntity.name + Command.FIELD_SEPARATOR + conventionalPropertyName;
            }
            if (property.isEmbedded) {
            	String conventionalEmbeddedPropertyName = Command.getPropertyNameByConvention(args.property.embeddedName);
            	args.propertyFullName += Command.EMBEDDED_FIELD_SEPARATOR + conventionalEmbeddedPropertyName;
            }
            String prefix = args.persistentEntityNameIdMap.get(args.persistentEntity.name) + ".";
           	args.code.append(prefix + args.persistentProperty.name + " " + args.propertyFullName);
        } else if (args.entityTypeRelationship != null) {
        	String prefix = args.persistentEntityNameIdMap.get(args.entityTypeRelationship.getFullAliasForLeftPET(args.persistentEntity)) + ".";
        	if (args.persistentProperty.name.equals(args.persistentEntity.id.name)) {
            	args.propertyFullName = args.fixedPrefix + args.entityTypeRelationship.getAliasForLeftPET(args.persistentEntity)
						+ Command.FIELD_SEPARATOR + conventionalPropertyName;
        		args.code.append(prefix).append(args.persistentProperty.name).append(" ").append(args.propertyFullName);
        	} else {
        		args.propertyFullName = args.fixedPrefix + args.entityTypeRelationship.getFullName(args.persistentEntity.alias, conventionalPropertyName);
        		args.code.append(prefix).append(args.persistentProperty.name).append(" ").append(args.propertyFullName);
        	}
        }
	}

	@Override
	public void buildKeyFullName(PropertyFullNameArg args) {
		// TODO review using propertyName instead of persistentProperty.alias
		PropertyType property = args.property;
    	String conventionalPropertyName = Command.getPropertyNameByConvention(property.name);
		//
		if (args.entityTypeRelationship == null)
			args.keyFullName = conventionalPropertyName;
		else
            args.keyFullName = args.entityTypeRelationship.getFullName(args.persistentEntity.alias, conventionalPropertyName);
	}
	
}
