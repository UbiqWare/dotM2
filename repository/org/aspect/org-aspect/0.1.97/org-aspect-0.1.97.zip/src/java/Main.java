import java.io.FileWriter;
import java.io.IOException;

import org.aspect.core.aql.AqlContext;
import org.aspect.core.aql.AqlEngine;
import org.aspect.core.aql.expressions.Expression;


/*

TODO top function for postgresql
TODO nested funcitions for hsql			
TODO add aggregatted sum function...			
			

Resources:
	Command line example: http://www.makestuff.eu/wordpress/quick-start-antlr-tutorial/
	First teset example: http://stackoverflow.com/questions/9789940/antlr-basic-example-in-java

	Grammar compilation
	java -cp C:\Users\Jorge\git\antlr-3.4-complete.jar org.antlr.Tool aql.g

	All java files compilation
	javac -cp .\bin\antlr-3.4-complete.jar *.java

	Executing an example
	java -cp .;.\bin\antlr-3.4-complete.jar TestAQL
	
	
*/

public class Main {

    public static AqlEngine aqlEngine;
    public static AqlContext aqlContext;

    public static void init() {
    	//
    	aqlEngine = new AqlEngine();
    	aqlContext = aqlEngine.aqlContext;
		// It's added all the external variables needed code generation
		addExternalVariables();
		//
		aqlEngine.buildBuiltinTypes();
		//
		addEntitiesByQuery();
		//
		addFunctionsByQuery();
    }

	public static void addExternalVariables() {
		aqlContext.setVariable(AqlContext.USER_ID, "1");
		aqlContext.setVariable("myId", "10");
		aqlContext.setVariable("myName", "'j'");
    }
    
	private static void addEntitiesByQuery() {
    	aqlEngine.addEntityByQuery("lightIssue", "select(issue, {'id':@id, 'summary':@summary})");
    	aqlEngine.addEntityByQuery("extraLightIssue", "select(lightIssue, {'id':@id})");
    	aqlEngine.addEntityByQuery("workforce", "aspect(issue, 'workforce')");
	}

    private static void addFunctionsByQuery() {
    	aqlEngine.setFunctionByQuery("issueById($id)", "issue[@id=$id]");
    	aqlEngine.setFunctionByQuery("workforceByName($name)", "workforce[@workforce[@authorName='%' + $name + '%']]");
    	//aqlEngine.setFunctionByQuery("workforceByName($name)", "aspect(issue, 'workforce')[@workforce[@authorName='%' + $name + '%']]");
	}
	
    private static void addInnerAspect(String innerAspectName) {
        aqlContext.addInnerAspect(innerAspectName);
    }
    
    
    /*
    public static void testDemo4Diego() {
    	//
    	testAQLHaveTo("issue");
    	testAQLHaveTo("issue[@id = 10000]");
    	testAQLHaveTo("issue[@id >= 10000 && @summary =~ '%Test%']");
    	//
    	testAQLHaveTo("issue[@project[@pname =~ '%Test%']]");
    	//
    	testAQLHaveTo("issue->issue");
    	testAQLHaveTo("issue[@id=10000]->issue");
    	testAQLHaveTo("issue[@id=10000]->issue[@summary =~ '%Sub%']");
    	//
    	testAQLHaveTo("issue->issue[role()='jira_subtask_link']");
    	//
    	testAQLHaveTo("issue[exist(issue)]");
    	testAQLHaveTo("issue[exist(issue[child()])]");
    	//
		testAQLHaveTo("select(issue, {'id':@id, 'name':@summary})");
    	testAQLHaveTo("count(issue, @id)");
    	testAQLHaveTo("top(issue, 1)");
    	testAQLHaveTo("orderby(issue, {@id DESC})");
		testAQLHaveTo("groupBy(issue, @summary, {'summary': @summary})");
		testAQLHaveTo("groupBy(issue, @summary, {'summary': @summary, 'counter': count(@summary)})");
    	testAQLHaveTo("page(issue, 0, 2)");
    	testAQLHaveTo("top(top(issue, 2), 1)"); 
    	testAQLHaveTo("page(orderby(top(issue, 2), {@id DESC}), 0, 2)");
    	//
    	testAQLHaveTo("aspect(issue, 'workforce')");
    	testAQLHaveTo("a(issue, 'workforce')");
    	testAQLHaveTo("a(issue, 'workforce')[@workforce[@authorName='admin']]");
    	testAQLHaveTo("a(issue, 'workforce')[@workforce[@timeWorked=3600]]");
    	
    	//aqlEngine.addEntityByQuery("lightIssue", "select(issue, {'id':@id, 'name':@summary})");
    	//aqlEngine.addEntityByQuery("workforce", "aspect(issue, 'workforce')");

		testAQLHaveTo("lightIssue");
		testAQLHaveTo("extraLightIssue");
		testAQLHaveTo("lightIssue[@id=10000]");
		testAQLHaveTo("extraLightIssue[@id=10000]");
		testAQLHaveTo("workforce");
		testAQLHaveTo("workforce[@id=10000]");
		testAQLHaveTo("groupBy(workforce, @projectId, {'projectId': @projectId, 'hours': count(@workforce[@timeWorked])})");
		
    	//aqlEngine.setFunctionByQuery("issueById($id)", "issue[@id=$id]");
    	//aqlEngine.setFunctionByQuery("workforceByName($name)", "workforce[@workforce[@authorName='%' + $myName + '%']]");

		testAQLHaveTo("issueById(10000)");
		testAQLHaveTo("workforceByName('admin')");
    }
    
	private static void testsAQLForJira() {
    	// Start
		testAQLHaveTo("start_Test");
		
		testDemo4Diego();

		testAQLHaveTo("extraLightIssue");
		testAQLHaveTo("groupBy(workforce, @projectId, {'projectId': @projectId, 'hours': sum(@workforce[@timeWorked]) / 3600})");
    	testAQLHaveTo("issue->issue[role() > '']");
		testAQLHaveTo("lightIssue[@id=10000]");
		testAQLHaveTo("lightIssue[@id=1 && @summary=~'%sam%']");

		// Recheck -> for postgresql, hsql. There must be a problem with its sintax
    	testAQLHaveTo("top(top(issue, 2), 1)"); 
    	testAQLHaveTo("page(issue, 0, 2)");
		
		testAQLHaveTo("aspect(issue, 'workforce')[@workforce[@authorName='%' + $myName + '%']]");
		testAQLHaveTo("workforceByName('Nacho')");
		
		testAQLHaveTo("workforce[@workforce[@authorName='%' + 'j' + '%']]");
		testAQLHaveTo("workforce[@workforce[@authorName='%' + $myName + '%']]");
		
		testAQLHaveTo("workforce");
		testAQLHaveTo("workforceByName('Nacho')");
		testAQLHaveTo("issueById(1)");

		testAQLHaveTo("issue[@id=$myId]");
		
		testAQLHaveTo("groupBy(issue, @id, {'id': @id})");
		testAQLHaveTo("groupBy(issue, @id, {'id': @id, 'count': count(@id)})");
		testAQLHaveTo("groupBy(issue, @id * 2, {'id': @id * 2})");
		testAQLHaveTo("groupBy(issue, @id * 2, {'id': @id})");
		testAQLHaveTo("groupBy(issue, @summary, {'summary': @summary})");
		testAQLHaveTo("groupBy(issue, @summary, {'summary': @summary, 'count': count(@summary)})");
		testAQLHaveTo("groupBy(issue, @summary + '-text', {'summary': @summary + '-text', 'count': count(@summary)})");

		testAQLHaveTo("groupBy(issue, @id, @summary, {'id': @id, 'summary': @summary, 'count': count(@id)})");
		
		// funciones agregadas: count, sum, min, max, avg
		
		
		testAQLHaveTo("lightIssue");

		testAQLHaveTo("lightIssue");
		testAQLHaveTo("extraLightIssue");
		testAQLHaveTo("lightIssue[@id=1]");
		testAQLHaveTo("lightIssue[@id=1 && @summary=~'%sam%']");

		testAQLHaveTo("select(issue, {'id':@id, 'name':@summary})");
    	testAQLHaveTo("a(issue, 'workforce')[@workforce[@authorName='nacho']]");
		
		
    	testAQLHaveTo("aspect(issue, 'workforce')");
    	testAQLHaveTo("a(issue, 'workforce')");
    	// TODO error when accessing 
    	testAQLHaveTo("a(issue, 'workforce')[@workforce[@authorName='nacho']]");
    	//
    	//testAQLHaveTo("a(issue, 'workforce')[@workforce[@author='nacho']]");
		
    	testAQLHaveTo("issue");
    	testAQLHaveTo("issue[@id = 10000]");
    	testAQLHaveTo("issue[@id >= 10000 && @summary =~ '%scrum%']");
    	testAQLHaveTo("issue[@project[@pname =~ '%Scrum%']]");
    	testAQLHaveTo("issue.issue");
    	testAQLHaveTo("issue->issue");
    	testAQLHaveTo("issue[@id=10005]->issue[@summary =~ '%sample%']");
    	testAQLHaveTo("issue[exist(issue)]");
    	testAQLHaveTo("issue[exist(issue[child()])]");

    	
    	// Add a "constant typeId" to all entities that don't provide one
    	//testAQLHaveTo("issue.@project");
		
    	// Finish
		testAQLHaveTo("finish_Test");
	}
    */
    
    private static void haveToTests() {
    	// Start
		testAQLHaveTo("start_Test");
		
		// New functionality


		// Testing
		//testAQLHaveTo("entity[@id=3]->entity[@id=2]->entity[@id=1]");
		//testAQLHaveTo("entity[@id=4]->entity[@id=3]->entity[@id=2]->entity[@id=1]");
		//testAQLHaveTo("entity[role()='normal']->entity");
    	//testAQLHaveTo("entity[exist(entity)]");

		
        // Inner Aspects
        //testAQLHaveTo("entity");
        //addInnerAspect("security");
        //testAQLHaveTo("entity");
        
    	// Debuging
		//testAQLHaveTo(".");

		// Pending
    	//testAQLHaveTo("orderby(entity->entity, {@dateCreated DESC})");
    	//testAQLHaveTo("entity[inset(entity->entity, @id, @::id)]");
		
    	// OK
		testAQLHaveTo("entity[exist(entity) && exist(entity)]");
    	testAQLHaveTo("aspects(entity, 'relationship')");
    	testAQLHaveTo("entity.@type)");
    	testAQLHaveTo("entity.@type[@id = 1]");
    	testAQLHaveTo("entity[@id = 1].@type");
    	testAQLHaveTo("entity[@id = 1].@type[@id = 2]");
    	testAQLHaveTo("entity.@type.@type");
    	testAQLHaveTo("entity[@id = 1].@type[@id = 2].@type[@id = 3]");

    	// Final test
    	testAQLHaveTo("1");
    	testAQLHaveTo("2 * 3");
    	testAQLHaveTo("2 * 3 + 4");
    	testAQLHaveTo("entity");
    	testAQLHaveTo("entity[@id=100]");
    	testAQLHaveTo("entity[@name='my name']");
    	testAQLHaveTo("entity[@typeId=1]");
    	testAQLHaveTo("entity[@type[@id=2]]");
    	testAQLHaveTo("entity[isnull(@typeId)]");
		testAQLHaveTo("entity[@id != 1 && @name = 'John']");
    	testAQLHaveTo("entity[inset(entity[isnull(@typeId)], @id, @::typeId)]");

    	
		testAQLHaveTo("entity[@id > 1]");
		testAQLHaveTo("entity[@id >= 1]");
		testAQLHaveTo("entity[@id < 1]");
		testAQLHaveTo("entity[@id <= 1]");
		testAQLHaveTo("entity[@id != 1]");
		testAQLHaveTo("entity[(@id || 1) = 1]");
		testAQLHaveTo("entity[(@id && 1) = 1]");
		testAQLHaveTo("entity[(@id | 1) = 1]");
		testAQLHaveTo("entity[(@id & 1) = 1]");
		testAQLHaveTo("entity[(@id ^ 1) = 1]");
		testAQLHaveTo("entity[@id = ~1]");
		testAQLHaveTo("entity[~@id = 1]");
		
		testAQLHaveTo("entity[count(@id)]");
		testAQLHaveTo("entity[sum(@id)]");
		//testAQLHaveTo("entity[avg(@id)]");
		//testAQLHaveTo("entity[min(@id)]");
		//testAQLHaveTo("entity[max(@id)]");
		testAQLHaveTo("entity[bitOr(@id)]");
		testAQLHaveTo("entity[bitor(@id)]");
		testAQLHaveTo("entity[bitAnd(@id)]");
		testAQLHaveTo("entity[bitand(@id)]");
		testAQLHaveTo("entity[bitXor(@id)]");
		testAQLHaveTo("entity[bitxor(@id)]");		
		
		testAQLHaveTo("count(entity, @id)");
		testAQLHaveTo("sum(entity, @id)");
		testAQLHaveTo("avg(entity, @id)");
		testAQLHaveTo("min(entity, @id)");
		testAQLHaveTo("max(entity, @id)");

		
    	testAQLHaveTo("type");
    	testAQLHaveTo("aspect");
		testAQLHaveTo("role");
		
    	testAQLHaveTo("type[@id=1]");
    	testAQLHaveTo("type[isnull(@typeId)]");
    	testAQLHaveTo("type[@name='my name']");
    	testAQLHaveTo("type[@localName='my local name']");
    	
    	testAQLHaveTo("entity.entity");
		testAQLHaveTo("(entity)[parent()].entity");
    	testAQLHaveTo("entity->entity");
    	testAQLHaveTo("(entity)[child()].entity");
    	testAQLHaveTo("entity<-entity");
    	testAQLHaveTo("entity->entity[@:relationship[@role[@id=1]]]");
    	testAQLHaveTo("entity->entity[@:relationship[@role[@typeId=1]]]");
    	testAQLHaveTo("entity->entity[@:relationship[@role[@name='my name']]]");
    	testAQLHaveTo("entity->entity[@:relationship[@role[@propagatesSecurity=true]]]");
    	testAQLHaveTo("(entity->entity)[@relationship[@role[@propagatesSecurity=true]]]");

    	testAQLHaveTo("entity[@id=1]<-entity");
    	
		testAQLHaveTo("entity[@id=1]");
		testAQLHaveTo("entity[@id=2]->entity[@id=1]");
		testAQLHaveTo("entity[@id=3]->entity[@id=2]->entity[@id=1]");
		testAQLHaveTo("entity[@id=4]->entity[@id=3]->entity[@id=2]->entity[@id=1]");
    	

    	testAQLHaveTo("a(entity, 'relationship')[@id= 1]");
    	testAQLHaveTo("aspect(entity, 'relationship')[@id= 1]");
    	testAQLHaveTo("aspect(Entity[@id=1], 'security')");
    	testAQLHaveTo("aspect(Entity[@id=1], 'relationship')");
    	testAQLHaveTo("aspect(Entity[@id=1], 'relationship')[@id=1]");
    	testAQLHaveTo("aspect(Entity[@id=1], 'relationship')[@name=1]");
    	testAQLHaveTo("aspect(Entity[@id=1], 'relationship')[@type[@id=1]]");
    	testAQLHaveTo("aspect(Entity[@id=1], 'relationship')[@relationship[@leftId=1]]");
    	testAQLHaveTo("aspect(entity->entity, 'security')");
    	testAQLHaveTo("aspect(entity, 'security')[@name=1]");
    	testAQLHaveTo("aspect(entity.entity, 'security')");
    	testAQLHaveTo("aspect(entity.entity, 'security')[@id=1]");
    	testAQLHaveTo("aspect(entity.entity, 'security')[@typeId=1]");
    	testAQLHaveTo("aspect(entity->entity,'security')[@relationship[@role[@propagatesSecurity=true]]]");
    	testAQLHaveTo("aspect(entity->entity, 'security')[@relationship[@role[@propagatesSecurity=true]]]");
    	testAQLHaveTo("aspect(entity, 'security')[ @security[ inset( entity, @id, @::securityEntityId) ] ]");
		testAQLHaveTo("aspect(entity[@id=27]->entity, 'security')[@security[@securityEntityId=31]]");
		testAQLHaveTo("aspect(entity[@id=27]->entity, 'security')[@relationship[@role[@propagatesSecurity=true]]]");
		testAQLHaveTo("aspect(entity[@id=27]->entity, 'security')[@security[@securityEntityId=31] && @relationship[@role[@propagatesSecurity=true]]]");
		testAQLHaveTo("aspect(entity[@id=27]->entity[@:relationship[@role[@propagatesSecurity=true]]], 'security')[@security[@securityEntityId=31]]");
		testAQLHaveTo("aspect(Entity, 'security')[ @security[ inset( entity, @id, @:::security[@securityEntityId]) ] ]");
		testAQLHaveTo("aspect(Entity[@id=1], 'security')[ @security[ inset( entity[@id=2]<-entity, @id, @:::security[@securityEntityId]) ] ]");
    	testAQLHaveTo("aspect(Entity[@id=1], 'security')[ @security[ inset( entity[@id=2]<-entity, @id, @::securityEntityId) ] ]");

    	testAQLHaveTo("aspect(entity, 'security', 'relationship')[@id= 1]");
    	testAQLHaveTo("aspect(entity, 'security', 'relationship')");
    	testAQLHaveTo("aspect(Entity[@id=1], 'security', 'relationship')");
    	testAQLHaveTo("aspect(Entity[@id=1], 'security', 'relationship')[@id=1]");
    	testAQLHaveTo("aspect(Entity[@id=1], 'security', 'relationship')[@name=1]");
    	testAQLHaveTo("aspect(Entity[@id=1], 'security', 'relationship')[@type[@id=1]]");
    	testAQLHaveTo("aspect(Entity[@id=1], 'security', 'relationship')[@relationship[@leftId=1]]");
    	testAQLHaveTo("aspect(entity->entity, 'security', 'relationship')");
    	testAQLHaveTo("aspect(entity, 'security', 'relationship')[@name=1]");
    	testAQLHaveTo("aspect(entity.entity, 'security', 'relationship')");
    	testAQLHaveTo("aspect(entity.entity, 'security', 'relationship')[@id=1]");
    	testAQLHaveTo("aspect(entity.entity, 'security', 'relationship')[@typeId=1]");
    	testAQLHaveTo("aspect(entity->entity,'security', 'relationship')[@relationship[@role[@propagatesSecurity=true]]]");
    	testAQLHaveTo("aspect(entity->entity, 'security', 'relationship')[@relationship[@role[@propagatesSecurity=true]]]");
    	testAQLHaveTo("aspect(entity, 'security', 'relationship')[ @security[ inset( entity, @id, @::securityEntityId) ] ]");
		testAQLHaveTo("aspect(entity[@id=27]->entity, 'security', 'relationship')[@security[@securityEntityId=31]]");
		testAQLHaveTo("aspect(entity[@id=27]->entity, 'security', 'relationship')[@relationship[@role[@propagatesSecurity=true]]]");
		testAQLHaveTo("aspect(entity[@id=27]->entity, 'security', 'relationship')[@security[@securityEntityId=31] && @relationship[@role[@propagatesSecurity=true]]]");
		testAQLHaveTo("aspect(entity[@id=27]->entity[@:relationship[@role[@propagatesSecurity=true]]], 'security', 'relationship')[@security[@securityEntityId=31]]");
		testAQLHaveTo("aspect(Entity, 'security', 'relationship')[ @security[ inset( entity, @id, @:::security[@securityEntityId]) ] ]");
		testAQLHaveTo("aspect(Entity[@id=1], 'security', 'relationship')[ @security[ inset( entity[@id=2]<-entity, @id, @:::security[@securityEntityId]) ] ]");
    	testAQLHaveTo("aspect(Entity[@id=1], 'security', 'relationship')[ @security[ inset( entity[@id=2]<-entity, @id, @::securityEntityId) ] ]");

    	testAQLHaveTo("aspect(aspect(entity, 'relationship'), 'security')");
    	
    	testAQLHaveTo("top(entity->entity, 1)");
    	testAQLHaveTo("top(entity->entity, 1)[@id=1]");
    	testAQLHaveTo("top(entity->entity, 1)[@typeId=1]");
    	testAQLHaveTo("top(entity->entity, 1)[@typeId=1 && @relationship[@role[@propagatesSecurity=true]]]");
    	testAQLHaveTo("entity[@id=27].entity[@:relationship[@role[@propagatesSecurity=true]]]");
    	testAQLHaveTo("entity[@id=27]->entity[@:relationship[@role[@propagatesSecurity=true]]]");
    	testAQLHaveTo("entity[@id=32].entity");

    	testAQLHaveTo("entity[@name = '1'].entity");
    	testAQLHaveTo("entity[@name = '1'].entity[@name = '2']");
    	testAQLHaveTo("entity[role() =~ 'normal'].entity[@name = '2']");
    	testAQLHaveTo("entity[parent()].entity");
    	testAQLHaveTo("entity[child()].entity");
    	testAQLHaveTo("entity.entity[child()]");
    	testAQLHaveTo("page(entity, 0, 10)");
    	
    	testAQLHaveTo("top(entity->entity, 1)[@type[@id=1]]");
    	testAQLHaveTo("top(entity->entity, 1)[@type[@name='my name']]");
    	testAQLHaveTo("top(entity->entity, 1)[@type[@localName='my name']]");
    	testAQLHaveTo("top(top(entity->entity, 1), 1)[@id=1]");
    	testAQLHaveTo("top(top(entity->entity, 1), 1)[@name=1]");
    	testAQLHaveTo("top(top(entity->entity, 1), 1)[@typeId=1]");
    	testAQLHaveTo("top(top(entity->entity, 1), 1)[@type[@id=1]]");
    	testAQLHaveTo("top(top(entity->entity, 1), 1)[@type[@name='my name']]");
    	testAQLHaveTo("top(top(entity->entity, 1), 1)[@type[@localName='my name']]");
    	testAQLHaveTo("entity[@type[@name='my name']]");
    	testAQLHaveTo("top(entity, 1)[@name='my name']");
    	testAQLHaveTo("top(entity->entity, 1)[@name='1']");
    	testAQLHaveTo("top(top(entity->entity, 1), 1)[@name='1']");
    	testAQLHaveTo("top(top(entity, 1), 1)[@name='1']");
    	testAQLHaveTo("top(entity->entity, 1)[@relationship[@leftId=1]]"); 
    	testAQLHaveTo("top(entity->entity, 1)[@right[@name=1]]"); 
    	testAQLHaveTo("entity->entity[@id=1]");
    	testAQLHaveTo("entity->entity[@type[@id=1]]");
    	testAQLHaveTo("entity->entity[@type[@typeId=1]]");
    	testAQLHaveTo("entity->entity[@type[@name='my name']]");
    	testAQLHaveTo("entity->entity[@type[@localName='my name']]");
    	testAQLHaveTo("aspect(entity, 'relationship')[@typeId= 1]");
    	testAQLHaveTo("aspect(entity, 'relationship')[@relationship[@leftId= 1]]");
    	testAQLHaveTo("aspect(entity, 'relationship')[@relationship[@leftId= 1] && @name = 'my name']");
    	testAQLHaveTo("top(entity, 1)");
    	testAQLHaveTo("top(entity, 1)[@id=1]");
    	testAQLHaveTo("top(entity, 1)[@name=1]");
    	testAQLHaveTo("top(entity, 1)[@type[@id=2]]");
    	testAQLHaveTo("top(entity, 1)[@type[@name='my name']]");
    	testAQLHaveTo("top(entity, 1)[@type[@localName='my name']]");
		testAQLHaveTo("(entity)");
    	testAQLHaveTo("(entity)[@id=1]");
    	testAQLHaveTo("(entity)[@typeId=1]");
    	testAQLHaveTo("(entity)[@type[@id=2]]");
    	testAQLHaveTo("(entity)[@type[@name='my name']]");
    	testAQLHaveTo("(entity)[@type[@localName='my name']]");
    	testAQLHaveTo("entity[@type[@localName='my name']]");
    	testAQLHaveTo("entity[@type[@id=2] || @type[@id=3]]");
    	testAQLHaveTo("top(top(entity->entity, 1), 1)");
    	testAQLHaveTo("aspect(entity, 'relationship')");

		testAQLHaveTo("select(entity, {'id':@id, 'name':@description})");
		testAQLHaveTo("select(entity, {'id':@id * 2, 'name':@description})");
		testAQLHaveTo("select(entity, {'id':@id * 2, 'name':@description})[@id=2]");
		testAQLHaveTo("select(entity, {'id':@id * 2, 'name':@description})[@name='my name']");

    	// Group
    	testAQLHaveTo("group(entity, entity, {'id':@id})");
		testAQLHaveTo("group(entity, entity, {'Count':count(@id)})");
    	testAQLHaveTo("group(entity, entity, {'Count':count(@id)}) [@Count > 0]");
		testAQLHaveTo("group(entity, entity, {'Count':count(@id)}) [if(isnull(@Count), 0, @Count) > 0]");
    	testAQLHaveTo("entity[exist(entity)]");
		testAQLHaveTo("entity[@id=2 && exist(entity[@id=1])]");
		testAQLHaveTo("entity[@id=3]->entity[@id=2 && exist(entity[@id=1])]");
		testAQLHaveTo("entity[@id=4]->entity[@id=3]->entity[@id=2 && exist(entity[@id=1])]");
		/* Pending
		testAQLHaveTo("entity[exist(entity) && @id=1 || in(@id, 1)]");
		testAQLHaveTo("entity[exist(entity[child()])]");
		testAQLHaveTo("entity[exist(entity[child()]) && @id=1]");
		testAQLHaveTo("entity[exist(entity[child()]) && @id=1 || in(@id, 1) ]");
		
		testAQLHaveTo("entity[exist(entity)].entity");
		testAQLHaveTo("entity[exist(entity) && @id=1].entity");
		testAQLHaveTo("entity[exist(entity) && !exist(entity)].entity");

		testAQLHaveTo("entity[exist(entity)].entity[@id=2]");
		testAQLHaveTo("entity[exist(entity) && @id=1].entity[@id=2]");
		testAQLHaveTo("entity[exist(entity) && !exist(entity)].entity[@id=2]");

		testAQLHaveTo("entity[exist(entity)].entity[@id=2].entity");
		testAQLHaveTo("entity[exist(entity) && @id=1].entity[@id=2].entity");
		testAQLHaveTo("entity[exist(entity) && !exist(entity)].entity[@id=2].entity");

		testAQLHaveTo("entity[exist(entity)].entity[@id=2 && exist(entity)].entity");
		testAQLHaveTo("entity[exist(entity) && @id=1].entity[@id=2 && exist(entity)].entity");
		testAQLHaveTo("entity[exist(entity) && !exist(entity)].entity[@id=2 && exist(entity)].entity");
		
		// entity[@id=1]->entity[@id=2 && exist(entity[@id=3 && parent()])]
		// Original
		// entity[@id=${job.id}]<-Build->JobForBuild[exist(Platform[@id=${platform.id}] && parent())]
		// Adaptacion
		// entity[@id=1]<-entity[@id=2]->entity[@id=3 && exist(entity[@id=4 && parent()])]
		
		*/
    	
    	
    	
    	// Select
		testAQLHaveTo("select(entity, {'aliasId': @id})[@aliasId=1]");
		testAQLHaveTo("select(entity, {'id': @id, 'name': @description})");
		testAQLHaveTo("select(entity, {'id': @id * 2, 'name': @description})");
		testAQLHaveTo("select(entity, {'id': @id * 2, 'name': @description})[@id=2]");
		testAQLHaveTo("select(entity, {'id': @id * 2, 'name': @description})[@name='my name']");
		testAQLHaveTo("select(entity, {'id': @id * 2, 'name': @description, 'type': @typeId})[@type='1']");
		testAQLHaveTo("select(entity->entity, {'id': @id * 2, 'name': @description, 'type': @typeId, 'propagatesSecurity': @relationship[@role[@propagatesSecurity]]})[@type='my name']");
		testAQLHaveTo("select(entity->entity, {'id': @id * 2, 'name': @description, 'type': @typeId, 'propagatesSecurity': @relationship[@role[@propagatesSecurity]]})[@propagatesSecurity=true]");
		testAQLHaveTo("select(entity->entity, {'id': @id * 2, 'name': @description, 'type': @typeId, 'roleName': @relationship[@role[@name]]})[@roleName='my role name']");
		
		// Graph
    	testAQLHaveTo("graph(entity)");
    	testAQLHaveTo("graph(entity[@id=1])");
    	testAQLHaveTo("graph(entity[@name='my name'])");
    	testAQLHaveTo("graph(entity)[@id=1])");
    	testAQLHaveTo("graph(entity)[@name='my name'])");
    	
    	testAQLHaveTo("graph(entity.entity)");
    	testAQLHaveTo("graph(entity.entity[@id=1])");
    	testAQLHaveTo("graph(entity.entity[@name='my name'])");
    	testAQLHaveTo("graph(entity.entity)[@id=1]");
    	testAQLHaveTo("graph(entity.entity)[@name='my name']");
    	testAQLHaveTo("graph(entity.entity[@id=1])[@relationship[@leftId=2]]");
    	testAQLHaveTo("graph(entity.entity[@name='my name'])[@role[@name='normal']]");
    	testAQLHaveTo("graph(entity.entity[@name='my name'])[@left[@name='left entity']]");

    	testAQLHaveTo("graph(entity->entity)");
    	testAQLHaveTo("graph(entity->entity[@id=1])");
    	testAQLHaveTo("graph(entity->entity[@name='my name'])");
    	testAQLHaveTo("graph(entity->entity)[@id=1]");
    	testAQLHaveTo("graph(entity->entity)[@name='my name']");
    	testAQLHaveTo("graph(entity->entity[@id=1])[@relationship[@leftId=2]]");
    	testAQLHaveTo("graph(entity->entity[@name='my name'])[@role[@name='normal']]");
    	testAQLHaveTo("graph(entity->entity[@name='my name'])[@left[@name='left entity']]");
    	
    	testAQLHaveTo("graph(entity).graph(entity)");
    	testAQLHaveTo("graph(entity).graph(entity[@id=1])");
    	testAQLHaveTo("graph(entity).graph(entity[@name='my name'])");
    	testAQLHaveTo("graph(entity).graph(entity)[@id=1]");
    	testAQLHaveTo("graph(entity).graph(entity)[@name='my name']");
    	testAQLHaveTo("(graph(entity).graph(entity[@id=1]))[@relationship[@leftId=2]]");
    	testAQLHaveTo("(graph(entity).graph(entity[@name='my name']))[@role[@name='normal']]");
    	testAQLHaveTo("(graph(entity).graph(entity[@name='my name']))[@left[@name='left entity']]");

    	testAQLHaveTo("graph(entity.entity).graph(entity)");
    	testAQLHaveTo("graph(entity.entity).graph(entity[@id=1])");
    	testAQLHaveTo("graph(entity.entity).graph(entity[@name='my name'])");
    	testAQLHaveTo("graph(entity.entity).graph(entity)[@id=1]");
    	testAQLHaveTo("graph(entity.entity).graph(entity)[@name='my name']");
    	testAQLHaveTo("(graph(entity.entity).graph(entity[@id=1]))[@relationship[@leftId=2]]");
    	testAQLHaveTo("(graph(entity.entity).graph(entity[@name='my name']))[@role[@name='normal']]");

    	testAQLHaveTo("graph(entity[@id=1].entity[@id=2])[@left[@name='entity2']]");
    	testAQLHaveTo("graph(entity[@id=1].entity[@id=2].entity[@id=3])[@left[@name='entity2']]");
    	testAQLHaveTo("graph(entity[@id=1].entity[@id=2].entity[@id=3])[@left[@left[@name='entity1']]]");
    	testAQLHaveTo("graph(entity[@id=1].entity[@id=2])[@left[@name='entity1']]");
    	testAQLHaveTo("graph(entity[@id=1].entity[@id=2])[@name='entity2']");
    	testAQLHaveTo("graph(entity[@id=1].entity[@id=2].entity[@id=3])");
    	testAQLHaveTo("graph(entity[@id=1].entity[@id=2].entity[@id=3])[@name='entity3']");
    	testAQLHaveTo("graph(entity[@id=1].entity[@id=2].entity[@id=3])[@left[@name='entity22']]");
    	testAQLHaveTo("graph(entity[@id=1].entity[@id=2].entity[@id=3])[@left[@left[@name='entity11']]]");
    	
    	// Group by
    	testAQLHaveTo("orderby(entity->entity, {@name DESC})"); 
    	
    	// Role
		testAQLHaveTo("entity[role()='normal']->entity");

    	// Should fail. Add unit test but checking exception/error
    	testAQLHaveTo("relationship", true);
    	testAQLHaveTo("@relationship", true);
    	testAQLHaveTo("relationship[@leftId = 1]", true);
    	testAQLHaveTo("@relationship[@leftId = 1]", true);
    	testAQLHaveTo("relationshipAspect", true);
    	testAQLHaveTo("securityAspect", true);
		
    	// Finish
		testAQLHaveTo("finish_Test");
		
		/*
		// Pending to test
		testAQLHaveTo("entity[@id=1.0]");
		testAQLHaveTo("entity[@id=true]");
		testAQLHaveTo("entity[@id=false]");
		testAQLHaveTo("entity[@id=$User]");

		testAQLHaveTo("(entity)[(@id=1)]");
		testAQLHaveTo("((entity))[@id=1]");
		testAQLHaveTo("entity[@id=1]");
		testAQLHaveTo("((entity)[@id=1])[@id=2]");

		testAQLHaveTo("entity.entity.entity");
		testAQLHaveTo("entity.entity.entity.entity");
		testAQLHaveTo("entity.entity.entity.entity.entity");

		testAQLHaveTo("entity[@id=1].entity[@id=2]");
		testAQLHaveTo("entity[@id=1].entity[@id=2].entity[@id=3]");
		testAQLHaveTo("entity[@id=1].entity[@id=2].entity[@id=3].entity[@id=4]");
		testAQLHaveTo("entity[@id=1].entity[@id=2].entity[@id=3].entity[@id=4].entity[@id=5]");

		testAQLHaveTo("top(entity, 1).top(entity, 2)");
		testAQLHaveTo("top(entity, 1)[@id=1].top(entity, 2)[@id=2]");
		testAQLHaveTo("(top(entity, 1)[@id=1].top(entity, 2)[@id=2])[@id=3]");

		testAQLHaveTo("count(entity, @id)");
		testAQLHaveTo("sum(entity, @id)");
		testAQLHaveTo("avg(entity, @id)");
		testAQLHaveTo("min(entity, @id)");
		testAQLHaveTo("max(entity, @id)");

		testAQLHaveTo("entity[isnull(@id)]");
		testAQLHaveTo("entity[in(@id, 1, 2)]");
		testAQLHaveTo("entity[if(@id = 1, @id * 2, @id * 3) = 4]");
		testAQLHaveTo("entity[if(@id = 1, @id * 2) = 3]");

		testAQLHaveTo("union(entity[@id=1])");
		testAQLHaveTo("union(entity[@id=1], entity[@id=2])");
		testAQLHaveTo("union(entity[@id=1], entity[@id=2], entity[@id=3])");

		testAQLHaveTo("entity[inset(entity, @id, 1)]");
		testAQLHaveTo("entity[inset(type, @id, @::id)]");

		testAQLHaveTo("orderby(entity, {@id ASC})");
		
		// Pending to be developed
		testAQLHaveTo("distinct(entity)");
    	
		*/
		
    }
    
    private static void aspectFilterTests() {
		//
		String code = "10"; 
		aqlContext.setVariable("externalVariable1", code);
		aqlContext.setVariable("userId", code);
		code = aqlEngine.translateAspectFilter("@property1 = 1");
		code = aqlEngine.translateAspectFilter("@property1 = @property1");
		code = aqlEngine.translateAspectFilter("@property1 = $externalVariable1");
		code = aqlEngine.translateAspectFilter("@property1 > 0");
		code = aqlEngine.translateAspectFilter("@property1 > 1 && @property2 = 1");
		code = aqlEngine.translateAspectFilter("@property1 > 1 && (@property2 = 2 || @property3 = 3)");
		code = aqlEngine.translateAspectFilter("isnull(@property1)");
		code = aqlEngine.translateAspectFilter("bitOr(@permissions & @permissionsMask)");
		code = aqlEngine.translateAspectFilter("sum(if(@permissionEntityId = $userId, @permissions, 0))");
		code = aqlEngine.translateAspectFilter("sum(@owner)");
    }

	private static void testsAQL() {
		aspectFilterTests();
		//
		haveToTests();
	}
    
	public static void main(String[] args) {
		init();
		//testsAQLForJira();
		testsAQL();
	}

    private static void testAQLHaveTo(String aql, boolean exceptionTest) {
		StringBuilder buffer = new StringBuilder();
		boolean notTruncateFile = true;
		//
		if (aql.equals("start_Test")) {
			buffer.append("package itest.org.aspect.core.aql.aqlEngine.h2;\n");
			buffer.append("import spock.lang.*\n");
			buffer.append("import org.aspect.core.aql.AqlContext\n");
			buffer.append("import org.aspect.core.aql.AqlEngine;\n");
			buffer.append("import org.aspect.core.aql.codegenerators.sql.SqlCodeGenerator\n");
			//buffer.append("import org.aspect.AqlService\n");
			buffer.append("class TranslateSpec extends Specification {\n");			
			//buffer.append("\tAqlService aqlService\n");
			buffer.append("\tAqlContext aqlContext\n");
			buffer.append("\tAqlEngine aqlEngine\n");
			buffer.append("\tString response\n");
			buffer.append("\tdef setup() {		\n");
			buffer.append("\t\taqlEngine = new AqlEngine(SqlCodeGenerator.H2)\n");
			buffer.append("\t\taqlEngine.buildBuiltinTypes()\n");
			buffer.append("\t}\n");
			buffer.append("\tdef cleanup() {  }\n");
			notTruncateFile = false;
		} else if (aql.equals("finish_Test")) {
			buffer.append("\t}\n");
		} else {
			//
			buffer.append("\tvoid \"translate(" + aql + ")\"() {\n");
			buffer.append("\t\twhen:\tresponse = aqlEngine.translate(\"" + aql + "\")\n");
			if (exceptionTest) {
				buffer.append("\t\tthen:\tException e = thrown()\n");
			} else {
				String sqlCode = aqlEngine.translate(aql);
				buffer.append("\t\tthen:\tresponse.trim() == \"\"\"" + sqlCode.trim() + "\"\"\"\n");
			}
			buffer.append("\t}\n");
		}
		//
		try {
		    String filename= "testAQLHaveTo.java";
		    FileWriter fw = new FileWriter(filename, notTruncateFile);
		    fw.write(buffer.toString());
		    fw.close();
			System.out.print(buffer.toString());
		} catch(IOException ioe) {
		    System.err.println("IOException: " + ioe.getMessage());
		}    
	}

    private static void testAQLHaveTo(String aql) {
        testAQLHaveTo(aql, false);
    }

}

