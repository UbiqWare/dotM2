package org.aspect.core.aql.expressions;

public class Parent extends Expression {
	
    public Parent() {
    	this.text = "parent()";
    	this.value = text;
    	this.leftExpression = null;
    	this.rightExpression = null;
    }
    
	@Override
    public Expression clone() {
        return new Parent();
    }

}
