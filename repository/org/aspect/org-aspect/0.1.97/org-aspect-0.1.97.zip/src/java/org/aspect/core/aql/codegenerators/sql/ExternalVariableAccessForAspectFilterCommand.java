package org.aspect.core.aql.codegenerators.sql;

public class ExternalVariableAccessForAspectFilterCommand extends Command {
	@Override
	public void toCode() {
		String externalVariableName = expression.leftExpression.toString();
        code.append("$$variableccess:").append(externalVariableName).append("$$");
    }
}
