package org.aspect.core.aql.codegenerators.sql;

import java.util.List;

public class ContextBitAndExternalFunctionCommand extends ExternalFunctionStandardAggregated {
    @Override
    public StringBuilder toCode(ExpressionListCommand args, List<String> argsCode) {
    	return code.append("BIT_AND(").append(argsCode.get(0)).append(")");
    }
}
