package org.aspect.core.aql.expressions;

public class ExternalVariableAccess extends Expression {

    public ExternalVariableAccess(String variableName) {
        this.text = "$" + variableName;
        this.value = this.text;
        this.leftExpression = variableName;
        this.rightExpression = null;
    }

	@Override
    public Expression clone() {
        return new ExternalVariableAccess(leftExpression.toString());
    }
	
}
