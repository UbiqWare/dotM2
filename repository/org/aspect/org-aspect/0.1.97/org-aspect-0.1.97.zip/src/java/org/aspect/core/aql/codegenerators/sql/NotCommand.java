package org.aspect.core.aql.codegenerators.sql;

public class NotCommand extends Command {
	@Override
	public void toCode() {
        code.append("( NOT ").append(left.code).append(")");
    }
}
