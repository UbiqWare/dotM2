package org.aspect.core.aql.codegenerators.sql;

public class ExternalVariableAccessCommand extends Command {
	@Override
	public void toCode() {
		//
		String externalVariableName = expression.leftExpression.toString();
		// Search external variable in SymbolTable context. 
		String externalVariable = null; 
		for (int level = 0; level < codeGenerator.commandStack.size() && externalVariable == null; level++) {
			Command current = codeGenerator.peekCommandContext(level);
			externalVariable = current.symbolTable.getExternalVariable(externalVariableName);
		}
		// If not exists, search on the global symbolTable
		externalVariable = (externalVariable == null) ? codeGenerator.getSymbolTable().getExternalVariable(externalVariableName) : externalVariable; 
		//
        code.append(externalVariable);
    }
}
