package org.aspect.core.aql.expressions;

public class FieldInitialize extends Expression {

    public FieldInitialize(StringLiteral fieldName, Expression expression) {
    	this.text = "fieldInitialize()";
    	this.value = "{" + fieldName.value + ", " + expression.value + "}";
    	this.leftExpression = fieldName;
    	this.rightExpression = expression;
    }
    
	@Override
    public Expression clone() {
        Expression left = (leftExpression instanceof Expression) ? ((Expression)leftExpression).clone() : null;
        Expression right = (rightExpression instanceof Expression) ? ((Expression)rightExpression).clone() : null;
        return new FieldInitialize((StringLiteral)left, right);
    }
	
}
