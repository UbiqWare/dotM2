package org.aspect.core.aql.codegenerators.sql;

public class LTOrEQCommand extends Command {
	@Override
	public void toCode() {
        code.append("(").append(left.code).append(" <= ").append(right.code).append(")");
    }
}
