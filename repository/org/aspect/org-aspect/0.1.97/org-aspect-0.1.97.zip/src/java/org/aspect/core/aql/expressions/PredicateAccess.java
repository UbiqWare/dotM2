package org.aspect.core.aql.expressions;

public class PredicateAccess extends Expression {
	
    public PredicateAccess(Expression predicate) {
    	this.text = "[ ]";
    	this.value = "[" + predicate.value + "]";
    	this.leftExpression = predicate;
    	this.rightExpression = null;
    }

	@Override
    public Expression clone() {
        Expression left = (leftExpression instanceof Expression) ? ((Expression)leftExpression).clone() : null;
        return new PredicateAccess(left);
    }

}
