package org.aspect.core.aql.codegenerators.sql;

public class FieldInitializeCommand extends Command {
    @Override 
    public void toCode() {
        code.append(right.code).append(" ");
    }
}
