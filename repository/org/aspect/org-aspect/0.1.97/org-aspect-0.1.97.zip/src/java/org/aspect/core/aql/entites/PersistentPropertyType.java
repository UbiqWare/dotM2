package org.aspect.core.aql.entites;

public abstract class PersistentPropertyType {
	public String name;
	public String alias;
	public String type;
	public PersistentPropertyType(String name, String alias, String type) {
		this.name = name;
		this.alias = (alias == "" || alias == null) ? name : alias;
		this.type = type;
	}
	
	public void buildFullName(PropertyFullNameArg args) {
       	args.propertyFullName = alias;
	}

	public void buildKeyFullName(PropertyFullNameArg args) {
       	args.keyFullName = alias;
	}
	
}
