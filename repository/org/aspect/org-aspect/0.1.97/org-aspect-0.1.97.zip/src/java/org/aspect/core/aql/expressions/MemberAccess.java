package org.aspect.core.aql.expressions;

public class MemberAccess extends Expression {
	
    public MemberAccess(String member) {
    	this.text = member;
    	this.value = member;
    	this.leftExpression = value;
    	this.rightExpression = null;
    }

    public MemberAccess(String member, PredicateAccess predicate) {
    	this.text = member;
    	this.value = member;
    	this.leftExpression = value;
    	this.rightExpression = predicate;
    }

	@Override
    public Expression clone() {
        Expression right = (rightExpression instanceof PredicateAccess)? ((Expression)rightExpression).clone(): null;
        return new MemberAccess(leftExpression.toString(), (PredicateAccess)right);
    } 

}
