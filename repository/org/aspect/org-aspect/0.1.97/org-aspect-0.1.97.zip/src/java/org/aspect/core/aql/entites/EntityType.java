package org.aspect.core.aql.entites;

import java.util.*;

import org.aspect.core.aql.entites.EntityTypeRelationship;

public class EntityType {
	
	public String 	name;
	public Long 	typeId;
	
	private List<Long> subtypeIds = new ArrayList<Long>();
	public List<Long> getSubtypeIds() {
		return subtypeIds;
	}

	public void addSubtypeId(Long subtypeId) {
		subtypeIds.add(subtypeId);
	}

	public static final Long 	MASTER_TYPE_TYPE_ID 	= null; 	
	public static final String 	MASTER_TYPE_TYPE_NAME	= "$$master_type$$"; 	

	public static final String 	ENTITY_TYPE_NAME		= "entity"; 	
	public static final Long	DEFAULT_ENTITY_TYPE_ID	= new Long(0); 	
	
	public static final String 	TYPE_TYPE_NAME			= "type"; 	
	public static final Long	DEFAULT_TYPE_TYPE_ID	= new Long(1); 	
	
	private static HashMap<String, Long> typeNameMap = new HashMap<String, Long>();
	
	static {
		typeNameMap.put(MASTER_TYPE_TYPE_NAME, MASTER_TYPE_TYPE_ID);
		typeNameMap.put(ENTITY_TYPE_NAME, DEFAULT_ENTITY_TYPE_ID);
		typeNameMap.put(TYPE_TYPE_NAME, DEFAULT_TYPE_TYPE_ID);
	}

	public static long getTypeId(String key) {
		return typeNameMap.get(key).longValue();
	}

	public static void setTypeId(String key, long value) {
		typeNameMap.put(key, value);
	}
	
	public boolean isTypeEntity() {
		return this.typeId == getTypeId(ENTITY_TYPE_NAME);
	}

	public boolean isTypeType() {
		return this.typeId == getTypeId(TYPE_TYPE_NAME);
	}
	
	public void init(String name) {
		//
		this.name = name;
		this.typeId = MASTER_TYPE_TYPE_ID;
	}

	public EntityType(String name) {
		init(name);
	}
	

	private List<PropertyType> properties = new ArrayList<PropertyType>();
	private HashMap<String, PropertyType> propertiesMap = new HashMap<String, PropertyType>();

	public List<PropertyType> getProperties() {
		return properties;
	}

	public PropertyType getProperty(String name) {
		return propertiesMap.get(name.toLowerCase());
	}
	
	public void addProperty(PropertyType property) {
		properties.add(property);
		propertiesMap.put(property.name.toLowerCase(), property);
	}

	private List<PersistentEntityType> hierarchyPersistentEntityTypes = new ArrayList<PersistentEntityType>();

	public List<PersistentEntityType> getHierarchyPersistentEntityTypes() {
		return hierarchyPersistentEntityTypes;
	}
	
	public void addHierarchyPersistentEntityType(PersistentEntityType entity) {
		if (entity == null) {
			throw new RuntimeException("entity can't be null");
		}
		hierarchyPersistentEntityTypes.add(entity);
		persistentEntityTypesMap.put(entity.alias.toLowerCase(), entity);
	}

	
	private List<EntityTypeRelationship> relationshipPersistentEntityTypes = new ArrayList<EntityTypeRelationship>();

	public List<EntityTypeRelationship> getPersistentEntityTypeRelationships() {
		return relationshipPersistentEntityTypes;
	}
	
	public void addRelationship(EntityTypeRelationship relationship) {
		//
		relationship.left = this;
		relationshipPersistentEntityTypes.add(relationship);
		//
		for (PersistentEntityType entityPET: relationship.right.getHierarchyPersistentEntityTypes()) {
			//persistentEntityTypesMap.put(relationship.getAliasForLeftPET(entityPET), entityPET);
			persistentEntityTypesMap.put(relationship.getFullAliasForLeftPET(entityPET), entityPET);
		}
	}

	public EntityTypeRelationship getRelationshipByName(String name) {
		EntityTypeRelationship result = null;
		for (EntityTypeRelationship r: getPersistentEntityTypeRelationships()) {
			if (r.leftPropertyName.toLowerCase().equals(name.toLowerCase())) {
				result = r;
				break;
			}
		}
		return result;
	}

	private HashMap<String, PersistentEntityType> persistentEntityTypesMap = new HashMap<String, PersistentEntityType>();

	public PersistentEntityType getPersistentEntityType(String name) {
		return persistentEntityTypesMap.get(name);
	}
		
	public Collection<PersistentEntityType> getPersistentEntityTypes() {
		return persistentEntityTypesMap.values();
	}

	public HashMap<String, PersistentEntityType> getPersistentEntityTypesMap() {
		return persistentEntityTypesMap;
	}

	public void copyTo(EntityType targetEntity) {
		// First of all, typeId
		targetEntity.typeId = typeId;
		// Copy PET in the hierarchy
		for (PersistentEntityType pet: getHierarchyPersistentEntityTypes()) 
			targetEntity.addHierarchyPersistentEntityType(pet);
		// Now, properties
		for (PropertyType p: getProperties()) 
			targetEntity.addProperty(p.clone());
		// And finally, relationship
		for (EntityTypeRelationship r: getPersistentEntityTypeRelationships()) 
			targetEntity.addRelationship(r.clone());
	}
	
	public EntityType clone() {
		EntityType clonedEntity = new EntityType(name);
		copyTo(clonedEntity);
		return clonedEntity;
	}
	
}

