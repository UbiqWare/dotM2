package org.aspect.core.aql.codegenerators.sql;

public abstract class ExternalFunctionStandardFieldAccess extends ExternalFunctionStandard {

	protected Command tempCommand = null;

    @Override 
    public void onBeforeLeftToCode() {
        // ExternalFunctionAccess context is temporaly remove
    	code = new StringBuilder();
        if (!functionCommand.codeGenerator.getAspectFilterGeneration())
            tempCommand = functionCommand.codeGenerator.closeCommandContext();
    	functionCommand.addArgsToSymbolTable = false;
    	functionCommand.positionToAddInSymbolTable = 0;
		functionName =  functionCommand.expression.leftExpression.toString();
    }

    @Override 
    public void onAfterToCode() {
        // ExternalFunctionAccess context is temporaly restored
        if (!functionCommand.codeGenerator.getAspectFilterGeneration())
            functionCommand.codeGenerator.openCommandContext(tempCommand);
    }
    
}
