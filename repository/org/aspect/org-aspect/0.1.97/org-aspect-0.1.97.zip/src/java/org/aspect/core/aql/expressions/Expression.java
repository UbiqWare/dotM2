package org.aspect.core.aql.expressions;

import org.aspect.core.aql.SymbolTable;
import org.aspect.core.aql.codegenerators.CodeGenerator;
import org.aspect.core.aql.codegenerators.CodeGeneratorCommand;
import org.aspect.core.aql.entites.EntityType;
import org.aspect.core.aql.entites.QueryEntityType;

public abstract class Expression {
	
	public String text = "";
	public Object value = "";
	public Object leftExpression;
	public Object rightExpression;
	public Expression parent;
	private String aliasName = "";

    public String getAliasName() {
        return (this.aliasName.equals("")) ? text : this.aliasName;
    }

    public void setAliasName(String value) {
        this.aliasName = (value == null) ? "" : value;
    }

    public Expression clone() {
        return null;
    }
    
    public void expand() {
        if (leftExpression instanceof Expression) {
            ((Expression)leftExpression).parent = this;
            ((Expression)leftExpression).expand();
        }
        if (rightExpression instanceof Expression) {
            ((Expression)rightExpression).parent = this;
            ((Expression)rightExpression).expand();
        }
    }

    public CodeGeneratorCommand currentContext(CodeGenerator codeGenerator) { 
		return codeGenerator.commandStack.peek(); 
	}
    
	public static Expression buildExpressionByRef(Expression expression) {
        if (expression instanceof ExplicitRelationshipAccess) {
            return new ExpressionAccessByRef(expression);
        } else if (expression instanceof ExpressionAccessByRef) {
            return new ExpressionAccessByRef(expression);
        } else if (expression instanceof MemberAccess) {
        	// MemberAccess need to protect PredicateAccess from updates 
            if (expression.rightExpression instanceof PredicateAccess)
                return new ExpressionAccessByRef(expression);
        }
        return expression;
    }

	public static Expression buildMemberAccess(String memberName, SymbolTable symbolTable) {
		EntityType entityType = symbolTable.getEntityType(memberName);
		if (entityType instanceof QueryEntityType) {
            return new ExpressionAccessByRef(new QueryMemberAccess(memberName, ((QueryEntityType)entityType).expression.clone()));
		} else {
			return new MemberAccess(memberName, null);
		}
	}
	
    public static Expression buildFunctionAccess(String functionName, ExpressionList args, SymbolTable symbolTable) {
    	if (functionName.equals("role")){
    		return new Role();
    	} else if (functionName.equals("parent")){
    		return new Parent();
    	} else if (functionName.equals("child")){
    		return new Child();
    	} else {
    		return new ExternalFunctionAccess(new ExternalFunction(functionName, (ExpressionList)args, symbolTable));
    	}
    }

}
