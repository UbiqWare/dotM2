package org.aspect.core.aql.interpreters;

import java.util.HashMap;
import java.util.List;

import org.aspect.core.aql.SymbolTable;

public abstract class AbstractIntepreter {

	protected SymbolTable symbolTable;

	public List<HashMap<String, Object>> resultList;
	
	public AbstractIntepreter() {
		this.symbolTable = null;
	}
	
	public AbstractIntepreter(SymbolTable symbolTable) {
		this.symbolTable = symbolTable;
	}
	
	public abstract void setApplicationContext(Object applicationContext);
	
	public abstract void interpret(String query);
	
}
