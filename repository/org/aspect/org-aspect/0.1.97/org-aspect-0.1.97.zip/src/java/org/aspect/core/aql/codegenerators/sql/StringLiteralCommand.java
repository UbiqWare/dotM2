package org.aspect.core.aql.codegenerators.sql;

public class StringLiteralCommand extends Command {
	@Override
	public void toCode() {
        code.append("'").append(expression.text).append("'");
    }
}
