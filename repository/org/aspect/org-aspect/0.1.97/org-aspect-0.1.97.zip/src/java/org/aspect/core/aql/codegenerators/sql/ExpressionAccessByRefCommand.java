package org.aspect.core.aql.codegenerators.sql;

import org.aspect.core.aql.SymbolTable;
import org.aspect.core.aql.entites.PropertyType;

public class ExpressionAccessByRefCommand extends Command {

	@Override
    public Command getCurrentCommandWithEntityType() {
		// TODO check whether is needed left.getCurrentCommandWithEntityType() or not
        //return left;
        return left.getCurrentCommandWithEntityType();
    }

	@Override
    public void onBeforeLeftToCode() {
        tableName = codeGenerator.getNewTableId();
        codeGenerator.openCommandContext(this);
    }

	@Override
    public void onAfterToCode() {
        codeGenerator.closeCommandContext();
    }

	@Override
    public void toCode() {
    	//
    	boolean added = addRightPredicateWhereCondition();
    	//
    	if (added) {
    		code.append("SELECT ").append(buildSelectSentence());
    		code.append(" FROM ").append(buildFromSentence());
    		code.append(buildWhereSentence());
    	} else {
    		tableName = left.tableName;
    		code = left.code;
    	}
    }

    private StringBuilder buildWhereSentence() {
 		return buildWhereSentence(" WHERE ", "");
	}

	private StringBuilder buildFromSentence() {
        // 
		StringBuilder from = new StringBuilder();
        from.append("(").append(left.code).append(") ").append(tableName).append(" ");
        from.append(buildAggregateCommands());
		return from;
	}

	private StringBuilder buildSelectSentence() {
		StringBuilder select = new StringBuilder();
        select.append(tableName).append(".*").append(buildExtraSelectField());
		return select;
	}

    @Override
	public void addToSymbolTable(SymbolTable sourceSymbolTable) {
		symbolTable.addAll(sourceSymbolTable);
	}
	
    private void checkSymbolTable() {
		if (symbolTable.get().size() < left.symbolTable.get().size()) {
			symbolTable.addAll(left.symbolTable);
		}
    }
    
	@Override
	public Command getCurrentCommandWithSymbolTable() {
		// TODO check whether is needed left.getCurrentCommandWithEntityType() or not
        //return left.getCurrentCommandWithEntityType();
		checkSymbolTable();
        return this;
    }

	@Override
    public Command getCurrentCommandWithTableName() {
        return this;
    }

	@Override
    public Command getRelationAccess() {
        return null;
    }
	
	@Override
	public PropertyType getPropertyByPAC(PropertyAccessCommand pac) {
		PropertyType p = left.getPropertyByPAC(pac);
		return p;
	}
}
