package org.aspect.core.aql.codegenerators.sql;

import java.util.List;

public class IfExternalFunctionCommand extends ExternalFunctionStandardFieldAccess {
    @Override
    public StringBuilder toCode(ExpressionListCommand args, List<String> argsCode) {
        //
        code.append("(CASE WHEN ").append(argsCode.get(0)).append(" THEN ").append(argsCode.get(1));
        if (argsCode.size() == 3) {
        	code.append(" ELSE ").append(argsCode.get(2));
        }
        code.append(" END)");
        //
    	return code;
    }

}
