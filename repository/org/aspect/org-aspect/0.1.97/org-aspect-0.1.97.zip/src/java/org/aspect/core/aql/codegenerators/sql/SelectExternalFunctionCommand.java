package org.aspect.core.aql.codegenerators.sql;

import java.util.List;

public class SelectExternalFunctionCommand  extends ExternalFunctionStandard {
    @Override
    public StringBuilder toCode(ExpressionListCommand args, List<String> argsCode) {
        code.append("SELECT ");
        String separator = "";
        for (Command fieldInit: ((ExpressionListCommand)args.commandList.get(1)).commandList) {
        	FieldInitializeCommand field = (FieldInitializeCommand)fieldInit;
        	String propertyName = field.left.expression.value.toString().toLowerCase();
        	// New property is added to command symbol table
        	functionCommand.addToSymbolTable(propertyName, propertyName);
        	//
        	code.append(separator);
        	//code.append(Command.getAliasByConvention(field.right.code.toString(), functionName, field.left.expression.value.toString()));
        	code.append(Command.getAliasByConvention(field.right.code.toString(), null, field.left.expression.value.toString()));
            separator = ", ";
        }
        //
        code.append(" FROM (").append(argsCode.get(0)).append(")").append(tableName);
    	return code;
    }
    
}
