package org.aspect.core.aql.codegenerators.sql;

public class PredicateAccessCommand extends Command {
	@Override
	public void toCode() {
		code = left.code;
    }
}
