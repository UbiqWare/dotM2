package org.aspect.core.aql.expressions;

public class Role extends Expression {

    public Role() {
    	this.text = "role()";
    	this.value = text;
    	this.leftExpression = null;
    	this.rightExpression = null;
    }

	@Override
    public Expression clone() {
        return new Role();
    }
	
}
