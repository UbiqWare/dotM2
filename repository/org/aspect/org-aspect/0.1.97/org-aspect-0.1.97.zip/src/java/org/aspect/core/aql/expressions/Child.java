package org.aspect.core.aql.expressions;

public class Child extends Expression {

    public Child() {
    	this.text = "child()";
    	this.value = text;
    	this.leftExpression = null;
    	this.rightExpression = null;
    }

	@Override
    public Expression clone() {
        return new Child();
    }
	
}
