package org.aspect.core.aql.entites;

import org.aspect.core.aql.Aspect;

public class InnerAspect {
	public Aspect aspect;
	public EntityType entityType;
	public String persistentName;
	public boolean isAggregateOf() {
		return aspect.isAggregateOf();
	}
}
