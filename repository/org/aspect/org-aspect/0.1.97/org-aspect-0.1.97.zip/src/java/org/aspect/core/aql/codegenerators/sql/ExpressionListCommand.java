package org.aspect.core.aql.codegenerators.sql;

import java.util.*;

import org.aspect.core.aql.expressions.Expression;
import org.aspect.core.aql.expressions.ExpressionList;

public class ExpressionListCommand extends Command {

    List<Command> commandList;
	
	List<String> codeList = new ArrayList<String>();

	public ExpressionListCommand() {
    	commandList = new ArrayList<Command>();
    }
    
    public List<String> getCodeList() {
        return codeList;
    }
	
    public String getCodeListAsString() {
        StringBuilder stringList = new StringBuilder();
        String coma = "";
        for (String code: codeList) {
            stringList.append(coma + " " + code + " ");
            coma = ",";
        }
        return stringList.toString();
    }

    void toCodeList(ExpressionList list) throws Exception {
        int position = 0;
        commandList = new ArrayList<Command>();
        for (Expression expression: list.getList()) {
            parent.onBeforeArgToCode(expression, position);
            Command command = codeGenerator.toCodeRecursive(expression, this);
            commandList.add(command);
            if (command instanceof ExpressionListCommand) {
                codeList.add(((ExpressionListCommand) command).getCodeListAsString().toString());
            } else {
                codeList.add(command.code.toString());
            }
            parent.onAfterArgToCode(command, position);
            position++;
        }
    }
    
    @Override
    public void toCode() throws Exception {
        toCodeList((ExpressionList) expression);
    }

}
