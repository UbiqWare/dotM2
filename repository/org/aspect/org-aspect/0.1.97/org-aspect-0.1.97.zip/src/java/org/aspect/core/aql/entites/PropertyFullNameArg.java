package org.aspect.core.aql.entites;

import java.util.HashMap;

public class PropertyFullNameArg {
	public EntityTypeRelationship 	entityTypeRelationship = null;
	public EntityType 				entityType = null;
	public PersistentEntityType 	targetPET = null;
	public String 					fixedPrefix = null;
	public boolean 					treatIdAsOtherProperties = true;
	public HashMap<String, String> 	persistentEntityNameIdMap = null;
	public PropertyType 			property = null;
	public PersistentEntityType 	persistentEntity = null;
	public PersistentPropertyType 	persistentProperty = null;
	public StringBuilder 			code = new StringBuilder();
	public String 					propertyFullName = null;
	public String 					keyFullName = null;
}
