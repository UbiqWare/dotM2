package org.aspect.core.aql;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;

import org.antlr.runtime.ANTLRStringStream;
import org.antlr.runtime.CommonTokenStream;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.aspect.core.aql.codegenerators.CodeGenerator;
import org.aspect.core.aql.codegenerators.sql.SqlCodeGenerator;
import org.aspect.core.aql.entites.EntityType;
import org.aspect.core.aql.entites.FunctionByQueryEntityType;
import org.aspect.core.aql.entites.QueryEntityType;
import org.aspect.core.aql.expressions.Expression;
import org.aspect.core.aql.interpreters.AbstractIntepreter;

public class AqlEngine {

	// TODO neo4j, mongodb?
	static  {
		AqlContext.persistanceEngineNameMetadataMap.put(SqlCodeGenerator.MS_SQL + ".persistentPropertyType", "org.aspect.core.aql.codegenerators.sql.entities.SqlPersistentPropertyType");
		AqlContext.persistanceEngineNameMetadataMap.put(SqlCodeGenerator.MS_SQL + ".persistentEntityType", "org.aspect.core.aql.codegenerators.sql.entities.SqlPersistentEntityType");
		AqlContext.persistanceEngineNameMetadataMap.put(SqlCodeGenerator.MS_SQL + ".codeGenerator", "org.aspect.core.aql.codegenerators.sql.SqlCodeGenerator");
		AqlContext.persistanceEngineNameMetadataMap.put(SqlCodeGenerator.MS_SQL + ".interpreter", "org.aspect.grails.interpreters.sql.HibernateInterpreter");
		//
		AqlContext.persistanceEngineNameMetadataMap.put(SqlCodeGenerator.MYSQL + ".persistentPropertyType", "org.aspect.core.aql.codegenerators.sql.entities.SqlPersistentPropertyType");
		AqlContext.persistanceEngineNameMetadataMap.put(SqlCodeGenerator.MYSQL + ".persistentEntityType", "org.aspect.core.aql.codegenerators.sql.entities.SqlPersistentEntityType");
		AqlContext.persistanceEngineNameMetadataMap.put(SqlCodeGenerator.MYSQL + ".codeGenerator", "org.aspect.core.aql.codegenerators.sql.SqlCodeGenerator");
		AqlContext.persistanceEngineNameMetadataMap.put(SqlCodeGenerator.MYSQL + ".interpreter", "org.aspect.grails.interpreters.sql.HibernateInterpreter");
		//
		AqlContext.persistanceEngineNameMetadataMap.put(SqlCodeGenerator.H2 + ".persistentPropertyType", "org.aspect.core.aql.codegenerators.sql.entities.SqlPersistentPropertyType");
		AqlContext.persistanceEngineNameMetadataMap.put(SqlCodeGenerator.H2 + ".persistentEntityType", "org.aspect.core.aql.codegenerators.sql.entities.SqlPersistentEntityType");
		AqlContext.persistanceEngineNameMetadataMap.put(SqlCodeGenerator.H2 + ".codeGenerator", "org.aspect.core.aql.codegenerators.sql.SqlCodeGenerator");
		AqlContext.persistanceEngineNameMetadataMap.put(SqlCodeGenerator.H2 + ".interpreter", "org.aspect.grails.interpreters.sql.HibernateInterpreter");
		//
		AqlContext.persistanceEngineNameMetadataMap.put(SqlCodeGenerator.HSQL + ".persistentPropertyType", "org.aspect.core.aql.codegenerators.sql.entities.SqlPersistentPropertyType");
		AqlContext.persistanceEngineNameMetadataMap.put(SqlCodeGenerator.HSQL + ".persistentEntityType", "org.aspect.core.aql.codegenerators.sql.entities.SqlPersistentEntityType");
		AqlContext.persistanceEngineNameMetadataMap.put(SqlCodeGenerator.HSQL + ".codeGenerator", "org.aspect.core.aql.codegenerators.sql.SqlCodeGenerator");
		AqlContext.persistanceEngineNameMetadataMap.put(SqlCodeGenerator.HSQL + ".interpreter", "org.aspect.grails.interpreters.sql.HibernateInterpreter");
		//
		AqlContext.persistanceEngineNameMetadataMap.put(SqlCodeGenerator.POSTGRESQL + ".persistentPropertyType", "org.aspect.core.aql.codegenerators.sql.entities.SqlPersistentPropertyType");
		AqlContext.persistanceEngineNameMetadataMap.put(SqlCodeGenerator.POSTGRESQL + ".persistentEntityType", "org.aspect.core.aql.codegenerators.sql.entities.SqlPersistentEntityType");
		AqlContext.persistanceEngineNameMetadataMap.put(SqlCodeGenerator.POSTGRESQL + ".codeGenerator", "org.aspect.core.aql.codegenerators.sql.SqlCodeGenerator");
		AqlContext.persistanceEngineNameMetadataMap.put(SqlCodeGenerator.POSTGRESQL + ".interpreter", "org.aspect.grails.interpreters.sql.HibernateInterpreter");
		
		AqlContext.persistanceEngineNameMetadataMap.put(SqlCodeGenerator.ORACLE + ".persistentPropertyType", "org.aspect.core.aql.codegenerators.sql.entities.SqlPersistentPropertyType");
		AqlContext.persistanceEngineNameMetadataMap.put(SqlCodeGenerator.ORACLE + ".persistentEntityType", "org.aspect.core.aql.codegenerators.sql.entities.SqlPersistentEntityType");
		AqlContext.persistanceEngineNameMetadataMap.put(SqlCodeGenerator.ORACLE + ".codeGenerator", "org.aspect.core.aql.codegenerators.sql.SqlCodeGenerator");
		AqlContext.persistanceEngineNameMetadataMap.put(SqlCodeGenerator.ORACLE + ".interpreter", "org.aspect.grails.interpreters.sql.HibernateInterpreter");
	}

	protected static final Log 	log = LogFactory.getLog(AqlEngine.class);
	public static final String 	DEFAULT_PERSISTANCE_ENGINE = SqlCodeGenerator.H2;
	public AqlContext aqlContext;
	public CodeGenerator codeGenerator;
	public AbstractIntepreter interpreter;
	public boolean addBuiltinTypes = true;

	public AqlEngine() {
		initialize(DEFAULT_PERSISTANCE_ENGINE);
	}

	public AqlEngine(String persistanceEngine) {
		initialize(persistanceEngine);
	}

	private AqlEngine(boolean init) {
	}

	public AqlEngine clone() {
		AqlEngine newAqlEngine = null;
		try {
			newAqlEngine = new AqlEngine(false);
			newAqlEngine.aqlContext = aqlContext.clone();
			newAqlEngine.loadContextSymbols();
			newAqlEngine.instanceCodeGeneratorAndInterpreter();
		} catch (Exception e) {
			throw new RuntimeException("initialization has thrown an exception", e);
		}
		return newAqlEngine;
	}

	void initialize(String persistanceEngineName) {
		try {
			aqlContext = new AqlContext(persistanceEngineName);
			loadContextSymbols();
			instanceCodeGeneratorAndInterpreter();
		} catch (Exception e) {
			throw new RuntimeException("initialization has thrown an exception", e);
		}
	}
	
	void loadContextSymbols() {
		aqlContext.set(SymbolTable.PERSISTENCE_ENGINE_NAME_KEY_ID, aqlContext.persistanceEngineName);
		aqlContext.setVariable(AqlContext.USER_ID, "1");
	}
	

	public void buildBuiltinTypes() {
		codeGenerator.buildBuiltinTypes();
	}

	void instanceCodeGeneratorAndInterpreter() throws InstantiationException, IllegalAccessException, ClassNotFoundException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException, SecurityException {
		this.codeGenerator = (CodeGenerator) newObjectByPropertyName("codeGenerator", aqlContext.symbolTable);
		this.interpreter = (AbstractIntepreter) newObjectByPropertyName("interpreter", aqlContext.symbolTable);
	}
	
	public Object newObjectByPropertyName(String propertyName) throws InstantiationException, IllegalAccessException, ClassNotFoundException {
		String className = checkObjectByName(propertyName);
		return this.getClass().getClassLoader().loadClass(className).newInstance();
	}
	
	public Object newObjectByPropertyName(String propertyName, SymbolTable symbolTable) throws InstantiationException, IllegalAccessException, ClassNotFoundException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException, SecurityException {
		String className = checkObjectByName(propertyName);
		return this.getClass().getClassLoader().loadClass(className).getConstructor(SymbolTable.class).newInstance(symbolTable);
	}
	
	private String checkObjectByName(String propertyName) {
		if (aqlContext.persistanceEngineName == null || aqlContext.persistanceEngineName.equals(""))
			throw new RuntimeException("target is not set. Call init first");
		// TODO check
		return AqlContext.persistanceEngineNameMetadataMap.get(aqlContext.persistanceEngineName + "." + propertyName);
	}

	private Expression translateRawAQLToExpression(String aql, boolean isFilter) {
		// Create an input character stream from standard in
		ANTLRStringStream input = new ANTLRStringStream(aql); 
		// Create an ExprLexer that feeds from that stream 
		AqlLexer lexer = new AqlLexer(input);
		// Create a stream of tokens fed by the lexer 
		CommonTokenStream tokens = new CommonTokenStream(lexer); 
		// Create a parser that feeds off the token stream 
		AqlParser aqlParser = new AqlParser(tokens);
		// Setting global symbol table
		aqlParser.symbolTable = aqlContext.symbolTable;
		//
		Expression expression;
		//
		try {
			//
			if (isFilter)
				expression = aqlParser.orExpression().value;
			else
				expression = aqlParser.queryExpression().value;
		} catch (Exception e) {
			throw new RuntimeException("translateRawAQLToExpression has thrown an exception", e);
		}
		//
		return expression;
	}
	
	private Expression translateAQLToExpression(String aql) {
		return translateRawAQLToExpression(aql, false);
	}

	public Expression translateAQLFilterToExpression(String aql) {
		return translateRawAQLToExpression(aql, true);
	}
	
    public String translate(String aql) {
		try {
			//
			Expression expression = translateAQLToExpression(aql);
			//
			return generateCode(expression, false).toString();
		} catch (Exception e) {
			throw new RuntimeException("translate has thrown an exception", e);
		}
    }

    public String translateAspectFilter(String aql) {
		try {
			//
			Expression expression = translateRawAQLToExpression(aql, true);
			//
			return generateCode(expression, true).toString();
		} catch (Exception e) {
			throw new RuntimeException("translateAspectFilter has thrown an exception", e);
		}
    }
    
	private StringBuilder generateCode(Expression expression, boolean aspectFilter) {
		StringBuilder code;
		//
		try {
			//
			boolean t = codeGenerator.getAspectFilterGeneration();
			codeGenerator.setAspectFilterGeneration(aspectFilter);
			// Be carefull with memory leaks because of the circular reference including symbol table. Set to null asap
			codeGenerator.setEngine(this);
			//
			codeGenerator.setExpression(expression);
			code = codeGenerator.toCode();
			//
			codeGenerator.setAspectFilterGeneration(t);
		} catch (Exception e) {
			throw new RuntimeException("generateCode has thrown an exception", e);
		} finally {
			// In order to prevent memory leaks because of the circular reference including symbol table
			codeGenerator.setEngine(null);
		}
		//
		return code;
	}
	
	public static StringBuilder generateCodeForAspectFilter(Object filterExpression, Object aqlEngine) {
		Expression localExpression = ((Expression) filterExpression).clone();
		AqlEngine newAqlEngine = ((AqlEngine)aqlEngine).clone();
		StringBuilder code = newAqlEngine.generateCode(localExpression, true);
		return code;
	}


	public void addEntityByQuery(String entityName, String aql) {
    	//
    	Expression expression = translateAQLToExpression(aql);
    	EntityType entityET = new QueryEntityType(entityName, expression);
    	//
    	aqlContext.setEntityType(entityET.name, entityET);
	}

	public void setFunction(String functionName, String className) {
		aqlContext.setFunction(functionName, className);
	}
	
	public String getFunction(String functionName) {
		return aqlContext.getFunction(functionName);
	}

	public void setFunctionByQuery(String functionName, FunctionByQueryEntityType entity) {
		aqlContext.setFunctionByQuery(functionName, entity);
	}

    public String getVariable(String name) {
    	return aqlContext.getVariable(name);
    }

    public void setVariable(String name, String value) { 
    	aqlContext.setVariable(name, value); 
    }
	
	public FunctionByQueryEntityType getFunctionByQuery(String functionName) {
		return aqlContext.getFunctionByQuery(functionName);
	}
	
	public void setFunctionByQuery(String functionSignature, String aql) {
		// Creating function
		String functionName = functionSignature.trim().substring(0, functionSignature.indexOf("("));
		setFunction(functionName, SqlCodeGenerator.rootNameSpace + "FunctionByQueryExternalFunctionCommand");
		//
		HashMap<String, String> args = buildArgsHashMap(functionSignature);
    	// Creating expression definition
    	Expression functionDefinitionExp = translateAQLToExpression(aql);
    	// 
    	FunctionByQueryEntityType entityET = new FunctionByQueryEntityType(functionName, functionDefinitionExp, args);
    	//
    	setFunctionByQuery(entityET.name, entityET);
	}

	private HashMap<String, String> buildArgsHashMap(String functionSignature) {
		// Translating function signature
    	Expression functionSignatureExp = translateAQLToExpression(functionSignature);
    	// Navigating through expression tree to get function args
    	Expression e = (Expression)((Expression)functionSignatureExp).leftExpression;
    	@SuppressWarnings("unchecked")
		ArrayList<Expression> args = (ArrayList<Expression>)((Expression)e.rightExpression).leftExpression;
    	//
    	HashMap<String, String> argsMap = new HashMap<String, String>();
    	int i = 0;
    	for (Expression exp: args) {
    		argsMap.put(exp.leftExpression.toString(), "");
    		argsMap.put(Integer.toString(i), exp.leftExpression.toString());
    		i++;
    	}
    	return argsMap;
	}

	public void addFunction(String functionName, String className) {
    	aqlContext.setFunction(functionName, className);
	}
	
}
