package org.aspect.core.loaders;

import java.util.HashMap;
import java.util.Map;

import org.aspect.core.aql.Aspect;
import org.aspect.core.aql.SymbolTable;
import org.aspect.core.aql.codegenerators.sql.entities.SqlEntityTypeRelationship;
import org.aspect.core.aql.codegenerators.sql.entities.SqlPersistentEntityType;
import org.aspect.core.aql.codegenerators.sql.entities.SqlPersistentPropertyType;
import org.aspect.core.aql.entites.EntityType;
import org.aspect.core.aql.entites.PersistentEntityType;
import org.aspect.core.aql.entites.PropertyType;

// TODO
public class DomainClassDefaultLoader {
	
	public DomainClassDefaultLoader(SymbolTable symbolTable) {
		setSymbolTable(symbolTable);
	}

    private SymbolTable symbolTable;

    public void setSymbolTable(SymbolTable value) {
    	this.symbolTable = value;
    }
    
    public SymbolTable getSymbolTable() {
    	return symbolTable;
    }
	
    void addPersistenEntityToSymbolTable(PersistentEntityType entity) {
    	symbolTable.setPersistentEntityType(entity.name.toLowerCase(), entity);
    }

    void addEntityToSymbolTable(EntityType entity) {
    	symbolTable.setEntityType(entity.name, entity);
    }
    
    public void buildBuiltinTypes() {
    	// PersistentEntityType - entity 
    	SqlPersistentEntityType entityPET = new SqlPersistentEntityType("entity");
		entityPET.addProperty(new SqlPersistentPropertyType("id", "long"));
		entityPET.addProperty(new SqlPersistentPropertyType("name", "string"));
		entityPET.addProperty(new SqlPersistentPropertyType("description", "string"));
		entityPET.addProperty(new SqlPersistentPropertyType("type_id", "long"));
		entityPET.addProperty(new SqlPersistentPropertyType("date_created", "datetime"));
		entityPET.addProperty(new SqlPersistentPropertyType("last_updated", "datetime"));
		entityPET.addProperty(new SqlPersistentPropertyType("created_by", "string"));
		entityPET.addProperty(new SqlPersistentPropertyType("updated_by", "string"));
		entityPET.id = entityPET.getProperty("id"); 
   		addPersistenEntityToSymbolTable(entityPET);

    	// PersistentEntityType - type
    	SqlPersistentEntityType typePET = new SqlPersistentEntityType("type");
		typePET.addProperty(new SqlPersistentPropertyType("id", "long"));
		typePET.addProperty(new SqlPersistentPropertyType("local_name", "long"));
		typePET.addProperty(new SqlPersistentPropertyType("local_namespace", "long"));
		typePET.id = typePET.getProperty("id"); 
   		addPersistenEntityToSymbolTable(typePET);

    	// PersistentEntityType - Aspect
    	SqlPersistentEntityType aspectPET = new SqlPersistentEntityType("aspect");
    	aspectPET.addProperty(new SqlPersistentPropertyType("id", "long"));
    	aspectPET.addProperty(new SqlPersistentPropertyType("detail_aspect_class_name", "string"));
    	aspectPET.addProperty(new SqlPersistentPropertyType("is_default", "bool"));
    	aspectPET.addProperty(new SqlPersistentPropertyType("filter", "string"));
    	aspectPET.id = aspectPET.getProperty("id"); 
   		addPersistenEntityToSymbolTable(aspectPET);
   		
    	// PersistentEntityType - role
    	SqlPersistentEntityType rolePET = new SqlPersistentEntityType("role");
    	rolePET.addProperty(new SqlPersistentPropertyType("id", "long"));
    	rolePET.addProperty(new SqlPersistentPropertyType("propagates_security", "boolean"));
    	rolePET.id = typePET.getProperty("id"); 
   		addPersistenEntityToSymbolTable(rolePET);
   		
    	// PersistentEntityType - relationshipAspect
    	SqlPersistentEntityType relationshipAspectPET = new SqlPersistentEntityType("relationship_aspect");
    	relationshipAspectPET.addProperty(new SqlPersistentPropertyType("id", "long"));
    	relationshipAspectPET.addProperty(new SqlPersistentPropertyType("date_created", "datetime"));
    	relationshipAspectPET.addProperty(new SqlPersistentPropertyType("last_updated", "datetime"));
    	relationshipAspectPET.addProperty(new SqlPersistentPropertyType("created_by", "string"));
    	relationshipAspectPET.addProperty(new SqlPersistentPropertyType("updated_by", "string"));
    	relationshipAspectPET.addProperty(new SqlPersistentPropertyType("left_id", "long"));
    	relationshipAspectPET.addProperty(new SqlPersistentPropertyType("right_id", "long"));
    	relationshipAspectPET.addProperty(new SqlPersistentPropertyType("role_id", "long"));
    	relationshipAspectPET.id = relationshipAspectPET.getProperty("id"); 
   		addPersistenEntityToSymbolTable(relationshipAspectPET);

    	// PersistentEntityType - securityAspect
    	SqlPersistentEntityType securityAspectPET = new SqlPersistentEntityType("security_aspect");
    	securityAspectPET.addProperty(new SqlPersistentPropertyType("id", "long"));
    	securityAspectPET.addProperty(new SqlPersistentPropertyType("date_created", "datetime"));
    	securityAspectPET.addProperty(new SqlPersistentPropertyType("last_updated", "datetime"));
    	securityAspectPET.addProperty(new SqlPersistentPropertyType("created_by", "string"));
    	securityAspectPET.addProperty(new SqlPersistentPropertyType("updated_by", "string"));
    	securityAspectPET.addProperty(new SqlPersistentPropertyType("entity_id", "long"));
    	securityAspectPET.addProperty(new SqlPersistentPropertyType("security_entity_id", "long"));
    	securityAspectPET.id = securityAspectPET.getProperty("id"); 
   		addPersistenEntityToSymbolTable(securityAspectPET);
   		
    		
    	// Instantiation
       	EntityType entityType = new EntityType("entity");
       	EntityType typeType = new EntityType("type");
       	EntityType aspectType = new EntityType("aspect");
       	EntityType roleType = new EntityType("role");
       	//EntityType relationshipAspectType = new EntityType("relationshipAspect");
       	//EntityType securityAspectType = new EntityType("securityAspect");
       	EntityType relationshipAspectType = new EntityType("relationship");
       	EntityType securityAspectType = new EntityType("security");
       	
       	// Type 'relationshipAspect': properties
       	Map<String, Object> relationshipAspectProperties = new HashMap<String, Object>();
       	relationshipAspectProperties.put("entityTypeName", relationshipAspectType.name);
       	relationshipAspectProperties.put("domainClassName", "org.aspect.model.RelationshipAspect");
       	relationshipAspectProperties.put("left", "leftId");
       	relationshipAspectProperties.put("right", "rightId");
       	relationshipAspectProperties.put("role", "roleId");

       	// Aspect 'security': properties
       	Map<String, Object> securityProperties = new HashMap<String, Object>();
       	securityProperties.put("entityTypeName", securityAspectType.name);
       	securityProperties.put("domainClassName", "org.aspect.model.SecurityAspect");
       	securityProperties.put("left", "entityId");
       	securityProperties.put("right", "securityEntityId");
       	//
       	Map<String, Object> filterSecurityAspectProperties = new HashMap<String, Object>();
       	filterSecurityAspectProperties.put("entityTypeName", securityAspectType.name);
       	filterSecurityAspectProperties.put("domainClassName", "org.aspect.model.SecurityAspect");
       	filterSecurityAspectProperties.put("left", "entityId");
       	//
       	Map<String, Object> filterSecurityAspectById = new HashMap<String, Object>();
       	filterSecurityAspectById.put("securityEntityId", "User");
       	filterSecurityAspectProperties.put("filter", filterSecurityAspectById);
       	
       	// Core aspects
       	Aspect relationshipAspect = new Aspect("relationship", relationshipAspectType, relationshipAspectProperties);
       	Aspect securityAspect = new Aspect("security", securityAspectType, securityProperties);
       	
       	// Filter aspects
       	Aspect filterSecurityAspect = new Aspect("security", securityAspectType, filterSecurityAspectProperties);
       	
       	// Adding to symbolTable
    	addEntityToSymbolTable(entityType);
    	addEntityToSymbolTable(typeType);
    	addEntityToSymbolTable(aspectType);
    	addEntityToSymbolTable(roleType);
    	addEntityToSymbolTable(relationshipAspectType);
    	addEntityToSymbolTable(securityAspectType);
    	
    	//
    	symbolTable.setAspect("relationship", relationshipAspect);
    	symbolTable.setAspect("security", securityAspect);
    	symbolTable.setFilterAspect("security", filterSecurityAspect);
    	 
    	// EntityType - typeType
		typeType.addHierarchyPersistentEntityType(entityPET);
		typeType.addHierarchyPersistentEntityType(typePET);
		typeType.addProperty(new PropertyType("id", "entity", "id"));
		typeType.addProperty(new PropertyType("typeId", "entity", "type_id"));
		typeType.addProperty(new PropertyType("name", "entity", "name"));
		typeType.addProperty(new PropertyType("description", "entity", "description"));
		typeType.addProperty(new PropertyType("localName", "type", "local_name"));
		typeType.typeId = EntityType.DEFAULT_TYPE_TYPE_ID;

    	// EntityType - entityType
		entityType.addHierarchyPersistentEntityType(entityPET);
		entityType.addProperty(new PropertyType("id", "entity", "id"));
		entityType.addProperty(new PropertyType("typeId", "entity", "type_id"));
		entityType.addProperty(new PropertyType("name", "entity", "name"));
		entityType.addProperty(new PropertyType("description", "entity", "description"));
		entityType.typeId = EntityType.DEFAULT_ENTITY_TYPE_ID;

    	// EntityType - aspectType
		aspectType.addHierarchyPersistentEntityType(entityPET);
		aspectType.addHierarchyPersistentEntityType(aspectPET);
		aspectType.addProperty(new PropertyType("id", "entity", "id"));
		aspectType.addProperty(new PropertyType("typeId", "entity", "type_id"));
		aspectType.addProperty(new PropertyType("name", "entity", "name"));
		aspectType.addProperty(new PropertyType("description", "entity", "description"));
		aspectType.addProperty(new PropertyType("detailAspectClassName", "aspect", "detail_aspect_class_name"));
		aspectType.addProperty(new PropertyType("isDefault", "aspect", "is_default"));
		aspectType.addProperty(new PropertyType("filter", "aspect", "filter"));
		aspectType.typeId = EntityType.DEFAULT_ENTITY_TYPE_ID + 10;
		
    	// EntityType - roleType
		roleType.addHierarchyPersistentEntityType(entityPET);
		roleType.addHierarchyPersistentEntityType(rolePET);
		roleType.addProperty(new PropertyType("id", "entity", "id"));
		roleType.addProperty(new PropertyType("typeId", "entity", "type_id"));
		roleType.addProperty(new PropertyType("name", "entity", "name"));
		roleType.addProperty(new PropertyType("description", "entity", "description"));
		roleType.addProperty(new PropertyType("propagatesSecurity", "role", "propagates_security"));
		roleType.typeId = EntityType.DEFAULT_ENTITY_TYPE_ID + 11;
		
    	// EntityType - relationshipType
		relationshipAspectType.addHierarchyPersistentEntityType(relationshipAspectPET);
		relationshipAspectType.addProperty(new PropertyType("id", "relationship_aspect", "id"));
		relationshipAspectType.addProperty(new PropertyType("leftId", "relationship_aspect", "left_id"));
		relationshipAspectType.addProperty(new PropertyType("rightId", "relationship_aspect", "right_id"));
		relationshipAspectType.addProperty(new PropertyType("roleId", "relationship_aspect", "role_id"));
		relationshipAspectType.typeId = EntityType.DEFAULT_ENTITY_TYPE_ID + 12;

    	// EntityType - securityType
		securityAspectType.addHierarchyPersistentEntityType(securityAspectPET);
		securityAspectType.addProperty(new PropertyType("id", "security_aspect", "id"));
		securityAspectType.addProperty(new PropertyType("entityId", "security_aspect", "entity_id"));
		securityAspectType.addProperty(new PropertyType("securityEntityId", "security_aspect", "security_entity_id"));
		securityAspectType.typeId = EntityType.DEFAULT_ENTITY_TYPE_ID + 13;
		
		// Join relationships
		entityType.addRelationship(new SqlEntityTypeRelationship(typeType, "type", "typeId"));
		typeType.addRelationship(new SqlEntityTypeRelationship(typeType, "type", "typeId"));
		aspectType.addRelationship(new SqlEntityTypeRelationship(typeType, "type", "typeId"));
		roleType.addRelationship(new SqlEntityTypeRelationship(typeType, "type", "typeId"));
		relationshipAspectType.addRelationship(new SqlEntityTypeRelationship(roleType, "role", "roleId"));
		
		//
		symbolTable.setBaseEntityType(entityType);

    }

}
