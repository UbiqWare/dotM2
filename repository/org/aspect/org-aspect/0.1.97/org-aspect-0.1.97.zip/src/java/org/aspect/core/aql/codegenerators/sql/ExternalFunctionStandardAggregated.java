package org.aspect.core.aql.codegenerators.sql;

public abstract class ExternalFunctionStandardAggregated  extends ExternalFunctionStandardFieldAccess {
    @Override
	public boolean isAggregated() {
		return true;
	}
}
