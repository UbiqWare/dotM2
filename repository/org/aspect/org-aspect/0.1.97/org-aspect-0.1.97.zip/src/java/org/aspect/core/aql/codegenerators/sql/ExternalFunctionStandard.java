package org.aspect.core.aql.codegenerators.sql;

import java.util.List;

import org.aspect.core.aql.entites.PropertyType;
import org.aspect.core.aql.expressions.Expression;
import org.aspect.core.aql.expressions.ExpressionList;
import org.aspect.core.aql.expressions.IExternalFunction;

public abstract class ExternalFunctionStandard implements IExternalFunction {

    public ExternalFunctionCommand functionCommand = null;

	protected StringBuilder code = new StringBuilder();
	
	public String tableName;
	
	public String functionName = "";

    @Override
	public void initialize(Expression baseExpression) {
	}

    @Override
	public ExpressionList buildArgs(ExpressionList args) {
		ExpressionList newArgs = new ExpressionList();
		for (Expression expression: args.getList())
			newArgs.add(expression.clone());
		return newArgs;
	}

    @Override
	public ExpressionList expand(Expression baseExpression, ExpressionList args) {
		for (Expression expression: args.getList())
			expression.expand();
		return args;
	}

    @Override
	public boolean isAggregated() {
		return false;
	}

    public void onBeforeLeftToCode() {
    	code = new StringBuilder();
        functionCommand.codeGenerator.openCommandContext(functionCommand);
    	functionCommand.addArgsToSymbolTable = true;
    	functionCommand.positionToAddInSymbolTable = 0;
		functionName =  functionCommand.expression.leftExpression.toString();
    }

    public void onBeforeRightToCode() { 
    	
    }

    public void onAfterToCode() {
        functionCommand.codeGenerator.closeCommandContext();
    }

    public abstract StringBuilder toCode(ExpressionListCommand args, List<String> argsCode);

    public void onBeforeArgToCode(Expression expression, int position) {
    	// NOT TO-DO recursive call which not terminate -> functionCommand.onBeforeArgToCode(expression, position);
    }

    public void onAfterArgToCode(Command command, int position) {
    	// NOT TO-DO recursive call which not terminate -> functionCommand.onAfterArgToCode(command, position);
    }
    
	public PropertyType getPropertyByPAC(PropertyAccessCommand pac) {
    	PropertyType p = functionCommand.entityTypeCommand.getPropertyByPAC(pac);
    	if (p == null) {
    		String pName = pac.propertyName.toLowerCase();
    		Object o = functionCommand.symbolTable.get(pName);
    		if (o != null && functionCommand.expression.leftExpression != null) {
    			p = new PropertyType( pName
    								  , Command.getPropertyNameByConvention(functionCommand.expression.leftExpression.toString())
    								  , Command.getPropertyNameByConvention(pName)
    								  , false);
    			p.isJoinRelationship = false;
    		}

    	}
    	return p; 
    }
}
