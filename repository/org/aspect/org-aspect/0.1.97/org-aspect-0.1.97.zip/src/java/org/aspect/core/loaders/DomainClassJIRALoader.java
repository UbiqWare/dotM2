package org.aspect.core.loaders;

// TODO
public class DomainClassJIRALoader {

    /*
    public void buildBuiltinTypeIssue() {
    	// PersistentEntityType 
    	SqlPersistentEntityType issuePET = new SqlPersistentEntityType("jiraissue");
		issuePET.addProperty(new SqlPersistentPropertyType("id", "long"));
		issuePET.addProperty(new SqlPersistentPropertyType("summary", "string"));
		issuePET.addProperty(new SqlPersistentPropertyType("issuetype", "string"));
		issuePET.addProperty(new SqlPersistentPropertyType("created", "datetime"));
		issuePET.addProperty(new SqlPersistentPropertyType("updated", "datetime"));
		issuePET.addProperty(new SqlPersistentPropertyType("duedate", "datetime"));
		issuePET.addProperty(new SqlPersistentPropertyType("resolutiondate", "datetime"));
		issuePET.addProperty(new SqlPersistentPropertyType("priority", "string"));
		issuePET.addProperty(new SqlPersistentPropertyType("timeoriginalestimate", "long"));
		issuePET.addProperty(new SqlPersistentPropertyType("timeestimate", "long"));
		issuePET.addProperty(new SqlPersistentPropertyType("timespent", "long"));
		issuePET.addProperty(new SqlPersistentPropertyType("project", "long"));
		issuePET.id = issuePET.getProperty("id"); 
		//
   		addPersistenEntityToSymbolTable(issuePET);
    	// Instantiation
       	EntityType issueType = new EntityType("issue");
       	// Adding to symbolTable
    	addEntityToSymbolTable(issueType);
    	// EntityType
		issueType.addHierarchyPersistentEntityType(issuePET);
		issueType.addProperty(new PropertyType("id", "jiraissue", "id"));
		issueType.addProperty(new PropertyType("typeId", "jiraissue", "issuetype"));
		issueType.addProperty(new PropertyType("summary", "jiraissue", "summary"));
		issueType.addProperty(new PropertyType("projectId", "jiraissue", "project"));
		issueType.typeId = EntityType.DEFAULT_ENTITY_TYPE_ID;
		//
		symbolTable.setBaseEntityType(issueType);
    }

	public void buildBuiltinTypeIssueLinkType() {
    	// PersistentEntityType 
    	SqlPersistentEntityType issueLinkTypePET = new SqlPersistentEntityType("issuelinktype");
		issueLinkTypePET.addProperty(new SqlPersistentPropertyType("id", "long"));
		issueLinkTypePET.addProperty(new SqlPersistentPropertyType("linkname", "string"));
		issueLinkTypePET.addProperty(new SqlPersistentPropertyType("inward", "string"));
		issueLinkTypePET.addProperty(new SqlPersistentPropertyType("outward", "string"));
		issueLinkTypePET.addProperty(new SqlPersistentPropertyType("pstyle", "string"));
		issueLinkTypePET.id = issueLinkTypePET.getProperty("id"); 
		//
   		addPersistenEntityToSymbolTable(issueLinkTypePET);
    	// Instantiation
       	EntityType roleType = new EntityType("role");
       	// Adding to symbolTable
    	addEntityToSymbolTable(roleType);
    	// EntityType
		roleType.addHierarchyPersistentEntityType(issueLinkTypePET);
		roleType.addProperty(new PropertyType("id", "issuelinktype", "id"));
		roleType.addProperty(new PropertyType("name", "issuelinktype", "linkname"));
		roleType.addProperty(new PropertyType("inward", "issuelinktype", "inward"));
		roleType.addProperty(new PropertyType("outward", "issuelinktype", "outward"));
		roleType.typeId = EntityType.DEFAULT_ENTITY_TYPE_ID;
	}
	
	public void buildBuiltinTypeIssueLink() {
    	// PersistentEntityType 
    	SqlPersistentEntityType issueLinkAspectPET = new SqlPersistentEntityType("issuelink");
		issueLinkAspectPET.addProperty(new SqlPersistentPropertyType("id", "long"));
		issueLinkAspectPET.addProperty(new SqlPersistentPropertyType("linktype", "long"));
		issueLinkAspectPET.addProperty(new SqlPersistentPropertyType("source", "long"));
		issueLinkAspectPET.addProperty(new SqlPersistentPropertyType("destination", "long"));
		issueLinkAspectPET.addProperty(new SqlPersistentPropertyType("sequence", "long"));
		issueLinkAspectPET.id = issueLinkAspectPET.getProperty("id"); 
		//
   		addPersistenEntityToSymbolTable(issueLinkAspectPET);

   		// Instantiation
       	EntityType relationshipAspectType = new EntityType("relationshipAspect");
		relationshipAspectType.addHierarchyPersistentEntityType(issueLinkAspectPET);
		relationshipAspectType.addProperty(new PropertyType("id", "issuelink", "id"));
		relationshipAspectType.addProperty(new PropertyType("source", "issuelink", "source"));
		relationshipAspectType.addProperty(new PropertyType("destination", "issuelink", "destination"));
		relationshipAspectType.addProperty(new PropertyType("linkType", "issuelink", "linktype"));
		relationshipAspectType.typeId = EntityType.DEFAULT_ENTITY_TYPE_ID;

       	// Adding to symbolTable
    	addEntityToSymbolTable(relationshipAspectType);
		
       	// Type 'relationshipAspect': properties
       	Map<String, Object> relationshipAspectProperties = new HashMap<String, Object>();
       	relationshipAspectProperties.put("entityTypeName", relationshipAspectType.name);
       	relationshipAspectProperties.put("domainClassName", "not implemented");//"org.aspect.model.RelationshipAspect");
       	relationshipAspectProperties.put("left", "source");
       	relationshipAspectProperties.put("right", "destination");
       	relationshipAspectProperties.put("role", "linkType");
		
       	//
       	Aspect relationshipAspect = new Aspect("relationship", relationshipAspectType, relationshipAspectProperties);
    	symbolTable.setAspect("relationship", relationshipAspect);

	}

    public void buildBuiltinTypeProject() {
    	// PersistentEntityType 
    	SqlPersistentEntityType projectPET = new SqlPersistentEntityType("project");
		projectPET.addProperty(new SqlPersistentPropertyType("id", "long"));
		projectPET.addProperty(new SqlPersistentPropertyType("pname", "string"));
		projectPET.addProperty(new SqlPersistentPropertyType("lead", "string"));
		projectPET.addProperty(new SqlPersistentPropertyType("originalkey", "string"));
		projectPET.id = projectPET.getProperty("id"); 
		//
   		addPersistenEntityToSymbolTable(projectPET);
    	// Instantiation
       	EntityType projectType = new EntityType("project");
       	// Adding to symbolTable
    	addEntityToSymbolTable(projectType);
    	// EntityType
		projectType.addHierarchyPersistentEntityType(projectPET);
		projectType.addProperty(new PropertyType("id", "project", "id"));
		projectType.addProperty(new PropertyType("pname", "project", "pname"));
		projectType.addProperty(new PropertyType("lead", "project", "lead"));
		projectType.addProperty(new PropertyType("originalkey", "project", "originalkey"));
		//projectType.addProperty(new ConstantPropertyType("typeId", "type_id", "1"));
		projectType.typeId = EntityType.DEFAULT_ENTITY_TYPE_ID;
    }

	public void buildBuiltinTypeWorkforceAspect() {
    	// PersistentEntityType 
    	SqlPersistentEntityType workforceAspectPET = new SqlPersistentEntityType("worklog");
		workforceAspectPET.addProperty(new SqlPersistentPropertyType("id", "long"));
		workforceAspectPET.addProperty(new SqlPersistentPropertyType("issueid", "long"));
		workforceAspectPET.addProperty(new SqlPersistentPropertyType("author", "string"));
		workforceAspectPET.addProperty(new SqlPersistentPropertyType("startdate", "datetime"));
		workforceAspectPET.addProperty(new SqlPersistentPropertyType("timeworked", "long"));
		workforceAspectPET.id = workforceAspectPET.getProperty("issueid"); 
   		addPersistenEntityToSymbolTable(workforceAspectPET);

   		// Instantiation
       	EntityType workforceAspectType = new EntityType("workforceAspect");
		workforceAspectType.addHierarchyPersistentEntityType(workforceAspectPET);
		workforceAspectType.addProperty(new PropertyType("id", "worklog", "issueid"));
		workforceAspectType.addProperty(new PropertyType("workforceId", "worklog", "id"));
		workforceAspectType.addProperty(new PropertyType("authorName", "worklog", "author"));
		//workforceAspectType.addProperty(new PropertyType("author", "worklog", "author"));
		workforceAspectType.addProperty(new PropertyType("startDate", "worklog", "startdate"));
		workforceAspectType.addProperty(new PropertyType("timeWorked", "worklog", "timeworked"));
		workforceAspectType.typeId = EntityType.DEFAULT_ENTITY_TYPE_ID;

       	// Adding to symbolTable
    	addEntityToSymbolTable(workforceAspectType);
		
       	// Type properties
       	Map<String, Object> componentAspectProperties = new HashMap<String, Object>();
       	componentAspectProperties.put("entityTypeName", workforceAspectType.name);
       	componentAspectProperties.put("domainClassName", "not implemented");//"org.aspect.model.ComponentAspect");
       	componentAspectProperties.put("left", "id");
       	componentAspectProperties.put("right", null);
		
       	//
       	Aspect workforceAspect = new Aspect("workforce", workforceAspectType, componentAspectProperties);
    	symbolTable.setAspect("workforce", workforceAspect);

	}
    
    public void buildBuiltinTypes() {
    	//
    	buildBuiltinTypeProject();
    	buildBuiltinTypeIssue();
    	buildBuiltinTypeIssueLinkType();
    	buildBuiltinTypeIssueLink();
    	buildBuiltinTypeWorkforceAspect();
    	// TODO finish
    	//buildBuiltinTypeComponent();
    	//buildBuiltinTypeComponentAspect();
    	//
    	EntityType issueET = symbolTable.getEntityType("issue"); 
    	EntityType projectET = symbolTable.getEntityType("project"); 
    	issueET.addJoinRelationship(new SqlEntityTypeRelationship(projectET, "project", "projectId"));
    	//
    	EntityType roleET = symbolTable.getEntityType("role"); 
    	EntityType relationshipAspectType = symbolTable.getEntityType("relationshipAspect"); 
    	relationshipAspectType.addJoinRelationship(new SqlEntityTypeRelationship(roleET, "role", "linkType"));
    	// TODO finish
    	//EntityType componentAspectType = symbolTable.getEntityType("componentAspect"); 
    	//componentAspectType.addJoinRelationship(new SqlEntityTypeRelationship(projectET, "project", "projectId"));
    }
    */
	
}
