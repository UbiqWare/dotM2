package org.aspect.core.aql.codegenerators.sql;

import java.util.List;
//

import org.aspect.core.aql.SymbolTable;
import org.aspect.core.aql.expressions.Expression;
import org.aspect.core.aql.expressions.ExpressionList;
import org.aspect.core.aql.expressions.ExternalFunction;
import org.aspect.core.aql.expressions.ExternalFunctionAccess;
import org.aspect.core.aql.expressions.FieldInitialize;
import org.aspect.core.aql.expressions.GT;
import org.aspect.core.aql.expressions.Int;
import org.aspect.core.aql.expressions.PredicateAccess;
import org.aspect.core.aql.expressions.PropertyAccess;
import org.aspect.core.aql.expressions.StringLiteral;

public class ExistExternalFunctionCommand extends ExternalFunctionStandardAggregated {
	//
    SymbolTable st;
	
	ExternalFunctionAccess buildEFA(String functionName, Expression ... args) {
		return new ExternalFunctionAccess(new ExternalFunction(functionName, buildEFAArgs(args), st), null);
	}

	ExternalFunctionAccess buildEFAPredicate(String functionName, PredicateAccess predicate, Expression ... args) {
		return new ExternalFunctionAccess(new ExternalFunction(functionName, buildEFAArgs(args), st), predicate);
	}
	
	ExpressionList buildEFAArgs(Expression[] args) {
		ExpressionList newArgs = new ExpressionList();
        for (Expression a: args)
        	newArgs.add(a);
        return newArgs;
	}
	
	@Override
    public ExpressionList expand(Expression baseExpression, ExpressionList args) {
		// Equivalent expression => group(ebase, eRelated, {'Count':count(@id)} ) [ if ( isnull(@Count), 0, @Count) > 0]
        ExternalFunction baseFunctionExpression = (ExternalFunction)baseExpression;
        // We get base expression where exist is applied. Then is cloned, and remove the predicate condition avoiding recursion
        Expression existBaseExpression = getExistBaseExpression(baseFunctionExpression);
        existBaseExpression = existBaseExpression.clone();
        existBaseExpression.rightExpression = null;
        st = baseFunctionExpression.symbolTable;
        // First, group's properties
        ExpressionList initializeExpressionList = new ExpressionList();
        initializeExpressionList.add(new FieldInitialize(new StringLiteral("'Count'"), buildEFA("count", new PropertyAccess("id", 0))));
        // Function's paramas
        PredicateAccess predicate = new PredicateAccess(
        		new GT(buildEFA("if", buildEFA("isnull", new PropertyAccess("Count", 0)), new Int(0), new PropertyAccess("Count", 0))
        		, new Int(0)));
        // Group param order is correct. This way join with the entityBase can be done easyly. It seems it makes no sense, but it is right
        ExternalFunctionAccess expression = buildEFAPredicate("group", predicate, args.getList().get(0), existBaseExpression, initializeExpressionList);
        // Created command is assigned to the param
        ExpressionList newArgs = new ExpressionList();
        newArgs.getList().add(expression);
        //
        return newArgs;
    }
	
    Expression getExistBaseExpression(Expression baseExpression) {
        // We search the predicate where the exist function is used
        Expression expression = baseExpression;
        boolean found = false;
        do {
            if (expression instanceof PredicateAccess) {
                found = true;
            }
            expression = expression.parent;
        } while (!found && expression != null);
        return expression;
    }
	
    @Override
    public StringBuilder toCode(ExpressionListCommand args, List<String> argsCode) {
        String codeString = args.commandList.get(0).right.left.code.toString();
        // Searching an expression that contains a predicate which is not a CommandExternalFunction y CommandExternalFunctionAccess, outter Exist
        Command accessExpression = functionCommand.codeGenerator.peekTableNamedAccessCommand();
        String topTableName = accessExpression.tableName;
        if (accessExpression.parent != null) {
            // Convention with group function
            String countTableName = args.commandList.get(0).tableName;
            String suffixFieldName = "group" + Command.FIELD_SEPARATOR + args.commandList.get(0).symbolTable.get("count").toString();
            String countFieldName = countTableName + "." + suffixFieldName;
            countTableName = countTableName.toLowerCase();
            // Next line commented because several "count" could appear. As they are not mandatory, they are not inserted
            //accessExpression.symbolTable.add("Count", countTableName + suffixFieldName);
            accessExpression.addExtraFieldToSelect(countFieldName + " " + countTableName + suffixFieldName);
            // Setting an aggregate function to the ancestors of PredicateAcccess
            String acc = args.commandList.get(0).code.toString().replace(suffixFieldName, countTableName + suffixFieldName);
            args.commandList.get(0).code = new StringBuilder(acc);
            accessExpression.addToAgregateCondition(args.commandList.get(0));
            // Checking parent
        	Command parentCommand = accessExpression.parent;
            topTableName = parentCommand.getCurrentTableNameBySide(functionCommand);
            if ((topTableName == null) ? false : !topTableName.equals("") ) {
                codeString = codeString.replace(args.commandList.get(0).tableName, topTableName);
                codeString = codeString.replace(suffixFieldName, countTableName + suffixFieldName);
            }
        } else {
            // Setting an aggregate function to the ancestors of PredicateAcccess
            accessExpression.addToAgregateCondition(args.commandList.get(0));
        }
        //
        return new StringBuilder(codeString);    
    }
}
