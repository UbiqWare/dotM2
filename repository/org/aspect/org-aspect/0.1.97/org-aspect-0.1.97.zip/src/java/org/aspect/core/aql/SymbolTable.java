package org.aspect.core.aql;

import java.util.Map;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Set;
import java.util.Stack;
import org.aspect.core.aql.entites.EntityType;
import org.aspect.core.aql.entites.InnerAspect;
import org.aspect.core.aql.entites.FunctionByQueryEntityType;
import org.aspect.core.aql.entites.PersistentEntityType;
import org.aspect.core.aql.expressions.IExternalFunction;

public class SymbolTable {
	//
    public static final String PERSISTENCE_ENGINE_NAME_KEY_ID = "$$persistanceEngineName$$";
    public static final String PERSISTENCE_ENGINE_UNKNOWN = "UNKNOWN";
    public static String ExternalFunctionNamespace = "ExternalFunctionNamespace";

    private Stack<HashMap<String, Object>> symbolTableStack = new Stack<HashMap<String, Object>>();
	
	public SymbolTable() {
		pushContext();
	}

    /*
	public SymbolTable(SymbolTable symbolTable) {
		// TODO review
		pushContext();
		addAll(symbolTable);
	}
	*/

    public SymbolTable clone() {
        SymbolTable newSymbolTable = new SymbolTable();
        newSymbolTable.addAll(this);
        return newSymbolTable;
    }

	private void pushContext() {
		symbolTableStack.push(new HashMap<String, Object>());
    }

    private void popContext() {
    	symbolTableStack.pop();
    }

    public Set<Entry<String, Object>> toList() {
        return symbolTableStack.peek().entrySet();
    }
	
    public void addAll(SymbolTable source) {
    	symbolTableStack.peek().putAll(source.symbolTableStack.peek());
    }

    public void set(String name, Object value) {
    	symbolTableStack.peek().put(name, value);
    }

    public Object get(String name) {
    	return symbolTableStack.peek().get(name);
    }

    public HashMap<String, Object> get() {
    	return symbolTableStack.peek();
    }
    
    public void add(String name, Object value) {
    	symbolTableStack.peek().put(name, value);
    }
    
    public String getString(String name) { 
    	Object obj = get(name);
        return (obj == null) ? null : obj.toString();
    }
    
    public int getInt(String name) {    	
    	return Integer.parseInt(getString(name)); 
    }

    public float getFloat(String name) { 
    	return Float.parseFloat(getString(name)); 
    }

    public Boolean getBoolean(String name) { 
    	return Boolean.parseBoolean(getString(name)); 
    }

    public String getExternalVariable(String name) {
    	Object o = get("$$external_variable$$" + name.toLowerCase() + "$$");
    	return (o == null) ? null : o.toString(); 
    }

    public void setExternalVariable(String name, String value) { 
    	set("$$external_variable$$" + name.toLowerCase() + "$$", value); 
    }
    
    public EntityType getEntityType(String name) {
    	Object o = get("$$entitytype$$" + name.toLowerCase() + "$$");
    	return (o == null) ? null : (EntityType)o; 
    }

    public void setEntityType(String name, EntityType entityType) { 
    	set("$$entitytype$$" + name.toLowerCase() + "$$", entityType); 
    }

    public EntityType getBaseEntityType() {
    	Object o = get("$$baseentitytype$$$$");
    	return (o == null) ? null : (EntityType)o; 
    }

    public void setBaseEntityType(EntityType entityType) { 
    	set("$$baseentitytype$$$$", entityType); 
    }

    public PersistentEntityType getPersistentEntityType(String name) { 
    	Object o = get("$$" + name.toLowerCase() + "$$"); 
    	return (o == null) ? null : (PersistentEntityType)o; 
    }

    public void setPersistentEntityType(String name, PersistentEntityType pet) { 
    	set("$$" + name.toLowerCase() + "$$", pet); 
    }

    public Aspect getAspect(String aspectName) { 
    	Object o = get("$$aspect_" + aspectName.toLowerCase() + "_$$"); 
    	return (o == null) ? null : (Aspect)o; 
    }

    public void setAspect(String aspectName, Aspect aspect) { 
    	set("$$aspect_" + aspectName.toLowerCase() + "_$$", aspect); 
    }

    public Aspect getFilterAspect(String filterAspectName) { 
    	Object o = get("$$filter$$aspect_" + filterAspectName.toLowerCase() + "_$$"); 
    	return (o == null) ? null : (Aspect)o; 
    }

    public void setFilterAspect(String filterAspectName, Aspect filterAspect) { 
    	set("$$filter$$aspect_" + filterAspectName.toLowerCase() + "_$$", filterAspect); 
    }
    
    public void removeInnerAspect(String innerAspect) {
        // TODO check
        Map<String, InnerAspect> innerAspects = getInnerAspects();
        innerAspects.remove(innerAspect);
    }
    
    public void addInnerAspect(String innerAspectName) {
        addInnerAspect(innerAspectName, getAspect(innerAspectName));
    }

    public InnerAspect newInnerAspect(String aspectName) {
    	return newInnerAspect(getAspect(aspectName));
    }
    
    public InnerAspect newInnerAspect(Aspect aspect) {
        InnerAspect newInnerAspect = new InnerAspect();
        newInnerAspect.aspect = aspect;
        newInnerAspect.entityType = aspect.entityType;
        if (!aspect.isAggregateOf()) {
        	newInnerAspect.persistentName = aspect.entityType.getHierarchyPersistentEntityTypes().get(0).name;
        }
    	return newInnerAspect;
    }
    
    public void addInnerAspect(String innerAspectName, Aspect innerAspect) {
        // TODO check
        Map<String, InnerAspect> innerAspects = getInnerAspects();
        InnerAspect newInnerAspect = newInnerAspect(innerAspect);
        innerAspects.put(innerAspectName, newInnerAspect);
    }
    
    @SuppressWarnings("unchecked")
    public Map<String, InnerAspect> getInnerAspects() {
        // TODO check
        Map<String, InnerAspect> innerAspects;  
        Object o = get("$$_innerAspects_$$");
        if (o == null) {
            innerAspects = new HashMap<String, InnerAspect>();
            set("$$_innerAspects_$$", innerAspects);
        } else {
            innerAspects = ((Map<String, InnerAspect>)o);
        }
        return innerAspects;
    }
    
    public void setInnerAspects(Map<String, InnerAspect> innerAspects) {
    	set("$$_innerAspects_$$", innerAspects);
    }
    
    
	public IExternalFunction getNewExternalFunctionInstance(String functionName) {
		//
        String fullFunctionClassName = getFunction(functionName);
        if (fullFunctionClassName == null) {
        	throw new RuntimeException("function '" + functionName + "' not found in symbolTable");
        }
        //
        try {
	    	ClassLoader classLoader = SymbolTable.class.getClassLoader();	    	
	    	Class<?> classLoaded = classLoader.loadClass(fullFunctionClassName);
			return (IExternalFunction) classLoaded.newInstance();
        } catch (Exception e) {
        	throw new RuntimeException("Error creating instance of '" + fullFunctionClassName + "'", e);
        }
	}
	
	public void setFunction(String functionName, String className) {
		set("$$externalfunction$$" + functionName + "$$", className);
	}
	
	public String getFunction(String functionName) {
		return get("$$externalfunction$$" + functionName + "$$").toString();
	}

    public void setFunctionByQuery(String functionName, FunctionByQueryEntityType entityType) { 
		set("$$functionbyquery$$" + functionName + "$$", entityType);
    }
	
    public FunctionByQueryEntityType getFunctionByQuery(String functionName) {
    	Object o = get("$$functionbyquery$$" + functionName + "$$"); 
		return (o instanceof FunctionByQueryEntityType) ? (FunctionByQueryEntityType)o : null;
    }

	public String getTargetPersistenceEngineTypeName() {
    	Object o = get(PERSISTENCE_ENGINE_NAME_KEY_ID);
    	return (o == null) ? PERSISTENCE_ENGINE_UNKNOWN : o.toString();
	}

	public void setTargetPersistenceEngineTypeName(String value) {
    	set(PERSISTENCE_ENGINE_NAME_KEY_ID, value);
	}
	
}
