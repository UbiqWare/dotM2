package org.aspect.core.aql.codegenerators.sql;

import java.util.List;

public class ScalarAvgExternalFunctionCommand extends ExternalFunctionStandard {
    @Override
    public StringBuilder toCode(ExpressionListCommand args, List<String> argsCode) {
        return code.append("SELECT AVG(").append(argsCode.get(1)).append(") AVG_Avg FROM (")
      		   .append(argsCode.get(0)).append(")").append(tableName);
    }

}
