package org.aspect.core.aql.codegenerators;

import java.util.Stack;
import org.aspect.core.aql.SymbolTable;
import org.aspect.core.aql.expressions.Expression;

public abstract class CodeGenerator {
    //
    public Stack<CodeGeneratorCommand> commandStack = new Stack<CodeGeneratorCommand>();
    //
	public abstract CodeGenerator init(SymbolTable symbolTable);
	//
    public abstract void buildBuiltinTypes();
    //
    public abstract void setSymbolTable(SymbolTable symbolTable);
    //
    public abstract SymbolTable getSymbolTable();
    //
    public abstract void setExpression(Expression expression);
    //
    public abstract Expression getExpression();
    //
    public abstract void setAspectFilterGeneration(boolean aspectFilterGeneration);
    //
    public abstract boolean getAspectFilterGeneration();
    //
    public abstract void setEngine(Object engine);
    //
    public abstract Object getEngine();
    //
    public abstract StringBuilder toCode() throws Exception;
}
