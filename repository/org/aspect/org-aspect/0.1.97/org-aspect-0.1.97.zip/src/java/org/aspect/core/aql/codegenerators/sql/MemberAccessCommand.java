package org.aspect.core.aql.codegenerators.sql;

import java.util.Map;
import java.util.HashMap;

import org.aspect.core.aql.AqlEngine;
import org.aspect.core.aql.Aspect;
import org.aspect.core.aql.codegenerators.sql.entities.SqlPersistentEntityType;
import org.aspect.core.aql.entites.EntityType;
import org.aspect.core.aql.entites.InnerAspect;
import org.aspect.core.aql.entites.PersistentEntityType;
import org.aspect.core.aql.entites.PersistentPropertyType;
import org.aspect.core.aql.entites.PropertyFullNameArg;
import org.aspect.core.aql.entites.PropertyType;
import org.aspect.core.aql.expressions.Expression;

public class MemberAccessCommand extends Command {
	SqlPersistentEntityType 	firstPET;
	StringBuilder 				querySentence =  new StringBuilder();
    Map<String, InnerAspect> innerAspects = new HashMap<String, InnerAspect>();

    protected boolean areThereAnyInnerAspects() {
        if (innerAspects == null) return false;
        return innerAspects.size() > 0;
    }

    protected String getBigintTypeForTarget() {
    	String target = codeGenerator.getSymbolTable().getTargetPersistenceEngineTypeName();
    	String bigintAlias = "UNSIGNED";
    	if (target.equals(SqlCodeGenerator.H2)) {
    		bigintAlias = "BIGINT";
    	} else if (target.equals(SqlCodeGenerator.MYSQL)) {
    		bigintAlias = "UNSIGNED";
    	}
    	return bigintAlias;
    }
    
    protected StringBuilder buildWhereFromEntityType(EntityType entityType) {
		//		
		StringBuilder query = new StringBuilder();
		String firstPETAlias = persistentEntityNameIdMap.get(firstPET.alias);
		final String typeId = "typeId";
		String typeIdPersistentName = entityType.getProperty(typeId).persistentPropertyName;
		PersistentPropertyType typeIdPPT = firstPET.getProperty(typeIdPersistentName);
		String typeIdTypeName = typeIdPPT.type.toLowerCase(); 
		//
		query.append("(");
		// TODO Add these type list to a hash table customizable externaly
		if (!typeIdTypeName.equals("int") && !typeIdTypeName.equals("long") && !typeIdTypeName.equals("numeric") && !typeIdTypeName.equals("bigint")) {
			query.append("CAST(").append(firstPETAlias).append(".").append(typeIdPersistentName).append(" AS ").append(getBigintTypeForTarget()).append(")");
		} else {
			query.append(firstPETAlias).append(".").append(typeIdPersistentName);
		}
		//
		if (entityType.isTypeEntity()) {
			query.append(" > 0").append(" OR ").append(firstPETAlias).append(".").append(typeIdPersistentName).append(" IS NULL");
		} else if (entityType.isTypeType()) {
			query.append(" = ").append(entityType.typeId).append(" OR ").append(firstPETAlias).append(".").append(typeIdPersistentName).append(" IS NULL");
		} else {
			if (entityType.getSubtypeIds().size() == 0) {
				query.append(" = ").append(entityType.typeId);
			} else {
				query.append(" IN (").append(entityType.typeId);
				for(Long subtypeId: entityType.getSubtypeIds())
					query.append(",").append(subtypeId);
				query.append(")");
			}
		}
		query.append(")");
		//
		return query;
	}
    

    protected StringBuilder buildPredicateWhereCondition() {
		return buildWhereSentence(" WHERE ", "");
	}

    protected StringBuilder buildSelectSentence() {
		StringBuilder select = new StringBuilder();
		return select.append(tableName).append(".*").append(buildExtraSelectField());
	}
	
    protected StringBuilder buildFromSentence() {
		StringBuilder from = new StringBuilder();
		return from.append(querySentence.toString()).append(")").append(tableName).append(" ")
	        		.append(buildAggregateCommands());
	}

    protected StringBuilder buildWhereSentence() {
		StringBuilder where = new StringBuilder();
        // If exists a right predicate where more conditions are set, this conditions are added to the where sentence
        addRightPredicateWhereCondition();
        //
		return where.append(buildPredicateWhereCondition());
	}

    protected StringBuilder buildTypeQuery(StringBuilder select, StringBuilder join, StringBuilder where) {
    	StringBuilder query = new StringBuilder();
    	query.append(" SELECT ").append(select);
    	query.append(" FROM ").append(join);
   		query.append(" WHERE ").append(where);
    	return query;
    }
	
    protected StringBuilder buildSelectTypeQuery() {
		StringBuilder select = new StringBuilder();
		select.append(buildSelectFromEntityType(entityType, null));
        if (areThereAnyInnerAspects()) {
			boolean treatIdAsOtherProperties = true;
			boolean justIdsFromJoinProperties = true;
            for (Map.Entry<String, InnerAspect> innerAspectEntry: innerAspects.entrySet()) {
                String innerAspectName = innerAspectEntry.getKey();
                EntityType innerAspectET = innerAspectEntry.getValue().aspect.entityType.clone();
                InnerAspect innerAspect = innerAspectEntry.getValue();
                //
                String entityTypePersistentName = innerAspectET.getHierarchyPersistentEntityTypes().get(0).name;
            	PropertyType p = new PropertyType("className", entityTypePersistentName, "class_name", false); 
            	p.defaultValue = "'" + innerAspectEntry.getValue().aspect.get("domainClassName").toString() + "'";
            	p.isConstant = true;
            	innerAspectET.addProperty(p);
                //
                select.append(", ").append(buildSelectFromEntityType(innerAspectET, treatIdAsOtherProperties, justIdsFromJoinProperties, innerAspectName + Command.AGGREGATE_FIELD_SEPARATOR));
            }
		}
		return select;
	}

    @SuppressWarnings("unchecked")
    protected StringBuilder buildFromTypeQuery() {
        StringBuilder from = new StringBuilder();
        from.append(buildJoinFromEntityType(entityType, firstPET, null));
        if (areThereAnyInnerAspects()) {
            String entityTableName = persistentEntityNameIdMap.get(firstPET.alias);
            for (Map.Entry<String, InnerAspect> entry: innerAspects.entrySet()) {
                Aspect innerAspect = entry.getValue().aspect;
                EntityType innerAspectET = entry.getValue().entityType;
                //
                StringBuilder on = new StringBuilder();
                String leftPropertyName = innerAspect.get("left").toString();
                //
                PersistentEntityType firstAspectPET = innerAspectET.getHierarchyPersistentEntityTypes().get(0);
                String aspectTableName = persistentEntityNameIdMap.get(firstAspectPET.alias);
                //
                on.append(" ON ").append(aspectTableName).append(".");
                on.append(innerAspectET.getProperty(leftPropertyName).persistentPropertyName);
                on.append(" = ").append(entityTableName).append(".").append(Command.DEFAULT_FIELD_ID);
                // We set a tableId for every persistent entity
                if (innerAspect.isAggregateOf()) {
                    from.append(" INNER JOIN (").append(buildAggregateAspect(innerAspect)).append(") ").append(aspectTableName).append(on);
                } else {
                    Object filter = innerAspect.get("filter");
                    filter = filter.equals("no") ? null : filter;
                    Object filterExpression = innerAspect.get("filterExpression");
	                if (filterExpression != null) {
	                	on.append(" AND ").append(generateCodeForAspectFilter(filterExpression, aspectTableName));
	                } else if (filter != null) {
	                    for (Map.Entry<String, Object> filterEntry: ((Map<String, Object>)filter).entrySet()) {
	                        String filterPersistentPropertyName = innerAspect.entityType.getProperty(filterEntry.getKey()).persistentPropertyName;
	                        String filterValue = codeGenerator.getSymbolTable().getExternalVariable(filterEntry.getValue().toString());
	                        on.append(" AND ").append(aspectTableName).append(".").append(filterPersistentPropertyName).append(" = ").append(filterValue);
	                    }
	                }
	                //
	                StringBuilder filterAspectJoin = buildJoinFromEntityType(innerAspectET, firstPET, on);
	                from.append(" INNER JOIN ").append(filterAspectJoin);
                }
            }
        }
        //
        return from;
    }

	protected String generateCodeForAspectFilter(Object filterExpression, String aspectTableName) {
		String aspectFilter = AqlEngine.generateCodeForAspectFilter(filterExpression, codeGenerator.getEngine()).toString();
		aspectFilter = aspectFilter.replace("$$tablename$$", aspectTableName);
		return aspectFilter;
	}
    
    protected StringBuilder buildAggregateAspect(Aspect innerAspect) {
    	// Initialize
    	StringBuilder query = new StringBuilder();
		Aspect aggregateOfAspect = innerAspect.aggregateOfAspect;
		String newTableName = codeGenerator.getNewTableId();
    	// SELECT phase
    	StringBuilder select = buildAggregateSelectFromEntityType(innerAspect.entityType, newTableName);
    	query.append(" SELECT ").append(select);
    	// FROM phase
    	query.append(" FROM ").append(aggregateOfAspect.entityType.getHierarchyPersistentEntityTypes().get(0).name).append(" ").append(newTableName);
    	// WHERE phase
        StringBuilder where = new StringBuilder();	//
        Object filterExpression = innerAspect.get("filterExpression");
        if (filterExpression != null) {
        	where.append(" WHERE ").append(generateCodeForAspectFilter(filterExpression, newTableName));
        }
    	query.append(where);
    	// GROUP BY phase
    	query.append(" GROUP BY ").append(newTableName).append(".").append(innerAspect.entityType.getHierarchyPersistentEntityTypes().get(0).id.name);
    	return query;
    }
    
	private StringBuilder buildAggregateSelectFromEntityType(EntityType entityType, String newTableName) {
		//
		StringBuilder select = new StringBuilder();
        String separator = "";
    	for (PropertyType property: entityType.getProperties()) {
    		if (!property.isCalculated) continue;
            select.append(separator).append(" ").append(generateCodeForAspectFilter(property.expression, newTableName)).append(" ").append(property.persistentPropertyName);
            separator = ", ";
    	}
    	return select;
	}
 
	
    protected StringBuilder buildWhereTypeQuery() {
		StringBuilder where = new StringBuilder();
		where.append(buildWhereFromEntityType(entityType));
		return where;
	}


    protected void loadEntityTypeInfo() {
        // We get all the EntityType info needed
    	entityType = codeGenerator.getSymbolTable().getEntityType(expression.text);
    	// We get the first, reference point, SQLPersistenEntityType
    	if (entityType == null) {
    		throw new RuntimeException("'" + expression.text + "' not found in symbol table");
    	}
    	
    	firstPET = (SqlPersistentEntityType) entityType.getHierarchyPersistentEntityTypes().get(0);
    	// Assign tableId to all the persistentEntities
    	assignTableIdToPersistentEntities(entityType, persistentEntityNameIdMap);
	}


    //
    protected void loadInnerAspectsInfo() {
        // Master inner aspects 
        innerAspects = codeGenerator.getSymbolTable().getInnerAspects();
        if (!areThereAnyInnerAspects()) return;
        Map<String, InnerAspect> newInnerAspects = new HashMap<String, InnerAspect>(); 
        for (Map.Entry<String, InnerAspect> entry: innerAspects.entrySet()) {
            InnerAspect newInnerAspect = new InnerAspect();
            newInnerAspect.aspect = entry.getValue().aspect;
            newInnerAspect.entityType = entry.getValue().aspect.entityType.clone();
            newInnerAspect.persistentName = newInnerAspect.entityType.getHierarchyPersistentEntityTypes().get(0).name;
            PropertyType p = new PropertyType("className", newInnerAspect.persistentName, "class_name", false); 
            p.defaultValue = "'" + newInnerAspect.aspect.get("domainClassName").toString() + "'";
            p.isConstant = true;
            //
            newInnerAspect.entityType.addProperty(p);
            // Assign tableId to all the persistentEntities
            assignTableIdToPersistentEntities(newInnerAspect.entityType, persistentEntityNameIdMap);
            //
            newInnerAspects.put(entry.getKey(), newInnerAspect);
        }
        innerAspects = newInnerAspects;
    }
	
	@Override
	public void onBeforeLeftToCode() {
        // We get a table name id for all the tables involved
        tableName = codeGenerator.getNewTableId();
        //
        loadEntityTypeInfo();
    	//
        loadInnerAspectsInfo();
		// We build the whole query joining: select sentence and join sentence of the query base on EntiyInfo
    	querySentence = buildTypeQuery(buildSelectTypeQuery(), buildFromTypeQuery(), buildWhereTypeQuery());
    	// Open a command context
        codeGenerator.openCommandContext(this);
	}

	@Override
	public void onAfterToCode() {
        // Close a command context
        codeGenerator.closeCommandContext();
	}
	
	@Override
	public void toCode() {
		//
        code.append("SELECT ").append(buildSelectSentence())
        	.append(" FROM (").append(buildFromSentence())
        	.append(buildWhereSentence());
    }

	@Override
    public Command getCurrentCommandWithSymbolTable() {
        return this;
    }

	@Override
    public Command getCurrentCommandWithTableName() {
        return this;
    }

    @Override
	public PropertyType getPropertyByPAC(PropertyAccessCommand pac) {
    	PropertyType p = null;
        if (areThereAnyInnerAspects()) {
        	InnerAspect innerAspect = innerAspects.get(pac.propertyName);
        	if (innerAspect != null) {
            	Aspect aspect = innerAspect.aspect;
        		pac.entityType = aspect.entityType;
        		String petName = aspect.entityType.getHierarchyPersistentEntityTypes().get(0).name; 
        		p = new PropertyType(pac.propertyName, petName, petName);
        		p.isJoinRelationship = true;
        	} else {
        		p = super.getPropertyByPAC(pac);
        	}
        } else {
        	p = super.getPropertyByPAC(pac);
        }
        return p;
    	/*
    	Aspect aspect = aspects.get(pac.propertyName);
    	if (aspect != null) {
    		pac.entityType = aspect.entityType;
    		String petName = aspect.entityType.getHierarchyPersistentEntityTypes().get(0).name; 
    		PropertyType p = new PropertyType(pac.propertyName, petName, petName);
    		p.isJoinRelationship = true;
    		return p;
    	} else {
        	aspect = aspects.get(defaultAspectName);
        	PropertyType p = functionCommand.entityTypeCommand.getPropertyByPAC(pac);
        	return p;
    	}
    	*/
    }
	
}
