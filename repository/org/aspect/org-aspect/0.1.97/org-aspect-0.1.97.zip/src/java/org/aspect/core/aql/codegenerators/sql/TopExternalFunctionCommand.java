package org.aspect.core.aql.codegenerators.sql;

import java.util.List;

public class TopExternalFunctionCommand extends ExternalFunctionStandard {
    @Override
    public StringBuilder toCode(ExpressionListCommand args, List<String> argsCode) {
        code.append("SELECT ").append(tableName).append(".* FROM (").append(argsCode.get(0).trim()).append( ") ").append(tableName)
        	.append(" LIMIT ").append(argsCode.get(1).trim());
        return code;    
    }
}