package org.aspect.core.aql.entites;

import org.aspect.core.aql.expressions.Expression;

public class QueryEntityType extends EntityType {
	
	public Expression expression;

	public QueryEntityType(String name, Expression expression) {
		super(name);
		this.expression = expression;
	}

	@Override
	public EntityType clone() {
		EntityType clonedEntity = new QueryEntityType(name, expression.clone());
		copyTo(clonedEntity);
		return clonedEntity;
	}
	
}
