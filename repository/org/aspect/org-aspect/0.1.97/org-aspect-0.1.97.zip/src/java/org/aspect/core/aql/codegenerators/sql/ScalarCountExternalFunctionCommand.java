package org.aspect.core.aql.codegenerators.sql;

import java.util.List;

public class ScalarCountExternalFunctionCommand extends ExternalFunctionStandard {
    @Override
    public StringBuilder toCode(ExpressionListCommand args, List<String> argsCode) {
        return code.append("SELECT COUNT(").append(argsCode.get(1)).append(") COUNT_Count FROM (")
     		   .append(argsCode.get(0)).append(")").append(tableName);
    }
}
