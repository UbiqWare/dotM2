package org.aspect.core.aql.codegenerators.sql;

import java.util.List;

public class ScalarSumExternalFunctionCommand extends ExternalFunctionStandard {
    @Override
    public StringBuilder toCode(ExpressionListCommand args, List<String> argsCode) {
        return code.append("SELECT SUM(").append(argsCode.get(1)).append(") SUM_Sum FROM (")
        		   .append(argsCode.get(0)).append(")").append(tableName);
    }
}
