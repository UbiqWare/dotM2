package org.aspect.core.aql.expressions;

public class Int extends Expression {

    public Int(String value) {
    	this.text = value;
    	this.value = new Integer(value);
    	this.leftExpression = new Integer(value);
    	this.rightExpression = null;
    }

    public Int(int value) {
    	this.text = String.valueOf(value);
    	this.value = new Integer(value);
    	this.leftExpression = new Integer(value);
    	this.rightExpression = null;
    }

	@Override
    public Expression clone() {
        return new Int(((Integer)value).intValue());
    }
	
}
