package org.aspect.core.aql.codegenerators.sql;

import org.aspect.core.aql.Aspect;
import org.aspect.core.aql.entites.EntityType;

public class ChildCommand extends Command {
	@Override
	public void toCode() throws Exception {
		ExplicitRelationshipAccessCommand accesorCommand = (ExplicitRelationshipAccessCommand) codeGenerator.peekRelationAccessCommand();
        if (accesorCommand == null) 
        	throw new Exception("parent() can't find an ExplicitRelationshipAccess");
        if (accesorCommand.relationshipTableName == "" || accesorCommand.relationshipTableName == null) 
        	throw new Exception("parent() can't be used without a relation path");
        //
    	EntityType entityET = codeGenerator.getSymbolTable().getBaseEntityType();
        Aspect relationshipLayer = codeGenerator.getSymbolTable().getAspect("relationship");
    	EntityType relationshipET = codeGenerator.getSymbolTable().getEntityType(relationshipLayer.get("entityTypeName").toString());
    	String parent = relationshipLayer.get("left").toString();
    	String child = relationshipLayer.get("right").toString();
        //
        boolean isLeftChild = (whatSideOf(accesorCommand) == -1);
        //
        leftTableName = accesorCommand.leftTableName;
        rightTableName = accesorCommand.rightTableName;
        //
        if (isLeftChild) {
            code.append("(").append(leftTableName).append(".").append(entityET.getProperty("id").persistentPropertyName).append(" = ");
            code.append(accesorCommand.relationshipTableName).append(".").append(relationshipET.getProperty(child).persistentPropertyName);
            code.append(" AND ").append(rightTableName).append(".").append(entityET.getProperty("id").persistentPropertyName).append(" = ");
            code.append(accesorCommand.relationshipTableName).append(".").append(relationshipET.getProperty(parent).persistentPropertyName);
            code.append(")");
        } else {
            code.append("(").append(rightTableName).append(".").append(entityET.getProperty("id").persistentPropertyName).append(" = ");
            code.append(accesorCommand.relationshipTableName).append(".").append(relationshipET.getProperty(child).persistentPropertyName);
            code.append(" AND ").append(leftTableName).append(".").append(entityET.getProperty("id").persistentPropertyName).append(" = ");
            code.append(accesorCommand.relationshipTableName).append(".").append(relationshipET.getProperty(parent).persistentPropertyName);
            code.append(")");
        }        
    }
}
