package org.aspect.core.aql.expressions;

public class QueryMemberAccess extends Expression {
	
    public QueryMemberAccess(String memberName, Expression expression) {
    	this.text = memberName;
    	this.value = memberName;
    	this.leftExpression = value;
    	this.rightExpression = expression;
    }

	@Override
    public Expression clone() {
        Expression right = (rightExpression instanceof Expression)? ((Expression)rightExpression).clone(): null;
        return new QueryMemberAccess(leftExpression.toString(), right);
    } 
	
}
