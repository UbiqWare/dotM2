package org.aspect.core.aql.expressions;

public class PropertyAccessForAspectFilter extends Expression {

    public PropertyAccessForAspectFilter(String role) {
        this.text = role;
        this.value = this.text.replace("@", "");
        this.leftExpression = this.value;
    }
    
    public PropertyAccessForAspectFilter(Expression propertyAccess) {
    	this(propertyAccess.value.toString());    	
    }

	@Override
    public Expression clone() {
		PropertyAccessForAspectFilter e = new PropertyAccessForAspectFilter("@" + leftExpression.toString());
		return e;
    }
	
}
