package org.aspect.core.aql.expressions;

public class EmbeddedAccess extends Expression {
    public EmbeddedAccess(Expression baseExpression, String embeddedPropertyName) {
    	this.text = embeddedPropertyName;
    	this.value = embeddedPropertyName;
    	this.leftExpression = baseExpression;
    	this.rightExpression = embeddedPropertyName;
    }


	@Override
    public Expression clone() {
        Expression left = (leftExpression instanceof Expression)? ((Expression)leftExpression).clone(): null;
        return new EmbeddedAccess(left, rightExpression.toString());
    } 
}
