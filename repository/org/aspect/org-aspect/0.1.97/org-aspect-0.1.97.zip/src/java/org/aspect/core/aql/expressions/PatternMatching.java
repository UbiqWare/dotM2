package org.aspect.core.aql.expressions;

public class PatternMatching extends Expression {

    public PatternMatching(Expression left, Expression right) {
    	this.text = "=~";
    	this.value = left.value + " =~ " + right.value;
    	this.leftExpression = left;
    	this.rightExpression = right;
    }

	@Override
    public Expression clone() {
        Expression left = (leftExpression instanceof Expression) ? ((Expression)leftExpression).clone() : null;
        Expression right = (rightExpression instanceof Expression) ? ((Expression)rightExpression).clone() : null;
        return new PatternMatching(left, right);
    }
	
}
