// TODO Move to core
package org.aspect.core.aql;

import java.util.Map;

import org.aspect.core.aql.entites.EntityType;

public class Aspect {
	
	public final static String FILTER_SECURITY_ASPECT_NAME = "security";
	
	public String name;
	public EntityType entityType;
	public Map<String, Object> properties;
	public String aggregateOf = "";
	public Aspect aggregateOfAspect = null;
	
	public boolean isAggregateOf() {
		return !aggregateOf.equals("");
	}
	
	public boolean isMaster() {
		return properties.get("right") == null;
	}
	
	public Object get(String property) {
		return properties.get(property);
	}
	
	public Aspect(Map<String, Object> properties) {
		this.properties = properties;
	}
	
	public Aspect(String name, EntityType entityType, Map<String, Object> properties) {
		this.name = name;
		this.entityType = entityType;
		this.properties = properties;
	}
	
	public Aspect(String name, EntityType entityType, Map<String, Object> properties, String aggregateOf) {
		this(name, entityType, properties);
		this.aggregateOf = aggregateOf;
	}
}
