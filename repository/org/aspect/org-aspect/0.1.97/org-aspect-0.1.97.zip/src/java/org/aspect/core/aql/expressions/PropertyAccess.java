package org.aspect.core.aql.expressions;

public class PropertyAccess extends Expression {

	public int contextLevelAccess = 0;

    public PropertyAccess(String rol, int contextLevelAccess) {
        this.text = "@" + rol;
        this.value = this.text;
        this.leftExpression = rol;
        this.rightExpression = new Integer(contextLevelAccess);
        this.contextLevelAccess = contextLevelAccess;
    }

	@Override
    public Expression clone() {
		if (rightExpression instanceof Integer) {
			return new PropertyAccess(leftExpression.toString(), contextLevelAccess);
		} else {
			PropertyAccess e = new PropertyAccess(leftExpression.toString(), contextLevelAccess);
			e.rightExpression = (rightExpression instanceof Expression) ? ((Expression)rightExpression).clone() : null;
			return e;
		}
    }
	
}
