package org.aspect.core.aql.entites;

public class ConstantPropertyType extends PropertyType {
	String value = "";

	public ConstantPropertyType(String name, String persistentPropertyName, String value) {
		super(name, null, persistentPropertyName);
		this.isConstant = true;
		this.value = value;
	}


}
