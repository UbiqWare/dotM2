package org.aspect.core.aql.codegenerators.sql.sqlserver;

import java.util.List;

import org.aspect.core.aql.codegenerators.sql.ExpressionListCommand;
import org.aspect.core.aql.codegenerators.sql.ExternalFunctionStandard;

public class PageExternalFunctionCommand extends ExternalFunctionStandard {
    @Override
    public StringBuilder toCode(ExpressionListCommand args, List<String> argsCode) {
        String outerTableName = functionCommand.codeGenerator.getNewTableId();
    	// TODO Get ".id" from metadata
        String orderBy = "ORDER BY " + tableName + ".id";
        // If the criteria is specified, we include it
        if (argsCode.size() == 4) {
            orderBy = "ORDER BY " + argsCode.get(3).trim();
        }
        //
        code.append("SELECT ").append(outerTableName).append(".* FROM (SELECT ").append(tableName).append(".*, ROW_NUMBER() OVER(")
        	.append(orderBy).append(") as RowNumber FROM (").append(argsCode.get(0).trim()).append( ") ").append(tableName)
        	.append(")").append(outerTableName).append(" WHERE ").append(outerTableName).append(".RowNumber BETWEEN ")
        	.append(argsCode.get(1).trim()).append(" AND ").append(argsCode.get(2).trim());
        //
        return code;    }

}
