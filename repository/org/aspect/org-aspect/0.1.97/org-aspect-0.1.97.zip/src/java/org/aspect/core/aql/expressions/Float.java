package org.aspect.core.aql.expressions;

public class Float extends Expression {

    public Float(String value) {
    	this.text = value;
    	this.value = new java.lang.Float(value);
    	this.leftExpression = value;
    	this.rightExpression = null;
    }
	
    public Float(java.lang.Float value) {
    	this.text = String.valueOf(value);
    	this.value = value;
    	this.leftExpression = new java.lang.Float(value);
    	this.rightExpression = null;
    }

	@Override
    public Expression clone() {
        return new Float(new java.lang.Float((java.lang.Float)value));
    }
	
}
