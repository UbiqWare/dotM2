package org.aspect.core.aql.codegenerators.sql;

public class BoolCommand extends Command {
	@Override
	public void toCode() {
        code.append(expression.text);
    }
}
