package org.aspect.core.aql.codegenerators.sql;

import java.util.List;

public class InSetExternalFunctionCommand extends ExternalFunctionStandard {
    @Override
    public StringBuilder toCode(ExpressionListCommand args, List<String> argsCode) {
        return code.append("( EXISTS( SELECT ").append(argsCode.get(1)).append(" FROM (")
        			.append(argsCode.get(0)).append(") ").append(tableName).append(" WHERE ")
        			.append(argsCode.get(1)).append(" = ").append(argsCode.get(2)).append("))");
    }
}
