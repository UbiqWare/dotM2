package org.aspect.core.aql.codegenerators.sql;

public class FieldOrderByCommand extends Command {
    @Override 
    public void toCode() {
    	String rightCode = right.code.toString().replace("'", "");
    	code.append(left.code).append(" ").append(rightCode).append(" ");
    }
}
