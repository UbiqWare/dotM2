package org.aspect.core.aql.codegenerators.sql;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.aspect.core.aql.SymbolTable;
import org.aspect.core.aql.codegenerators.CodeGenerator;
import org.aspect.core.aql.codegenerators.CodeGeneratorCommand;
import org.aspect.core.aql.codegenerators.sql.entities.SqlPersistentEntityType;
import org.aspect.core.aql.entites.EntityType;
import org.aspect.core.aql.entites.EntityTypeRelationship;
import org.aspect.core.aql.entites.PersistentEntityType;
import org.aspect.core.aql.entites.PropertyFullNameArg;
import org.aspect.core.aql.entites.PropertyType;
import org.aspect.core.aql.expressions.Expression;

public abstract class Command implements CodeGeneratorCommand {
	public static final String DEFAULT_FIELD_ID 		= "id";
	public static final String AGGREGATE_FIELD_SEPARATOR = "_1_";
	public static final String FIELD_SEPARATOR = "_2_";
	public static final String EMBEDDED_FIELD_SEPARATOR = "_3_";
	public static final String WORD_SEPARATOR = "_";

    public Command left;
    public Command right;
    public Command parent;
    public Expression expression;
    public StringBuilder code;

    public String tableName;
    public String leftTableName;
    public String rightTableName;
    public SymbolTable symbolTable;
    public SqlCodeGenerator codeGenerator;
    
	public EntityType entityType = null;

	private List<String> whereConditionList = new ArrayList<String>();
	List<String> extraSelectFieldList = new ArrayList<String>();
	List<Command> agregateCommandList = new ArrayList<Command>();


	public Command() {
        this.symbolTable = new SymbolTable();
        this.tableName = "";
        this.expression = null;
        code = new StringBuilder();
    }
    
    public Command(Expression expression) {
		this.expression = expression;
    }

    public static String externalFunctionNameSpacePrefix = "org.aspect.core.aql.codegenerators.sql.";
    
	public static Command createCommandFromExpression(Expression expression) 
			throws ClassNotFoundException, IllegalAccessException, InstantiationException  
	{
    	ClassLoader classLoader = Command.class.getClassLoader();
    	Class<?> classLoaded;
       	String simpleClassName = expression.getClass().getSimpleName();
       	classLoaded = classLoader.loadClass(externalFunctionNameSpacePrefix + simpleClassName + "Command");
		Command command = (Command)classLoaded.newInstance();
		command.setExpression(expression);
        return command;
    }
	
    public void setExpression(Expression value) {
    	this.expression = value;
    }
    
    public Expression getExpression() {
    	return expression;
    }

	public CodeGenerator getCodeGenerator() {
		return codeGenerator;
	}
	
	public void setCodeGenerator(CodeGenerator value) {
		this.codeGenerator = (SqlCodeGenerator)value;
	}

    public boolean anyWhereConditionSpecified() {
    	return this.whereConditionList.size() > 0;
    }

    public void addWhereCondition(String condition) {
    	if (condition.equals("")) return;
    	this.whereConditionList.add(condition);
    }

    StringBuilder buildWhereSentence(String start, String end) {
    	StringBuilder where = new StringBuilder();
        if (!anyWhereConditionSpecified()) return where;
        where.append(start);
        String and = "";
        for (String condition: whereConditionList) {
            where.append(and).append(condition);
            and = " AND ";
        }
        where.append(end);
        return where;
    }

    public void addExtraFieldToSelect(String field) {
        extraSelectFieldList.add(field);
    }
    
    public StringBuilder buildExtraSelectField() {
        StringBuilder extraSelect = new StringBuilder();
        for (String extraField: extraSelectFieldList) {
        	extraSelect.append(", ").append(extraField);
        }
        return extraSelect;
    }
    
    
    public void addToAgregateCondition(Command agregateCommand) {
        agregateCommandList.add(agregateCommand);
    }

    
	StringBuilder buildAggregateCommands() {
		StringBuilder aggregate = new StringBuilder();
		String id = codeGenerator.getSymbolTable().getBaseEntityType().getProperty("id").persistentPropertyName;
        for (Command agregateCommand: agregateCommandList) {
        	aggregate.append(" LEFT JOIN ( ").append(agregateCommand.left.code).append(") ").append(agregateCommand.tableName).append(" ON ").append(tableName)
        			 .append(".").append(id).append(" = ").append(agregateCommand.tableName).append(".").append(id);
        }
		return aggregate;
	}
	
    public boolean addRightPredicateWhereCondition() {
        // if predicate doesn't exist -> return
        if (right == null) return false;
        Command accessCommand = codeGenerator.peekRelationAccessCommand();
        if (accessCommand != null) {
            accessCommand.addWhereCondition(right.code.toString());
        } else {
            if (right.code.length() != 0)
                addWhereCondition(right.code.toString());
            else
                return false;
        }
        return true;
    }
    
    public boolean isReferenceAccess() {
        return 		(this instanceof ExpressionAccessByRefCommand) 
        		|| 	(this instanceof ExternalFunctionAccessCommand)
        ;
    }

    boolean isRelationAccess() {
        return this instanceof ExplicitRelationshipAccessCommand;
    }

    public int whatSideOf(Command root) {
        if (root == null) return 0;
        Command command = this;
        Command leftCandidate = null;
        while (command != root && command != null) {
            leftCandidate = command;
            command = command.parent;
        }
        return (command != root) ? 0 : (command.expression.leftExpression == leftCandidate.expression) ? -1 : 1;
    }
    
	HashMap<String, String> persistentEntityNameIdMap = new HashMap<String, String>();

    public StringBuilder buildSelectFromEntityType(EntityType entityType, boolean treatIdAsOtherProperties, boolean justIdsFromJoinProperties, String fixedPrefix) {
    	StringBuilder query = buildSelectFromEntityType(entityType, null, treatIdAsOtherProperties, justIdsFromJoinProperties, fixedPrefix);
    	return query;
    }
	
    public StringBuilder buildSelectFromEntityType(EntityType entityType, boolean treatIdAsOtherProperties, String fixedPrefix) {
    	StringBuilder query = buildSelectFromEntityType(entityType, null, treatIdAsOtherProperties, false, fixedPrefix);
    	return query;
    }
	
    public StringBuilder buildSelectFromEntityType(EntityType entityType, boolean treatIdAsOtherProperties) {
    	StringBuilder query = buildSelectFromEntityType(entityType, null, treatIdAsOtherProperties, false, "");
    	return query;
    }

	public StringBuilder buildSelectFromEntityType(EntityType entityType) {
    	StringBuilder query = buildSelectFromEntityType(entityType, null);
    	return query;
    }
    
    public StringBuilder buildSelectFromEntityType(EntityType entityType, PersistentEntityType targetPET) {
    	return buildSelectFromEntityType(entityType, targetPET, false, false, "");
    }

    public StringBuilder buildSelectFromEntityType(EntityType entityType, PersistentEntityType targetPET, boolean treatIdAsOtherProperties, boolean justIdsFromJoinProperties, String fixedPrefix) {
    	//
    	StringBuilder select = buildSelectFromEntityTypeOnlyProperties(entityType, targetPET, treatIdAsOtherProperties, fixedPrefix);
    	select.append(buildSelectFromEntityTypeOnlyJoinRelationship(entityType, justIdsFromJoinProperties, fixedPrefix));
        return select;
    }

	private StringBuilder buildSelectFromEntityTypeOnlyProperties(EntityType entityType, PersistentEntityType targetPET, boolean treatIdAsOtherProperties, String fixedPrefix) {
		//
		StringBuilder select = new StringBuilder();
        String separator = "";
        //
    	for (PropertyType property: entityType.getProperties()) {
    		if (!property.isPersisted && !property.isConstant && !property.isCalculated) continue;
    		//
            PropertyFullNameArg args = property.loadFullNameArg(entityType, targetPET, treatIdAsOtherProperties, fixedPrefix, persistentEntityNameIdMap);
    		property.buildFullName(args);
            property.buildKeyFullName(args);
            //
            symbolTable.add(args.keyFullName, args.propertyFullName);
            //
            select.append(separator).append(args.code);
            separator = ", ";
    	}
    	return select;
	}

    private StringBuilder buildSelectFromEntityTypeOnlyJoinRelationship(EntityType entityType, boolean justIdsFromJoinProperties, String fixedPrefix) {
        //
    	StringBuilder select = new StringBuilder();
        String separator = ", ";
    	for (EntityTypeRelationship r: entityType.getPersistentEntityTypeRelationships()) {
	    	for (PropertyType property: r.right.getProperties()) {
	    		if (!property.isPersisted && !property.isConstant) continue;
	    		if (justIdsFromJoinProperties && !property.name.equals(Command.DEFAULT_FIELD_ID)) continue;
	            PropertyFullNameArg args = r.loadFullNameArg(property, entityType, fixedPrefix, persistentEntityNameIdMap);
	    		r.buildFullName(args);
	            r.buildKeyFullName(args);
	            //
	            symbolTable.add(args.keyFullName, args.propertyFullName);
	            //
	            select.append(separator).append(args.code);
	            separator = ", ";
    		}
    	}
        //
    	return select;
	}
	
	// An "id" is set for every persistent entity
    protected void assignTableIdToPersistentEntities(EntityType entityType, HashMap<String, String> persistentEntityNameMap) {
	    for (Map.Entry<String, PersistentEntityType> petEntry: entityType.getPersistentEntityTypesMap().entrySet()) 
	    	persistentEntityNameMap.put(petEntry.getKey(), codeGenerator.getNewTableId());
	}
    
    void assignTableIdToPersistentEntities(EntityType entityType) {
    	assignTableIdToPersistentEntities(entityType, persistentEntityNameIdMap);
	}

    protected StringBuilder buildJoinFromEntityType(EntityType entityType, PersistentEntityType firstPET, StringBuilder firstOn) {
    	StringBuilder query = new StringBuilder();
    	query.append(buildJoinHierarchyFromEntityType(entityType, firstPET, firstOn));
    	query.append(buildLeftJoinFromEntityType(entityType));
    	return query;
    }
    
    public StringBuilder buildJoinHierarchyFromEntityType(EntityType entityType, PersistentEntityType firstPET, StringBuilder firstOn) {
    	StringBuilder query = new StringBuilder();
    	String join = "";
    	for (PersistentEntityType pet: entityType.getHierarchyPersistentEntityTypes()) {
    		SqlPersistentEntityType sqlPET = (SqlPersistentEntityType)pet;
            query.append(join).append(pet.name).append(" ").append(persistentEntityNameIdMap.get(pet.alias));
    		if (join == "") {
    			if (firstOn != null)
    				query.append(" ").append(firstOn);
    			join = " INNER JOIN ";
    		} else {
	            query.append(" ON ").append(persistentEntityNameIdMap.get(pet.alias)).append(".").append(sqlPET.id.name).append(" = ");
	            query.append(persistentEntityNameIdMap.get(firstPET.alias)).append(".").append(firstPET.id.name);
    		}
    	}
    	return query;
    }    

    public StringBuilder buildLeftJoinFromEntityType(EntityType entityType) {
    	StringBuilder query = new StringBuilder();
    	for (EntityTypeRelationship r: entityType.getPersistentEntityTypeRelationships()) {
    		PropertyType leftProperty = r.left.getProperty(r.leftPropertyId);
    		PersistentEntityType leftPET = codeGenerator.getSymbolTable().getPersistentEntityType(leftProperty.persistentEntityName);
    		String firstTableName = "",  firstPersistentPropertyName = "";
    	    for (PersistentEntityType rightPET: r.right.getHierarchyPersistentEntityTypes()) {
        		String rightTableName = persistentEntityNameIdMap.get(r.getFullAliasForLeftPET(rightPET));
        		String leftTableName = persistentEntityNameIdMap.get(leftPET.alias);
                query.append(" LEFT JOIN ").append(rightPET.name).append(" ").append(rightTableName).append(" ON ")
            	 	 .append(rightTableName).append(".").append(rightPET.id.name).append(" = ");
        		if (firstTableName.equals("")) {
        			query.append(leftTableName).append(".").append(leftProperty.persistentPropertyName);
        		} else {
        			query.append(firstTableName).append(".").append(firstPersistentPropertyName);
        		}
    			firstTableName = rightTableName;
    			firstPersistentPropertyName = rightPET.id.name;
    	    }
    	}
    	//
    	return query;
    }    

    public String getTableNameByProperty(String propertyName, int side) {
        switch (side) {
        	case -1: // Left side
        		return leftTableName;
        	case +1: // Right side
        		return rightTableName;
        	default: // 0 No side
        		return tableName;
        }
	}

    
	public static String getPropertyNameByConvention(String name) {
		StringBuilder conventionalName = new StringBuilder();
		for(char ch: name.toCharArray()) {
			if (Character.isUpperCase(ch)) {
				conventionalName.append(Command.WORD_SEPARATOR);
			}
			conventionalName.append(Character.toLowerCase(ch));
		}
		return conventionalName.toString();
	}
	
    public static StringBuilder getAliasByConvention(String fieldName, String tableName, String aliasFieldName) {
    	StringBuilder localCode = new StringBuilder();
        localCode.append(fieldName).append(" ");
        if (tableName != null)
        	localCode.append(Command.getPropertyNameByConvention(tableName)).append(Command.FIELD_SEPARATOR);
        localCode.append(Command.getPropertyNameByConvention(aliasFieldName));
    	return localCode;
    }
	
    public String getCurrentTableName(PropertyAccessCommand source) {
    	// source == null only from ExistFunction
    	//if (source == null) return tableName;
    	if (source.relationAccessCandidate == null)
    		return tableName;
   		return source.relationAccessCandidate.getTableNameByProperty(source.propertyName, whatSideOf(source.relationAccessCandidate));
    }

	public String getCurrentTableNameBySide(Command source) {
		int side = source.whatSideOf(this);
		if (side < 0) return leftTableName;
		//else if (side > 0) return rightTableName;
		else return rightTableName;//tableName;
	}

    public String getFullPathPropertyName(PropertyAccessCommand source) {
    	// Map where all related commands will be included
    	HashMap<Command, Object> commandAffected = new HashMap<Command, Object>();
    	// Getting context level from the current command
		int contextLevel = codeGenerator.getContextLevel(this);
		// We add all commands related. Removing all command that ":" operator skips
		for (int i = source.contextLevelAccess; i <= contextLevel; i++) {
			Command command = codeGenerator.peekCommandContext(i);
			commandAffected.put(command, command);
			PropertyAccessCommand pac = (command instanceof PropertyAccessCommand) ? (PropertyAccessCommand)command : null ;
			if (pac != null) i += pac.contextLevelAccess; 
		}
		//
		StringBuilder prefix = new StringBuilder();
		PropertyType p = null;
		Command firstCommand = codeGenerator.peekCommandContext(contextLevel);
		Command lastCommand = firstCommand;
		Command command = null;
		for (int level = contextLevel; level >= 0; level--) {
			command = codeGenerator.peekCommandContext(level);
			while (commandAffected.get(command) == null && level >= 0) {
				--level;
				if (level >= 0) 	command = codeGenerator.peekCommandContext(level);
			}
			if (level < 0) continue;
			//
			PropertyAccessCommand pac = (command instanceof PropertyAccessCommand) ? (PropertyAccessCommand)command : null ;
			if (pac != null) {
				p = lastCommand.getPropertyByPAC(pac);
				boolean isJoinRelationship = (p == null) || p.isJoinRelationship && firstCommand.isNamedSubquery();
				if (isJoinRelationship) {
					prefix.append(getPropertyNameByConvention(pac.propertyName) + Command.AGGREGATE_FIELD_SEPARATOR);
				}
			}
			lastCommand = command;
		}
		p = lastCommand.getPropertyByPAC(source);
		String propertyNameByConvention = Command.getPropertyNameByConvention(p.name);
		if (prefix.length() == 0 && p.name.equals(Command.DEFAULT_FIELD_ID)) {
			prefix.append(propertyNameByConvention);
		} else {
			if (firstCommand.isNamedSubquery()) {
				prefix.append(p.persistentEntityName).append(Command.FIELD_SEPARATOR).append(propertyNameByConvention);
			} else {
				prefix.append(propertyNameByConvention);
			}
		}
		return prefix.toString();
    }
    
	public boolean isNamedSubquery() {
		return true;
	}

	public PropertyType getPropertyByPAC(PropertyAccessCommand pac) {
		pac.entityType = (pac.entityType == null) ? entityType : pac.entityType;
		return getPropertyByPAC(pac, entityType);
	}

	public PropertyType getPropertyByPAC(PropertyAccessCommand pac, EntityType localEntityType) {
		PropertyType p = null;
		p = (localEntityType == null || pac == null) ? null : localEntityType.getProperty(pac.getPropertyName());
		if (p == null) {
			EntityTypeRelationship r = (localEntityType == null) ? null : localEntityType.getRelationshipByName(pac.propertyName);
			if (r != null) {
				pac.entityType = r.right;
				PropertyType propertyNameId = localEntityType.getProperty(r.leftPropertyId); 
				p = new PropertyType(pac.propertyName, propertyNameId.persistentEntityName, pac.propertyName);
			}
		}
		return p;
	}
	
    
	@Override
    public Command getCurrentCommandWithEntityType() {
        return this;
    }
    
	@Override
    public Command getCurrentCommandWithSymbolTable() {
        return null;
    }

    @Override
    public Command getCurrentCommandWithTableName() {
        return null;
    }

    @Override
    public Command getRelationAccess() {
        return null;
    }
	
	@Override
	public void toCode() throws Exception {
	}
    
	@Override
	public void onBeforeLeftToCode() {
	}

	@Override
	public void onBeforeRightToCode() {
	}

	@Override
	public void onAfterToCode() {
	}
	
	@Override
    public void onBeforeArgToCode(Expression expression, int position) {
    }

	@Override
    public void onAfterArgToCode(CodeGeneratorCommand command, int position) {
    }

	public void addToSymbolTable(String name, String value) {
		symbolTable.add(name.toLowerCase(), value);
	}

	public void addToSymbolTable(SymbolTable sourceSymbolTable) {
		symbolTable.addAll(sourceSymbolTable);
	}
	
}
