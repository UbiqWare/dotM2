package org.aspect.core.aql.codegenerators.sql;

import java.util.List;

import org.aspect.core.aql.expressions.ExplicitRelationshipAccess;
import org.aspect.core.aql.expressions.ExpressionList;

public class GroupExternalFunctionCommand extends ExternalFunctionStandard {

    @Override
    public ExpressionList buildArgs(ExpressionList args) {
        ExpressionList list = new ExpressionList();
        if ( (args.getList().size() == 2) && (args.getList().get(0) instanceof ExplicitRelationshipAccess)) {
            list.add(args.getList().get(0));
            list.add(args.getList().get(1));
        } else {
            list.add(new ExplicitRelationshipAccess(args.getList().get(0), args.getList().get(1), 0));
            list.add(args.getList().get(2));
        }
        return list;
    }

    // 
    String idField;
	
    @Override
    public void onBeforeLeftToCode() {
    	super.onBeforeLeftToCode();
        idField = functionCommand.codeGenerator.getSymbolTable().getBaseEntityType().getProperty("id").persistentPropertyName;
        functionCommand.addToSymbolTable(idField, idField);
    }
    
    
	@Override
    public StringBuilder toCode(ExpressionListCommand args, List<String> argsCode) {
		//
        StringBuilder groupedFieldList = buildGroupFieldList((ExpressionListCommand)args.commandList.get(1));
        code.append(" SELECT ").append(tableName).append(".").append(idField).append(", ").append(groupedFieldList);
        code.append(" FROM (").append(argsCode.get(0)).append(") ").append(tableName);
        code.append(" GROUP BY ").append(tableName).append(".").append(idField);
		//
    	return code;
    }

    StringBuilder buildGroupFieldList(ExpressionListCommand commandInitializeList) {
        StringBuilder group = new StringBuilder();
        String separator = "";
        for (Command fieldInit: commandInitializeList.commandList) {
            FieldInitializeCommand field = (FieldInitializeCommand) fieldInit;
            String propertyName = field.left.expression.value.toString().toLowerCase();
            functionCommand.addToSymbolTable(propertyName, propertyName);
        	group.append(separator);
        	String propertyValue = field.right.code.toString();
        	group.append(Command.getAliasByConvention(propertyValue, functionName, propertyName));
            separator = ", ";
        }
        return group;
    }
	
}
