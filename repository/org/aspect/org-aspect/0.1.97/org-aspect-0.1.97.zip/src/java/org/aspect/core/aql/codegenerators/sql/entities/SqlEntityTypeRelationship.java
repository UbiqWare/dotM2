package org.aspect.core.aql.codegenerators.sql.entities;

import org.aspect.core.aql.codegenerators.sql.Command;
import org.aspect.core.aql.entites.EntityType;
import org.aspect.core.aql.entites.EntityTypeRelationship;
import org.aspect.core.aql.entites.PersistentEntityType;

public class SqlEntityTypeRelationship extends EntityTypeRelationship {

	public SqlEntityTypeRelationship(EntityType right, String leftPropertyName, String leftPropertyId) {
		super(right, leftPropertyName, leftPropertyId);
	}

	public EntityTypeRelationship clone() {
		EntityTypeRelationship cloneETR = new SqlEntityTypeRelationship(right, leftPropertyName, leftPropertyId);
		cloneETR.left = left;
		cloneETR.rawLeftPropertyName = rawLeftPropertyName; 
		return cloneETR;
	}
	
	public static String getFullAlias(String rightEntityName, String propertyName, String leftEntityName) {
        String key = rightEntityName + EntityTypeRelationship.PREFIX_SEPARATOR + propertyName + Command.AGGREGATE_FIELD_SEPARATOR + leftEntityName;
		return key;
	}

	public String getAliasForLeftPET(String petName, String prefix) {
		// TODO check
		return 	prefix + rawLeftPropertyName.toLowerCase() + Command.AGGREGATE_FIELD_SEPARATOR + petName.toLowerCase(); 
	}

	public String getFullName(String persistentEntityName, String localPropertyName) {
		return 	rawLeftPropertyName.toLowerCase() 
				+ Command.AGGREGATE_FIELD_SEPARATOR + persistentEntityName.toLowerCase() 
				+ Command.FIELD_SEPARATOR + localPropertyName.toLowerCase();
	}
	
	public String getFullAliasForLeftPET(PersistentEntityType entityPET) {
		String prefix = (left == null) ? "" : left.name + PREFIX_SEPARATOR;
		return getAliasForLeftPET(entityPET.alias, prefix);
	}

	public String getAliasForLeftPET(PersistentEntityType entityPET) {
		return getAliasForLeftPET(entityPET.alias);
	}
	
	public String getAliasForLeftPET(String petName) {
		return 	getAliasForLeftPET(petName, ""); 
	}
	
}
