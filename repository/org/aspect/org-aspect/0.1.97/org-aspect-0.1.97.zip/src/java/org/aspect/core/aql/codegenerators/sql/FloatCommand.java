package org.aspect.core.aql.codegenerators.sql;

public class FloatCommand extends Command {
	@Override
	public void toCode() {
        code.append(expression.text);
    }
}
