package org.aspect.core.aql.codegenerators.sql;

import org.aspect.core.aql.entites.PersistentEntityType;
import org.aspect.core.aql.entites.PropertyType;

public class InnerRelationshipAccessCommand extends	ExplicitRelationshipAccessCommand {

	@Override
    public void onBeforeLeftToCode() {
    	//
        leftTableName = codeGenerator.getNewTableId();
        rightTableName = codeGenerator.getNewTableId();
        //
        codeGenerator.openCommandContext(this);
    }

	@Override
	public void toCode() {
		entityType = right.entityType;
		super.toCode();
    }
	
	@Override
	protected StringBuilder buildFromSentence() {
		//
    	StringBuilder from = new StringBuilder();
    	//
    	PersistentEntityType firstLeftPET = left.entityType.getHierarchyPersistentEntityTypes().get(0);
    	PersistentEntityType firstRightPET = right.entityType.getHierarchyPersistentEntityTypes().get(0);
    	
    	//
        from.append(" (").append(right.code).append(") ").append(rightTableName);
        from.append(" INNER JOIN (").append(left.code).append(") ").append(leftTableName);
        from.append(" ON ").append(leftTableName).append(".").append(firstLeftPET.id.name).append(" = ");
        from.append(rightTableName).append(".").append(firstRightPET.id.name);
        //
        return from;
	}

	@Override
	protected StringBuilder buildSelectSentence() {
    	//
    	StringBuilder select = new StringBuilder();
		if (codeGenerator.getGraphRequired()) {
			// TODO Look at ExplicitRelationshipAccessCommand
		} else {
			select.append(rightTableName).append(".* ");
		}
		return select;
	}

	@Override
	public PropertyType getPropertyByPAC(PropertyAccessCommand pac) {
		PropertyType p = null;
		if (!(codeGenerator.peekCommandContext() instanceof PropertyAccessCommand)) {
    		pac.entityType = right.entityType;
			p = right.getPropertyByPAC(pac);
		} else {
    		p = new PropertyType(pac.propertyName, pac.propertyName, pac.propertyName);
			PropertyAccessCommand command = (PropertyAccessCommand)codeGenerator.peekCommandContext();
			if (pac.propertyName.equals("right")) {
	    		pac.entityType = right.entityType;
			} else if (pac.propertyName.equals("left")) {
	    		pac.entityType = left.entityType;
			} else if (command.propertyName.equals("left")) {
				// TODO
				p.isJoinRelationship = true;
	    		p = left.getPropertyByPAC(pac);
			} else { // It could be a join field of right, like @type
	    		p.isJoinRelationship = true;
	    		p = right.getPropertyByPAC(pac);
			}
		}
		return p;
	}

	@Override
    public String getCurrentTableName(PropertyAccessCommand source) {
    	if (!(codeGenerator.peekCommandContext() instanceof Command)) {
			return rightTableName;
    	} else {
			PropertyAccessCommand pac = (PropertyAccessCommand)codeGenerator.peekCommandContext();
			if (pac.propertyName.equals("left")) {
				return leftTableName;
			} else {// by default -> pac.propertyName.equals("right"))
				return rightTableName;
			}
    	}
    }

}
