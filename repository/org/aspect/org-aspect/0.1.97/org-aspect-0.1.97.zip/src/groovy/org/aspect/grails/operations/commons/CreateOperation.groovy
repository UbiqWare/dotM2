package org.aspect.grails.operations.commons

import org.aspect.grails.annotations.AspectOperation;

@AspectOperation(signature = "common.create")
class CreateOperation extends CRUDBaseOperation {

	@Override
	def execute() {
		create(entity)
	}

}
