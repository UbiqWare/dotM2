package org.aspect.grails.operations.contents

import org.aspect.grails.annotations.AspectOperation;

@AspectOperation(signature = "content.readData")
class ReadDataOperation  extends ContentOperation {

	@Override
	def execute() {
		readContentData(content)
	}

}
