package org.aspect.grails.operations.commons

import org.aspect.grails.annotations.AspectOperation;

@AspectOperation(signature = "common.update")
class UpdateOperation extends CRUDBaseOperation {

	@Override
	def execute() {
		update(entity)
	}

}
