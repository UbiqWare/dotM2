package org.aspect.grails.exceptions

class AspectException  extends RuntimeException {
	AspectException(String message = null) {
		super(message)
	}
}
