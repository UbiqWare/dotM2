package org.aspect.grails.operations.contents

import org.aspect.grails.annotations.AspectOperation;

@AspectOperation(signature = "content.appendPart")
class AppendPartOperation  extends ContentOperation {

	byte[] part
	
	@Override
	def execute() {
		appendContentPart(content, part)
	}

}
