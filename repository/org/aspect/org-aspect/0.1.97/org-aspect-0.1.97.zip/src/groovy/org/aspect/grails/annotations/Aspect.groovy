package org.aspect.grails.annotations

import java.lang.annotation.ElementType
import java.lang.annotation.Retention
import java.lang.annotation.RetentionPolicy
import java.lang.annotation.Target

// http://isagoksu.com/2009/creating-custom-annotations-and-making-use-of-them/
@Target([ElementType.TYPE])
@Retention(RetentionPolicy.RUNTIME)
public @interface Aspect {
	String name() default ""
	String left() default "left"
	String right() default "null"
	String filter() default "no"
	boolean isDefault() default false
	String description() default ""
	String aggregateOf() default ""
}

