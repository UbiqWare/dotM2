package org.aspect.grails.operations.contents

import org.aspect.grails.annotations.AspectOperation;

@AspectOperation(signature = "content.delete")
class DeleteOperation  extends ContentOperation {

	@Override
	def execute() {
		deleteContent(entity)
	}

}
