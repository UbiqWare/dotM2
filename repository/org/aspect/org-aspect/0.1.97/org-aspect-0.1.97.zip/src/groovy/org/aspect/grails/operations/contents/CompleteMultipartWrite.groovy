package org.aspect.grails.operations.contents

import org.aspect.grails.annotations.AspectOperation;

@AspectOperation(signature = "content.completeMultipartWrite")
class CompleteMultipartWriteOperation extends ContentOperation {
	
	@Override
	def execute() {
		completeMultipartWrite(content)
	}

}
