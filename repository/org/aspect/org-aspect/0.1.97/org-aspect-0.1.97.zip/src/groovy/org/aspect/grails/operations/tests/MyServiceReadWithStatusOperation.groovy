package org.aspect.grails.operations.tests

import org.aspect.grails.annotations.AspectOperation
import org.aspect.grails.operations.ServiceOperation

@AspectOperation(signature = "test.readWithStatus", interpreter="service", innerAspects = 'status')
class MyServiceReadWithStatusOperation extends ServiceOperation {
	def entity
	def useSecurity = false
	def execute() {
		if (useSecurity)
			entity = exec(signature:"test.readWithStatusAndSecurity", args:[entity:entity])
		else
			entity = read(entity)
		entity
	}
}
