package org.aspect.grails.entities

import grails.util.Holders
import org.hibernate.cfg.ImprovedNamingStrategy

// http://stackoverflow.com/questions/25691409/gorm-automatically-prefix-each-table-name-with-the-domain-class-namespace
class HibernateNamespaceNamingStrategy extends ImprovedNamingStrategy {
	/*
    String classToTableName(String className){
        Class clazz = Holders.grailsApplication.domainClasses.find { it.clazz.simpleName == className }.clazz
        String packageName = clazz.getPackage().getName()
        "${packageName}_${className.toLowerCase()}"
    }
    */
}
