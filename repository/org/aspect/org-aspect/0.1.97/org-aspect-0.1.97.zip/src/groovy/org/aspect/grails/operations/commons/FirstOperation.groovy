package org.aspect.grails.operations.commons

import org.aspect.grails.annotations.AspectOperation;
import org.aspect.grails.entities.AbstractOperation;

@AspectOperation(signature = "common.first")
class FirstOperation extends QueryOperation  {
	
	@Override
	def execute() {
		first(q)
	}

}
