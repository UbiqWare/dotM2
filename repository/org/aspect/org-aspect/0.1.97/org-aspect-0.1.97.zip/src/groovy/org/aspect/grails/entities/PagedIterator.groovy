package org.aspect.grails.entities

import java.util.Iterator;

abstract class PagedIterator implements Iterator, Iterable {
	
		protected int offset
		protected int pageSize
		private int current
		private def set
		
		PagedIterator() {
		}
		
		@Override
		public Iterator iterator() {
			return this;
		}
	
		@Override
		public boolean hasNext() {
			if (current + 1 < set.size()) {
				true
			} else  {
				getNextPage()
				set.size() > 0
			}
		}
		
		protected void getNextPage() {
			set = queryNextPage()
			this.offset += set.size()
			this.current = -1
		}
		
		protected abstract def queryNextPage();
	
		@Override
		public Object next() {
			current ++
			if (current < set.size()) {
				set[this.current]
			} else {
				getNextPage()
				if (set.size() > 0) {
					this.current = 0
					set[this.current]
				} else {
					throw new java.util.NoSuchElementException()
				}
			}
		}
		
		@Override
		public void remove() {
			throw new UnsupportedOperationException("remove() not supported")
		}
}