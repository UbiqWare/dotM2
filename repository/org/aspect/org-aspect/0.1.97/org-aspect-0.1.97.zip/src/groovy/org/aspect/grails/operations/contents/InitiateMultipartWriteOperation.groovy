package org.aspect.grails.operations.contents

import org.aspect.grails.annotations.AspectOperation;

@AspectOperation(signature = "content.initiateMultipartWrite")
class InitiateMultipartWriteOperation extends ContentOperation {
	
	def contentProperties

	@Override
	def execute() {
		initiateMultipartWrite(entity, contentProperties)
	}

}
