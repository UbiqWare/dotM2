package org.aspect.grails.operations

import java.util.Map;

import org.aspect.grails.engines.AspectEngine;
import org.aspect.grails.entities.AbstractOperation;
import org.aspect.grails.entities.Interpreter;
import org.aspect.grails.entities.Operation;

class CoreOperation extends AbstractOperation {	
	
}
