package org.aspect.grails.operations.commons

import org.aspect.grails.annotations.AspectOperation;

@AspectOperation(signature = "common.read")
class ReadOperation extends CRUDBaseOperation {

	@Override
	def execute() {
		read(entity) ?: []
	}

}
