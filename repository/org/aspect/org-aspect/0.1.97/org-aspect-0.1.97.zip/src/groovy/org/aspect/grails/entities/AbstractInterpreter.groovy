package org.aspect.grails.entities

import java.util.Map;
import org.apache.commons.logging.LogFactory
import org.aspect.core.aql.Aspect;
import org.aspect.core.aql.entites.InnerAspect;


abstract class AbstractInterpreter extends org.aspect.core.interpreters.AbstractInterpreter {
	/**
	 * All the operations have access to log object
	 */
	protected static final log = LogFactory.getLog(this)

	//
	Binding binding

	def buildBinding() {
		binding = new Binding()
	}

	@Override
	def init() {
		//
		binding = buildBinding()
		// 
		this.result
	}

	@Override
	def execute() {
		//
		def operationImpl = engine.newInstance(operation.localFullName())
		operationImpl.runtimeInterpreter = this
		//
		args.each { key, value -> operationImpl[key] = value }
		// TODO apply inner aspects
		//
		operationImpl?.handle()
	}

	@Override
	public Object finish() {
		this.result
	}

	//
	static String 	ORDER_BY_DEFAULT = "{@id ASC}"
	static Long 	OFFSET_DEFAULT = 0
	static Long 	MAX_DEFAULT = 1000

	//
	def methodMissing(String methodName, args) {
		exec(signature:methodName, args:args)
	}

	def exec(Map args) {
		if (args.containsKey("operation") && args.containsKey("interpreter")) {
			engine.execute(args.operation, args.interpreter, args?.args, args?.executeModifiers)
		} else if (args.containsKey("operation")) {
			engine.execute(args.operation, args?.args ?: [:], args?.executeModifiers ?: [:])
		} else if (args.containsKey("signature")) {
			engine.execute(args.signature, args?.args ?: [:], args?.executeModifiers ?: [:])
		} else if (args.containsKey("query")) {
			engine.executeByQuery(args.query, args?.args ?: [:], args?.executeModifiers ?: [:])
		}
	}

	def query(String aql, Long offset = OFFSET_DEFAULT, Long max = MAX_DEFAULT, String orderBy = ORDER_BY_DEFAULT) {
		engine.query(aql, offset, max, orderBy)
	}

	def queryMap(String aql, Long offset = OFFSET_DEFAULT, Long max = MAX_DEFAULT, String orderBy = ORDER_BY_DEFAULT) {
		engine.queryMap(aql, offset, max, orderBy)
	}

	def queryAll(String aql, Long offset = OFFSET_DEFAULT, Long max = MAX_DEFAULT, String orderBy = ORDER_BY_DEFAULT) {
		engine.queryAll(aql, offset, max, orderBy)
	}

	def queryMapAll(String aql, Long offset = OFFSET_DEFAULT, Long max = MAX_DEFAULT, String orderBy = ORDER_BY_DEFAULT) {
		engine.queryMapAll(aql, offset, max, orderBy)
	}

	def first(String aql, orderBy = null) {
		engine.first(aql, orderBy)
	}

	def firstMap(String aql, orderBy = null) {
		engine.firstMap(aql, orderBy)
	}

	def save(rawEntity) {
		engine.save(rawEntity)
	}

	def create(def rawEntity, def parent = null, def role = null) {
		engine.create(rawEntity, parent, role)
	}

	def read(rawEntity) {
		engine.read(rawEntity)
	}

	def update(rawEntity) {
		engine.save(rawEntity)
	}

	def delete(rawEntity) {
		engine.delete(rawEntity)
	}

	def undelete(rawEntity) {
		engine.undelete(rawEntity)
	}

	def destroy(rawEntity) {
		engine.destroy(rawEntity)
	}

	def link(leftRawEntity, rightRawEntity, rawRoleEntity = null) {
		engine.link(leftRawEntity, rightRawEntity, rawRoleEntity)
	}

	def unlink(leftRawEntity, rightRawEntity, rawRoleEntity = null) {
		engine.unlink(leftRawEntity, rightRawEntity, rawRoleEntity)
	}

	def content(def entity) {
		engine.content(entity)
	}

	def createContent(def entity, def contentProperties, ContentRepository contentRepository) {
		engine.createContent(entity, contentProperties, contentRepository)
	}

	def deleteContent(def entity, def content) {
		engine.deleteContent(entity, content)
	}

	def deleteContent(def entity) {
		engine.deleteContent(entity)
	}

	def truncateContent(def entity) {
		engine.truncateContent(entity)
	}

	def byte[] readContentData(def content) {
		engine.readContentData(content)
	}

	def InputStream getContentDataInputStream(def content) {
		engine.getContentDataInputStream(content)
	}

	def InputStream getEntityContentDataInputStream(def entity) {
		engine.getEntityContentDataInputStream(entity)
	}

	def writeContentData(def content, byte[] data) {
		engine.writeContentData(content, data)
	}

	def appendContentData(def content, byte[] data) {
		engine.appendContentData(content, data)
	}

	def Content initiateMultipartWrite(def entity, def contentProperties) {
		engine.initiateMultipartWrite(entity, contentProperties)
	}

	def Content appendContentPart(def content, byte[] part) {
		engine.appendContentPart(content, part)
	}

	def Content completeMultipartWrite(def content) {
		engine.completeMultipartWrite(content)
	}

	def Boolean abortMultipartWrite(def content) {
		engine.abortMultipartWrite(content)
	}

	public void removeInnerAspect(String innerAspect) {
		engine.removeInnerAspect(innerAspect)
	}

	public void addInnerAspect(String innerAspectName) {
		engine.addInnerAspect(innerAspectName)
	}

	public void addInnerAspect(String innerAspectName, Aspect innerAspect) {
		engine.addInnerAspect(innerAspectName, innerAspect)
	}

	public Map<String, InnerAspect> getInnerAspects() {
		return engine.getInnerAspects()
	}

	def setVariable(String name, String value) {
		engine.setVariable(name, value)
	}

	def getVariable(String name) {
		engine.getVariable(name)
	}

	public void set(String name, Object value) {
		engine.set(name, value);
	}

	public Object get(String name) {
		return engine.get(name);
	}

	def getCurrentUser() {
		engine.currentUser
	}

	def setCurrentUser(def user) {
		engine.currentUser = user
	}
	// TODO Move to org.aspect.core.operations.AbstractOperation in AspectCore
	def findOrSave(def rawEntity, def parent = null, def role = null) {
		engine.findOrSave(rawEntity, parent, role)
	}

}
