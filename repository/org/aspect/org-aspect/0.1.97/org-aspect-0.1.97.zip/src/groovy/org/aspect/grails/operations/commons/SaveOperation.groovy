package org.aspect.grails.operations.commons

import org.aspect.grails.annotations.AspectOperation;

@AspectOperation(signature = "common.save")
class SaveOperation extends CRUDBaseOperation {

	@Override
	def execute() {
		save(entity)
	}

}
