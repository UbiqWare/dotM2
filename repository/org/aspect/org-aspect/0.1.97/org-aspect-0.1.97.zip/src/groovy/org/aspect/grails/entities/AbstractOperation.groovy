package org.aspect.grails.entities

import java.util.Map;
import org.apache.commons.logging.LogFactory
import org.aspect.core.aql.Aspect;
import org.aspect.core.aql.entites.InnerAspect;
import groovy.json.JsonBuilder
import groovy.json.JsonSlurper
/**
 */
abstract class AbstractOperation extends org.aspect.core.operations.AbstractOperation {
	/**
	 * All the operations have access to log object
	 */
	protected static final log = LogFactory.getLog(this)

	//
	@Override
	def init() { 
		this.result 
	}

	//
	@Override	
	def execute() { 
		this.result 
	}
	

	//
	@Override
	def finish()  { 
		this.result 
	}

	//
	def getSessionFactory() {
		runtimeInterpreter.engine.sessionFactory
	}
	
	// TODO Move to org.aspect.core.operations.AbstractOperation in AspectCore
	// In case operation is executed as a LongTermOperation, this properties has the LongTermOperationId of the entity instance
	def longTermOperationId = 0

	// TODO Move to org.aspect.core.operations.AbstractOperation in AspectCore
	def isLongTermOperation() {
		return this.@longTermOperationId != 0
	}
		
	// TODO Move to org.aspect.core.operations.AbstractOperation in AspectCore
	def getLongTermOperation() {
		isLongTermOperation() ? first("LongTermOperation[@id=${this.@longTermOperationId}]") : null
	}

	// TODO Move to org.aspect.core.operations.AbstractOperation in AspectCore
	def getOperation() {
		this.runtimeInterpreter.operation
	}
	
	// TODO Move to org.aspect.core.operations.AbstractOperation in AspectCore
	def static serialize(def o) {
		def r = new JsonBuilder(o).toString()
	}
	
	// TODO Move to org.aspect.core.operations.AbstractOperation in AspectCore
	def static deserialize(String s) {
		def r = new JsonSlurper().parseText(s ?: "{}")
	}
	

	// TODO Move to org.aspect.core.operations.AbstractOperation in AspectCore
	def query(String aql, Long offset = AbstractInterpreter.OFFSET_DEFAULT, Long max = AbstractInterpreter.MAX_DEFAULT, String orderBy = AbstractInterpreter.ORDER_BY_DEFAULT) {
		runtimeInterpreter.query(aql, offset, max, orderBy)
	}

	// TODO Move to org.aspect.core.operations.AbstractOperation in AspectCore
	def queryAll(String aql, Long offset = AbstractInterpreter.OFFSET_DEFAULT, Long max = AbstractInterpreter.MAX_DEFAULT, String orderBy = AbstractInterpreter.ORDER_BY_DEFAULT) {
		runtimeInterpreter.queryAll(aql, offset, max, orderBy)
	}
	
	// TODO Move to org.aspect.core.operations.AbstractOperation in AspectCore
	def queryMapAll(String aql, Long offset = AbstractInterpreter.OFFSET_DEFAULT, Long max = AbstractInterpreter.MAX_DEFAULT, String orderBy = AbstractInterpreter.ORDER_BY_DEFAULT) {
		runtimeInterpreter.queryMapAll(aql, offset, max, orderBy)
	}

	// TODO Move to org.aspect.core.operations.AbstractOperation in AspectCore
	def first(String aql) {
		runtimeInterpreter.first(aql)
	}

	// TODO Move to org.aspect.core.operations.AbstractOperation in AspectCore
	def firstMap(String aql) {
		runtimeInterpreter.firstMap(aql)
	}

	// TODO Move to org.aspect.core.operations.AbstractOperation in AspectCore
	def save(rawEntity) {
		runtimeInterpreter.save(rawEntity)
	}

	// TODO Move to org.aspect.core.operations.AbstractOperation in AspectCore
	def create(rawEntity) {
		runtimeInterpreter.create(rawEntity)
	}
		
	// TODO Move to org.aspect.core.operations.AbstractOperation in AspectCore
	def read(rawEntity) {
		runtimeInterpreter.read(rawEntity)
	}
	
	// TODO Move to org.aspect.core.operations.AbstractOperation in AspectCore
	def update(rawEntity) {
		runtimeInterpreter.save(rawEntity)
	}
	
	// TODO Move to org.aspect.core.operations.AbstractOperation in AspectCore
	def delete(rawEntity) {
		runtimeInterpreter.delete(rawEntity)
	}
	
	// TODO Move to org.aspect.core.operations.AbstractOperation in AspectCore
	def undelete(rawEntity) {
		runtimeInterpreter.undelete(rawEntity)
	}
	
	// TODO Move to org.aspect.core.operations.AbstractOperation in AspectCore
	def destroy(rawEntity) {
		runtimeInterpreter.destroy(rawEntity)
	}
	
	// TODO Move to org.aspect.core.operations.AbstractOperation in AspectCore
	def link(leftRawEntity, rightRawEntity, role = null) {
		runtimeInterpreter.link(leftRawEntity, rightRawEntity, role)
	}
	
	// TODO Move to org.aspect.core.operations.AbstractOperation in AspectCore
	def unlink(leftRawEntity, rightRawEntity, role = null) {
		runtimeInterpreter.unlink(leftRawEntity, rightRawEntity, role)
	}

	// TODO Move to org.aspect.core.operations.AbstractOperation in AspectCore
	def content(def entity) {
		runtimeInterpreter.content(entity)
	}
		
	// TODO Move to org.aspect.core.operations.AbstractOperation in AspectCore
	def createContent(def entity, def contentProperties, ContentRepository contentRepository = null) {
		contentRepository = contentRepository ?: contentProperties?.contentRepository
		runtimeInterpreter.createContent(entity, contentProperties, contentRepository)
	}
	
	// TODO Move to org.aspect.core.operations.AbstractOperation in AspectCore
	def deleteContent(def entity, def content) {
		runtimeInterpreter.deleteContent(entity, content)
	}

	// TODO Move to org.aspect.core.operations.AbstractOperation in AspectCore
	def deleteContent(def entity) {
		runtimeInterpreter.deleteContent(entity)
	}
	
	// TODO Move to org.aspect.core.operations.AbstractOperation in AspectCore
	def truncateContent(def entity) {
		runtimeInterpreter.truncateContent(entity)
	}

	// TODO Move to org.aspect.core.operations.AbstractOperation in AspectCore
	def byte[] readContentData(def content) {
		runtimeInterpreter.readContentData(content)
	}


	def InputStream getContentDataInputStream(def content) {
		runtimeInterpreter.getContentDataInputStream(content)
	}

	def InputStream getEntityContentDataInputStream(def entity) {
		runtimeInterpreter.getEntityContentDataInputStream(entity)
	}

	// TODO Move to org.aspect.core.operations.AbstractOperation in AspectCore
	def writeContentData(def content, byte[] data) {
		runtimeInterpreter.writeContentData(content, data)
	}
	
	// TODO Move to org.aspect.core.operations.AbstractOperation in AspectCore
	def appendContentData(def content, byte[] data) {
		runtimeInterpreter.appendContentData(content, data)
	}

	// TODO Move to org.aspect.core.operations.AbstractOperation in AspectCore
	def Content initiateMultipartWrite(def entity, def contentProperties) {
		runtimeInterpreter.initiateMultipartWrite(entity, contentProperties)
	}

	// TODO Move to org.aspect.core.operations.AbstractOperation in AspectCore
	def Content appendContentPart(def content, byte[] part) {
		runtimeInterpreter.appendContentPart(content, part)
	}

	// TODO Move to org.aspect.core.operations.AbstractOperation in AspectCore
	def Content completeMultipartWrite(def content) {
		runtimeInterpreter.completeMultipartWrite(content)
	}

	// TODO Move to org.aspect.core.operations.AbstractOperation in AspectCore
	def Boolean abortMultipartWrite(def content) {
		runtimeInterpreter.abortMultipartWrite(content)
	}

	// TODO Move to org.aspect.core.operations.AbstractOperation in AspectCore
	public void removeInnerAspect(String innerAspect) {
		runtimeInterpreter.removeInnerAspect(innerAspect)
	}
	
	// TODO Move to org.aspect.core.operations.AbstractOperation in AspectCore
	public void addInnerAspect(String innerAspectName) {
		runtimeInterpreter.addInnerAspect(innerAspectName)
	}
	
	// TODO Move to org.aspect.core.operations.AbstractOperation in AspectCore
	public void addInnerAspect(String innerAspectName, Aspect innerAspect) {
		runtimeInterpreter.addInnerAspect(innerAspectName, innerAspect)
	}
	
	// TODO Move to org.aspect.core.operations.AbstractOperation in AspectCore
	public Map<String, InnerAspect> getInnerAspects() {
		return runtimeInterpreter.getInnerAspects()
	}

	// TODO Move to org.aspect.core.operations.AbstractOperation in AspectCore
	def setVariable(String name, String value) {
		runtimeInterpreter.setVariable(name, value)
	}
	
	// TODO Move to org.aspect.core.operations.AbstractOperation in AspectCore
	def getVariable(String name) {
		runtimeInterpreter.getVariable(name)
	}
	
	// TODO Move to org.aspect.core.operations.AbstractOperation in AspectCore
	def findOrSave(def rawEntity, def parent = null, def role = null) {
		runtimeInterpreter.findOrSave(rawEntity, parent, role)
	}

}
