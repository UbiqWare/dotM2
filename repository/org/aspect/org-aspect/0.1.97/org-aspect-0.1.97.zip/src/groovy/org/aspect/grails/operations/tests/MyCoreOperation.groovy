package org.aspect.grails.operations.tests

import org.aspect.grails.annotations.AspectOperation;
import org.aspect.grails.operations.CoreOperation;

@AspectOperation(signature = "test.myCoreOperation", interpreter="core")
class MyCoreOperation extends CoreOperation {
	def init() {
		log.debug("test.myCoreOperation.init()")
	}
	
	def execute() {
		log.debug("test.myCoreOperation.execute()")
	}
	
	def finish() {
		log.debug("test.myCoreOperation.finish()")
		return "test.myCoreOperation result"
	}
}
