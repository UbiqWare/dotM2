package org.aspect.grails.helpers
//
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream

class ClassUtils {
	/**
	 * 
	 * @param clazz
	 * @return
	 */
	def static String getPackageName(Class clazz) {
		getPackageName(clazz.name)
	}
	
	def static String getPackageName(String className) {
		int lastDot = className.lastIndexOf ('.')
		(lastDot == -1) ? "" : className.substring (0, lastDot)
	}

	def static String getSimpleName(String className) {
		int lastDot = className.lastIndexOf ('.')
		(lastDot == -1) ? className : className.substring (lastDot, className.length())
	}

	/**
	 * Scans all classes accessible from the context class loader which belong to the given package and subpackages.
	 * Adapted from http://snippets.dzone.com/posts/show/4831 and extended to support use of JAR files
	 */
	def static getClasses(String packageName) {
		try {
			ClassLoader classLoader = Thread.currentThread().getContextClassLoader()
			assert classLoader != null
			String path = packageName.replace('.', '/')
			Enumeration resources = classLoader.getResources(path)
			List dirs = new ArrayList()
			while (resources.hasMoreElements()) {
				URL resource = resources.nextElement();
				String fileName = resource.getFile();
				String fileNameDecoded = URLDecoder.decode(fileName, "UTF-8");
				dirs.add(new File(fileNameDecoded));
			}
			TreeSet classes = new TreeSet()
			for (String directory : dirs) {
				classes.addAll(findClasses(directory, packageName))
			}
			ArrayList classList = new ArrayList()
			for (String clazz : classes) {
				classList.add(Class.forName(clazz))
			}
			return classList.toArray(new Class[classes.size()])
		} catch (Exception e) {
			e.printStackTrace()
			return null;
		}
	}
	   
	/**
	 * Recursive method used to find all classes in a given directory and subdirs.
	 * Adapted from http://snippets.dzone.com/posts/show/4831 and extended to support use of JAR files
	 */
	private static TreeSet findClasses(String directory, String packageName) throws Exception {
		TreeSet classes = new TreeSet()
		if (directory.startsWith("file:") && directory.contains("!")) {
			String [] split = directory.split("!")
			URL jar = new URL(split[0])
			ZipInputStream zip = new ZipInputStream(jar.openStream())
			ZipEntry entry = null
			while ((entry = zip.getNextEntry()) != null) {
				if (entry.getName().endsWith(".class")) {
					String className = entry.getName().replaceAll('[$].*', "").replaceAll("[.]class", "").replace('/', '.')
					classes.add(className)
				}
			}
		}
		File dir = new File(directory)
		if (!dir.exists()) {
			return classes
		}
		File[] files = dir.listFiles()
		for (File file : files) {
			String fileName = file.getName();
			if (file.isDirectory()) {
				assert !file.getName().contains(".")
				classes.addAll(findClasses(file.getAbsolutePath(), packageName + "." + file.getName()))
			} else if (fileName.endsWith(".class") && !fileName.contains('$')) {
				classes.add(packageName + '.' + file.getName().substring(0, file.getName().length() - 6));
			}
		}
		return classes
	}
}
