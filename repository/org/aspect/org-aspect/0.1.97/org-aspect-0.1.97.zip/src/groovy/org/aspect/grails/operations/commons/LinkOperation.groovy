package org.aspect.grails.operations.commons

import org.aspect.grails.annotations.AspectOperation;
import org.aspect.grails.operations.CoreOperation;

@AspectOperation(signature = "common.link")
class LinkOperation extends CoreOperation {

	def parent
	def child
	def role
	
	@Override
	def execute() {
		link(parent, child, role)
	}

}
