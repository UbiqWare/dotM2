package org.aspect.grails.loaders

//
import org.apache.commons.io.IOUtils
import org.aspect.core.aql.Aspect;
import org.aspect.core.aql.codegenerators.sql.Command;
import org.aspect.core.aql.entites.EntityType;
import org.aspect.core.aql.entites.EntityTypeRelationship;
import org.aspect.core.aql.entites.PersistentEntityType
import org.aspect.core.aql.entites.PropertyType;
import org.aspect.grails.engines.AspectContext;
import org.aspect.grails.engines.AspectEngine
import org.aspect.grails.entities.Entity;
import org.aspect.grails.entities.Interpreter;
import org.aspect.grails.entities.Type;
import org.aspect.grails.helpers.ClassName;
import org.aspect.grails.helpers.ClassUtils;
import org.aspect.grails.operations.BaseOperation;
import org.aspect.grails.operations.ClientOperation;
import org.aspect.grails.operations.CoreOperation;
import org.aspect.grails.operations.ServiceOperation;
import org.codehaus.groovy.grails.commons.DefaultGrailsDomainClass
import org.codehaus.groovy.grails.commons.GrailsApplication
import org.hibernate.SessionFactory
import org.hibernate.persister.entity.AbstractEntityPersister
import grails.util.Holders
import javax.naming.InitialContext
import java.sql.DriverManager


//
class DomainClassGrailsLoader {
	AspectEngine 			aspectEngine
	AspectContext 			aspectContext
	String					target

	SessionFactory 			sessionFactory
	GrailsApplication 		grailsApplication
	
	static final String		DEFAULT_TARGET = AspectContext.DEFAULT_TARGET

	DomainClassGrailsLoader() {
	}

	DomainClassGrailsLoader(AspectEngine aspectEngine) {
		init(aspectEngine)
	}
	
	def static String getDefaultAspectEngineTarget() {

		def dataSource = Holders.config.dataSource
		if (dataSource?.jndiName) {
			// Using jndi datasource
			def context = new InitialContext()
			def lookedUp = context.lookup(dataSource.jndiName)
			//lookedUp?.driverClassName
			//def driverClassName = DriverManager.getDriver(lookedUp.getConnection().getMetaData().getURL()).getClass()
			def driverClassName = DriverManager.getDriver(lookedUp.connection.metaData.URL).getClass().canonicalName
		} else {
			// First way of getting defaultAspectEngine
			Holders.config.dataSource.driverClassName.toString() ?: "com.mysql.jdbc.Driver"
		}
	}

	def target(String target = "datasource") {
		target = (target.toLowerCase() == "datasource") ? defaultAspectEngineTarget : target  
		init(new AspectEngine(target))
	}
	
	def private init(AspectEngine aspectEngine) {
		this.aspectEngine = aspectEngine
		this.aspectContext = aspectEngine.aspectContext
		this.target = aspectContext.target
		grailsApplication = aspectEngine.grailsApplication
		sessionFactory = aspectEngine.sessionFactory
	}

	private getEntityMetadata(String entityTypeName, String entityClassName) {
		AbstractEntityPersister hibernateClass = sessionFactory.getClassMetadata(entityClassName)
		if (!hibernateClass)
			throw new RuntimeException("metadata not found for '${entityClassName}'")
		//
		[	"domain"		: grailsApplication.getClassForName(hibernateClass.entityName)
			, "grails"		: new DefaultGrailsDomainClass(grailsApplication.getClassForName(hibernateClass.entityName))
			, "hibernate"	: hibernateClass
			, "name"		: entityTypeName
			, "className"	: entityClassName
		]
	}

	// Move this map to DSL
	private static Map aspectTargetMetadataMap = [
		"org.h2.Driver": [ 'persistentPropertyType'	: "org.aspect.core.aql.codegenerators.sql.entities.SqlPersistentPropertyType"
						 , 'entityTypeRelationship'	: "org.aspect.core.aql.codegenerators.sql.entities.SqlEntityTypeRelationship"
						 , 'persistentEntityType'	: "org.aspect.core.aql.codegenerators.sql.entities.SqlPersistentEntityType"
						 , 'codeGenerator'			: "org.aspect.core.aql.codegenerators.sql.SqlCodeGenerator"
						 , 'interpreter'			: "org.aspect.core.aql.interpreters.sql.HibernateInterpreter"]
		, "com.mysql.jdbc.Driver": [	'persistentPropertyType'	: "org.aspect.core.aql.codegenerators.sql.entities.SqlPersistentPropertyType"
										, 'entityTypeRelationship'	: "org.aspect.core.aql.codegenerators.sql.entities.SqlEntityTypeRelationship"
										, 'persistentEntityType'	: "org.aspect.core.aql.codegenerators.sql.entities.SqlPersistentEntityType"
										, 'codeGenerator'			: "org.aspect.core.aql.codegenerators.sql.SqlCodeGenerator"
										, 'interpreter'			: "org.aspect.core.aql.interpreters.sql.HibernateInterpreter"]
	];

	def newAspectTargetObject(targetEntityName, Object... constructorArgs) {
		if (!target) throw new RuntimeException('target is not set. Call init first')
		String className = aspectTargetMetadataMap[target][targetEntityName]
		(constructorArgs) ? this.class.classLoader.loadClass(className).newInstance(constructorArgs) : this.class.classLoader.loadClass(className).newInstance()
	}

	def buildPersistentEntityType(entityMetadata) {
		def entityPET = newAspectTargetObject("persistentEntityType", entityMetadata.hibernate.tableName.toLowerCase());
		entityMetadata.grails.properties.each { property ->
			if (!property.persistent || property.name == "version") return
			def columnProps = entityMetadata.hibernate.getPropertyColumnNames(property.name)
			if (columnProps && columnProps.length > 0) {
				// It could has more than one propertyColumnName
				columnProps.each {
					entityPET.addProperty(newAspectTargetObject("persistentPropertyType", it.toLowerCase(), property.type.name))
				}
			}
		}
		entityPET.id = entityPET.getProperty("id")
		entityPET
	}

	def static final String DEFAULT_FIELD_ID = "id"
	def static final String EQUIVALENT_ID_PROPERTY_NAME_FOR_INHERITANCE = "dateCreated"

	def buildEntityType(entityMetadata) {
		EntityType entityType = new EntityType(entityMetadata.grails.name.toLowerCase())
		entityMetadata.grails.properties.each { property ->
			int tableNameIndex = 0
			if (!property.persistent || property.oneToOne || property.manyToOne || property.name == "version") return
			if (property.name == DEFAULT_FIELD_ID)
				tableNameIndex = entityMetadata.hibernate.getSubclassPropertyTableNumber(EQUIVALENT_ID_PROPERTY_NAME_FOR_INHERITANCE)
			else
				tableNameIndex = entityMetadata.hibernate.getSubclassPropertyTableNumber(property.name)
			String specificTableName = entityMetadata.hibernate.getSubclassTableName(tableNameIndex)
			//
			entityType.addProperty(
				new PropertyType(property.name, specificTableName, entityMetadata.hibernate.getPropertyColumnNames(property.name)[0].toLowerCase())
			);
		}
		entityType
	}

	//
	def buildHierarchyClassList(leafClass) {
		//
		def hierarchy= []
		def hierarchyClass = leafClass
		while (hierarchyClass != null) {
			if (hierarchyClass == Object.class || hierarchyClass == org.aspect.core.entities.Entity.class) { hierarchyClass = null; continue; }
			def typeName = ClassName.conventionMemberName(hierarchyClass.simpleName)
			hierarchy.add(0, [name:hierarchyClass.name, typeName:typeName, clazz:hierarchyClass])
			hierarchyClass = hierarchyClass.superclass
		}
		hierarchy
	}

	//
	def addHierarchyMetadata(entityMetadata) {
		EntityType entityType = aspectContext.getEntityType(entityMetadata.className)
		// Hierarchy
		def hierarchy = buildHierarchyClassList(entityMetadata.domain)
		hierarchy.each { hierarchyData ->
			def entityPET = aspectContext.getPersistentEntityType(hierarchyData.name)
			if (!entityPET) return
			entityType.addHierarchyPersistentEntityType(entityPET)
			def typeET = aspectContext.getEntityType(hierarchyData.typeName)
			if (typeET.name != entityType.name)
				typeET.addSubtypeId(entityType.typeId)
		}
	}

	//
	def findRelationshipPropertyId(entityMetadata, relationshipProperty) {
		def columnProps = entityMetadata.hibernate.getPropertyColumnNames(relationshipProperty.name)
		String columnToFind = columnProps[0].toLowerCase()
		def propertyFounded = entityMetadata.grails.properties.find { property ->
			if (!property.persistent) return false
			if (property == relationshipProperty) return false
			if (property.name == relationshipProperty.name) return false
			def columnPropsCandidate = entityMetadata.hibernate.getPropertyColumnNames(property.name)
			columnPropsCandidate[0].toLowerCase() == columnToFind
		}
		propertyFounded?.name
	}

	//
	def addAspectMetadata(entityMetadata) {
		EntityType leftEntity = aspectContext.getEntityType(entityMetadata.name)
		entityMetadata.grails.properties.each { property ->
			if (!property.persistent || !(property.oneToOne || property.manyToOne)) return
			EntityType rightEntity = aspectContext.getEntityType(property.type.name.toLowerCase())
			if (!rightEntity) {
				throw new RuntimeException("Entity: ${property.type.name.toLowerCase()} not found in aspectContext")
			}
			EntityTypeRelationship r =
				newAspectTargetObject('entityTypeRelationship', rightEntity, property.name, findRelationshipPropertyId(entityMetadata, property))
			leftEntity.addRelationship(r)
		}
	}

	def private setBaseEntities(entityClassName, typeClassName, EntityType entityET) {
		aspectContext.setBaseEntityType(entityET)
		aspectContext.entityClassName = entityClassName
		aspectContext.typeClassName = typeClassName
	}

	static final String ENTITY_TYPE_NAME = "entity"
	static final String ENTITY_TYPE_TYPE_NAME = "type"
	/**
	 * Set the base entities for Aspect
	 * @param entityClassName
	 * @param typeClassName
	 * @return
	 */
	def baseTypes(String entityTypeDomainClassName, String typeTypeDomainClassName) {
		// We get metadata from grails
		def entityMetadata = getEntityMetadata(ENTITY_TYPE_NAME, entityTypeDomainClassName)
		def typeMetadata = getEntityMetadata(ENTITY_TYPE_TYPE_NAME, typeTypeDomainClassName)
		// We set entityType metadata
		aspectContext.setEntityTypeMetadata(entityMetadata)
		aspectContext.setEntityTypeMetadata(typeMetadata)
		// Building persistent entity types
		def entityPET = buildPersistentEntityType(entityMetadata)
		def typePET = buildPersistentEntityType(typeMetadata)
		// We add PET info to aspectContext
		aspectContext.setPersistentEntityType(entityMetadata.name, entityPET);
		aspectContext.setPersistentEntityType(entityMetadata.className, entityPET);
		aspectContext.setPersistentEntityType(typeMetadata.name, typePET);
		aspectContext.setPersistentEntityType(typeMetadata.className, typePET);
		// Adding ET with property info only
		EntityType entityET = buildEntityType(entityMetadata)
		EntityType typeET = buildEntityType(typeMetadata)
		// Setting types ids
		entityET.typeId = EntityType.DEFAULT_ENTITY_TYPE_ID;
		typeET.typeId = EntityType.DEFAULT_TYPE_TYPE_ID
		// Adding to aspectContext
		aspectContext.setEntityType(entityMetadata.name, entityET)
		aspectContext.setEntityType(entityMetadata.className, entityET)
		aspectContext.setEntityType(typeMetadata.name, typeET)
		aspectContext.setEntityType(typeMetadata.className, typeET)
		// Adding ET info with hierarchy and join info
		addHierarchyMetadata(entityMetadata);
		addHierarchyMetadata(typeMetadata);
		// Adding ET info with relationship info
		addAspectMetadata(typeMetadata);
		addAspectMetadata(entityMetadata);
		// We set base entity names: both, entity and type
		setBaseEntities(entityTypeDomainClassName, typeTypeDomainClassName, entityET)
		//
		[entityET, typeET]
	}

	def type(String entityTypeName, String domainClassName, Long typeId = EntityType.DEFAULT_ENTITY_TYPE_ID) {
		def (entityET, entityMetadata) = typeMetadata(entityTypeName, domainClassName, typeId)
		entityET = typeHierarchyMetadata(entityET, entityMetadata)
		entityET = typeAspectMetadata(entityET, entityMetadata)
		entityET
	}


	def private typeMetadata(String entityTypeName, String domainClassName, Long typeId = EntityType.DEFAULT_ENTITY_TYPE_ID) {
		// We get metadata from grails
		def entityMetadata = getEntityMetadata(entityTypeName, domainClassName)
		// We set entityType metadata
		aspectContext.setEntityTypeMetadata(entityMetadata)
		// Building persistent entity types
		def entityPET = buildPersistentEntityType(entityMetadata)
		// We add PET info to aspectContext
		aspectContext.setPersistentEntityType(entityPET.name, entityPET);
		aspectContext.setPersistentEntityType(entityMetadata.className, entityPET);
		// Adding ET with property info only
		EntityType entityET = buildEntityType(entityMetadata)
		// Setting types ids
		entityET.typeId = typeId
		// Adding to aspectContext
		aspectContext.setEntityType(entityMetadata.name, entityET)
		aspectContext.setEntityType(entityMetadata.className, entityET)
		//
		[entityET, entityMetadata]
	}
	
	def private typeHierarchyMetadata(entityET, entityMetadata) {
		// Adding ET info with hierarchy info
		addHierarchyMetadata(entityMetadata);
		entityET
	}

	def private typeAspectMetadata(entityET, entityMetadata) {
		// Adding ET info with relationship info
		addAspectMetadata(entityMetadata);
		//
		entityET
	}
	
	def aspect(String aspectName, Map aspectProperties, Long typeId = EntityType.DEFAULT_ENTITY_TYPE_ID) {
		type(aspectProperties.entityTypeName, aspectProperties.domainClassName, typeId)
		def entityMetadata = aspectContext.getEntityTypeMetadata(aspectName)
		// Build expression tree for aspect filter
		aspectProperties.filterExpression = (aspectProperties.filter && aspectProperties.filter != "no") ? aspectEngine.aqlEngine.translateAQLFilterToExpression(aspectProperties.filter) : null
		//
		Aspect aspect = new Aspect(aspectName, aspectContext.getEntityType(entityMetadata.className), aspectProperties)
		aspectContext.setAspect(aspectName, aspect)
		aspect
	}
	
	def aggregateAspect(Class clazz, String aspectName, Map aspectProperties, Long typeId = EntityType.DEFAULT_ENTITY_TYPE_ID) {
		String persistentEntityName = Command.getPropertyNameByConvention(aspectName)
		PersistentEntityType entityPET = newAspectTargetObject("persistentEntityType", persistentEntityName)
		EntityType entityType = new EntityType(aspectName)
		clazz.declaredFields.each { property ->
			// First it's checked out is an aggregated expression/property
			def annotation = property.getAnnotation(org.aspect.grails.annotations.AspectProperty.class)
			String textExpression = annotation?.expression()
			if (!textExpression) return
			//
			String persistentPropertyName = Command.getPropertyNameByConvention(property.name)
			entityPET.addProperty(newAspectTargetObject("persistentPropertyType", persistentPropertyName, property.type.name))
			entityType.addProperty(new PropertyType(property.name, persistentEntityName, persistentPropertyName, aspectEngine.aqlEngine.translateAQLFilterToExpression(textExpression)))
		}
		//
		entityPET.id = entityPET.getProperty(Command.getPropertyNameByConvention(aspectProperties.left))
		entityType.addHierarchyPersistentEntityType(entityPET)
		// Build expression tree for aspect filter
		aspectProperties.filterExpression = (aspectProperties.filter && aspectProperties.filter != "no") ? aspectEngine.aqlEngine.translateAQLFilterToExpression(aspectProperties.filter) : null
		//
		Aspect aspect = new Aspect(aspectName, entityType, aspectProperties, aspectProperties.aggreateOf)
		aspectContext.setAspect(aspectName, aspect)
		aspect
	}
	
	def getMetadataFrom(classList) {
		//
		def baseTypeListMap = [entityETDomainClassName:null, typeETDomainClassName:null]
		def typeList = []
		def aspectList = []
		def interpreterList = []
		def operationList = []
		// iteration classifying all the Aspects
		classList.each { Class clazz ->
			if (clazz.isAnnotationPresent(org.aspect.grails.annotations.Aspect.class)) {
				aspectList << clazz
			} else if (clazz.isAnnotationPresent(org.aspect.grails.annotations.AspectType.class)) {
				def annotation = clazz.getAnnotation(org.aspect.grails.annotations.AspectType.class)
				if (annotation.entityBase()) {
					baseTypeListMap.entityETDomainClassName = clazz
				} else if (annotation.typeBase()) {
					baseTypeListMap.typeETDomainClassName = clazz
				} else {
					typeList << clazz
				}
			} 
			if (clazz.isAnnotationPresent(org.aspect.grails.annotations.AspectInterpreter.class)) {
				interpreterList << clazz
			} 
			if (clazz.isAnnotationPresent(org.aspect.grails.annotations.AspectOperation.class)) {
				operationList << clazz
			} 
			if (clazz.isAnnotationPresent(org.aspect.core.annotations.AspectInterpreter.class)) {
				interpreterList << clazz
			} 
			if (clazz.isAnnotationPresent(org.aspect.core.annotations.AspectOperation.class)) {
				operationList << clazz
			}
		}
		[baseTypeListMap, typeList, aspectList, interpreterList, operationList]
	}

	def static String defaultUserName = "admin"
	
	def static boolean isBaseTypesDefined() {
		Type.types.base && Type.types.entity
	}
	
	def private includeBaseEntities(baseTypeMap) {
		if (!baseTypeMap) return null
		//
		Type baseType = Type.findOrSaveWhere(type:null, name:"base", description:"Base type"
			, localNamespace:ClassUtils.getPackageName(baseTypeMap.typeETDomainClassName)
			, localName:baseTypeMap.typeETDomainClassName.simpleName
			, createdBy:defaultUserName, updatedBy:defaultUserName)
		Type entityType = Type.findOrSaveWhere(type:baseType, name:ENTITY_TYPE_NAME, description:"${ENTITY_TYPE_NAME} type"
			, localNamespace:ClassUtils.getPackageName(baseTypeMap.entityETDomainClassName)
			, localName:baseTypeMap.entityETDomainClassName.simpleName
			, createdBy:defaultUserName, updatedBy:defaultUserName)
		// Adding metadata to Aspect engine  
		baseTypes(baseTypeMap.entityETDomainClassName.name, baseTypeMap.typeETDomainClassName.name)
		//
		Type.types.base = baseType 
		Type.types.entity = entityType 
		Type.types
	}

	def private includeTypes(typeList) {
		if (!typeList) return null
		//
		def typeMap = [:]
		// TODO make two iteration in order to avoid cross reference error
		typeList.each { Class clazz ->
			def annotation = clazz.getAnnotation(org.aspect.grails.annotations.AspectType.class)
			if (annotation.entityBase() || annotation.typeBase()) return
			//
			def typeName = ClassName.conventionMemberName(annotation.name() ?: clazz.simpleName)
			def description = annotation.description() ?: "${clazz.simpleName.toLowerCase()} type"
			//
			Type newType = Type.findOrSaveWhere(type:Type.types.base, name:typeName, description:description
				, localNamespace:ClassUtils.getPackageName(clazz.name), localName:clazz.simpleName
				, createdBy:defaultUserName, updatedBy:defaultUserName)
			// Adding metadata to Aspect engine
			def (entityET, entityMetadata) = typeMetadata(typeName, clazz.name, newType.id)
			typeMap[clazz] = [entityET:entityET, entityMetadata:entityMetadata]
			//
			Type.types[typeName] = newType
		}
		// Second iterations adding Hierarchy and Aspect metadatada
		typeMap.each { clazz, value ->
			typeHierarchyMetadata(value.entityET, value.entityMetadata);
		}
		typeMap.each { clazz, value ->
			typeAspectMetadata(value.entityET, value.entityMetadata)
		}
		//
		Type.types
	}
	
	def private includeAspects(aspectList) {
		if (!aspectList) return null
		def aggregatedList = []
		aspectList.each { Class clazz ->
			def annotation = clazz.getAnnotation(org.aspect.grails.annotations.Aspect.class)
			def aspectName = annotation.name() ?: ClassName.conventionMemberName(clazz.simpleName)
			def aspectIsDefault = annotation.isDefault()
			def aspectDescription = annotation.description() ?: "${clazz.simpleName.toLowerCase()} aspect"
			def aspectAggregateOf = annotation.aggregateOf()
			def aspectProperties = [entityTypeName:aspectName, domainClassName:clazz.name
									, left:annotation.left(), right:annotation.right()
									, aggreateOf:aspectAggregateOf, filter: annotation.filter()]
			//
			def newAspect = org.aspect.grails.entities.Aspect.findOrSaveWhere(
				name:aspectName, detailAspectClassName:aspectProperties.domainClassName
				, left:aspectProperties.left, right:aspectProperties.right
				, isDefault:aspectIsDefault, filter:aspectProperties.filter
				, aggregateOf:aspectAggregateOf
				, type:Type.types.aspect, description:aspectDescription
				, createdBy:defaultUserName, updatedBy:defaultUserName)
			//
			if (aspectAggregateOf) {
				aggregatedList << aggregateAspect(clazz, aspectName, aspectProperties, Type.types.aspect.id)
			}  else {
				aspect(aspectName, aspectProperties, Type.types.aspect.id)
			}
			//
			org.aspect.grails.entities.Aspect.aspectss[aspectName] = newAspect 
		}
		// Make sure all the aggregateOf aspect have located their aggregated
		aggregatedList.each { Aspect aspect ->
			aspect.aggregateOfAspect = aspectContext.getAspect(aspect.@aggregateOf)
		}
		//
		Type.types
	}

	def private includeInterpreters(interpreterList) {
		if (!interpreterList) return null
		String innerAspects = "false"
		String groups = "none"
		//
		interpreterList.each { Class clazz ->
			def annotation = clazz.getAnnotation(org.aspect.grails.annotations.AspectInterpreter.class)
			if (annotation) {
				innerAspects = annotation.innerAspects()
				groups = annotation.groups()
			} else {
				annotation = clazz.getAnnotation(org.aspect.core.annotations.AspectInterpreter.class)
			}
			String localNamespace = ClassUtils.getPackageName(clazz.name)
			String localName = clazz.simpleName
			String interpreterType = annotation.type()
			String description = annotation.description() ?: "${localName} interpreter"
			def type = Type.types.interpreter
			def newInterpreter = Interpreter.findOrSaveWhere(
				localNamespace:localNamespace, localName: localName
				, type:type, name:localName, description:description
				, interpreterType:interpreterType, innerAspects:innerAspects, groups:groups
				, createdBy:defaultUserName, updatedBy:defaultUserName)
			// TODO Check, only one interpreter by "interpreterType"
			Interpreter.interpreters[interpreterType] = newInterpreter
		}
		//
		Interpreter.interpreters
	}
		
	def private includeOperations(operationList) {
		if (!operationList) return null
		String innerAspects = "false"
		String groups = "none"
		//
		operationList.each { Class clazz ->
			def annotation = clazz.getAnnotation(org.aspect.grails.annotations.AspectOperation.class)
			if (annotation) {
				innerAspects = annotation.innerAspects()
				groups = annotation.groups()
			} else {
				annotation = clazz.getAnnotation(org.aspect.core.annotations.AspectOperation.class)
			}
			def localNamespace = ClassUtils.getPackageName(clazz)
			def localName = clazz.simpleName
			def signature = annotation.signature() ?: localName
			def name = annotation.name() ?: signature
			def description = annotation.description() ?: name
			def type =  Type.types.operation
			def argsSignature = annotation.argsSignature()
			def defaultArgs = annotation.defaultArgs()
			def active = annotation.active()
			def deprecated = annotation.deprecated()
			boolean process = annotation.process()		
			def processDefinition = annotation.definition()		
			def interpreterName = annotation.interpreter() ?: ""
			if (!interpreterName) {
				//
				def classes = []
				def c = clazz
				while (c) { classes << c; c = c.superclass }
				// 
				if (classes.contains(ClientOperation.class)) {
					interpreterName = "client"
				} else if (classes.contains(ServiceOperation.class)) {
					interpreterName = "service"
				} else if (classes.contains(CoreOperation.class)) {
					interpreterName = "core"
				} else if (classes.contains(BaseOperation.class)) {
					interpreterName = "base"
				} else {
					interpreterName = "base"
					//throw new RuntimeException("Invalid default operation definition for ${clazz.name}. It has to extends BaseOperation, CoreOperation, ServiceOperation or derived from them.")
				}
			}
			def interpreter = Interpreter.interpreters[interpreterName]
			//
			def newOperation
			if (process) {
				newOperation = org.aspect.grails.entities.Process.findOrSaveWhere(
						localNamespace:localNamespace, localName:localName, signature:signature
						, argsSignature:argsSignature, defaultArgs:defaultArgs
						, active:active, deprecated:deprecated
						, interpreter:interpreter, innerAspects:innerAspects, groups:groups
						, definition:processDefinition
						, name:name, type:Type.types.process, description:description
						, createdBy:defaultUserName, updatedBy:defaultUserName)
			} else {
				newOperation = org.aspect.grails.entities.Operation.findOrSaveWhere(
						localNamespace:localNamespace, localName:localName, signature:signature
						, argsSignature:argsSignature, defaultArgs:defaultArgs
						, active:active, deprecated:deprecated
						, interpreter:interpreter, innerAspects:innerAspects, groups:groups
						, name:name, type:type, description:description
						, createdBy:defaultUserName, updatedBy:defaultUserName)
			}
			newOperation
		}
	}
	
	def include(String packageName) {
		Entity.withTransaction { tx ->
			//
			def classList = ClassUtils.getClasses(packageName)
			//
			def (baseTypeMap, typeList, aspectList, interpreterList, operationList) = getMetadataFrom(classList)
			//
			if (baseTypeMap.typeETDomainClassName && baseTypeMap.entityETDomainClassName) includeBaseEntities(baseTypeMap)
			//
			includeTypes(typeList)
			//
			includeAspects(aspectList)
			//
			includeInterpreters(interpreterList)
			//
			includeOperations(operationList)
		}
	}

	public void alias(String entityName, String aql) {
		aspectEngine.addEntityByQuery(entityName, aql)
	}

	public void function(String functionSignature, String aql) {
		aspectEngine.setFunctionByQuery(functionSignature, aql)
	}
	
	def parseDSL(String resourceName) {
		// TODO resource could be not exist
		InputStream inputStream = this.class.classLoader.getResourceAsStream(resourceName)
		def content = IOUtils.toString(inputStream, "UTF-8")
	}
}
