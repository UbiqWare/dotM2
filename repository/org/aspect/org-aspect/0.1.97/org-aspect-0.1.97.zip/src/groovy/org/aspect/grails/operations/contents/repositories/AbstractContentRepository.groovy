package org.aspect.grails.operations.contents.repositories

import org.aspect.grails.exceptions.AspectException
import org.aspect.grails.engines.AspectEngine;
import org.aspect.grails.entities.AbstractInterpreter;
import org.aspect.grails.entities.Content;
import org.aspect.grails.entities.ContentRepository;
import org.aspect.grails.entities.ContentStatus;

import java.security.MessageDigest

abstract class AbstractContentRepository extends AbstractInterpreter {

	static Boolean initialized = false
	
	def initialize() {
	}

	
	@Override
	def execute() {
		// TODO Once content repo operation were created, this function should interpret them
		super.execute()
	}

	def refreshCalculatedProperties(def content, def contentData) {
		refreshSize(content, contentData)
		refreshHash(content, contentData)
	}

	def abstract refreshSize(def content, def contentData)
	def abstract refreshHash(def content, def contentData)
	def abstract Content createContent(def entity, def contentProperties)

	ContentRepository contentRepository

	def static generateMD5(byte[] buffer) {
		MessageDigest digest = MessageDigest.getInstance("MD5")
		digest.update(buffer, 0, buffer.size());
		byte[] md5sum = digest.digest()
		BigInteger bigInt = new BigInteger(1, md5sum)
		bigInt.toString(16).padLeft(32, '0')
	}

	def static content(def entity, AspectEngine aspectEngine) {
		aspectEngine.first("entity[@id=${entity.id} && parent()].content[@status=${ContentStatus.STABLE.value()}]")
	}

	def content(def entity) {
		content(entity, engine)
	}

	def static entity(def content, AspectEngine aspectEngine) {
		aspectEngine.first("entity[@id=${content.id} && child()].entity")
	}

	def entity(def e) {
		entity(e, engine)
	}	

	def static contentRepositoryImpl(def content, AspectEngine aspectEngine) {
		if (!content?.contentRepository) return null
		newInstance(content.contentRepository, aspectEngine)
	}

	def static newInstance(def contentRepository, AspectEngine aspectEngine) {
		def contentRepositoryImpl = AspectEngine.newInstance(contentRepository.localFullName())
		contentRepositoryImpl.engine = aspectEngine
		contentRepositoryImpl.contentRepository = contentRepository
		contentRepositoryImpl.initialize()
		contentRepositoryImpl
	}

	def static createContent(def entity, def contentProperties, ContentRepository contentRepository, AspectEngine aspectEngine) {
		if (!contentRepository) throw new RuntimeException("contentRepository not provided in createContent")
		def contentRepositoryImpl = newInstance(contentRepository, aspectEngine)
		contentRepositoryImpl.createContent(entity, contentProperties)
	}

	def static deleteContent(def entity, AspectEngine aspectEngine) {
		def contentInstance = content(entity, aspectEngine)
		if (!contentInstance) return false
		def crImpl = contentRepositoryImpl(contentInstance, aspectEngine)
		crImpl.deleteContent(entity, contentInstance)
	}

	def static truncateContent(def entity, AspectEngine aspectEngine) {
		def contentInstance = content(entity, aspectEngine)
		if (!contentInstance) return false
		contentRepositoryImpl(contentInstance, aspectEngine).truncateContent(contentInstance)
	}

	def static byte[] readContentData(def content, AspectEngine aspectEngine) {
		contentRepositoryImpl(content, aspectEngine).readContentData(content)
	}

	def static writeContentData(def content, byte[] data, AspectEngine aspectEngine) {
		contentRepositoryImpl(content, aspectEngine).writeContentData(content, data)
	}

	def static appendContentData(def content, byte[] data, AspectEngine aspectEngine) {
		contentRepositoryImpl(content, aspectEngine).appendContentData(content, data)
	}
	
	def static Content initiateMultipartWrite(def entity, def contentProperties, AspectEngine aspectEngine) {
		Content currentContent = content(entity, aspectEngine)
		def contentRepositoryImplInstance = contentRepositoryImpl(currentContent, aspectEngine)
		if (!contentRepositoryImplInstance) 
			contentRepositoryImplInstance = contentRepositoryImpl(contentProperties, aspectEngine)
		if (!contentRepositoryImplInstance) throw new RuntimeException("contentRepository not provided in initiateMultipartWrite")
		contentRepositoryImplInstance.initiateMultipartWrite(entity, contentProperties)
	}

	def static Content appendContentPart(def content, byte[] part, AspectEngine aspectEngine) {
		contentRepositoryImpl(content, aspectEngine).appendContentPart(content, part)
	}

	def static Content completeMultipartWrite(def content, AspectEngine aspectEngine) {
		contentRepositoryImpl(content, aspectEngine).completeMultipartWrite(content)
	}

	def static Boolean abortMultipartWrite(def content, AspectEngine aspectEngine) {
		contentRepositoryImpl(content, aspectEngine).abortMultipartWrite(content)
	}

	
	def static InputStream getContentDataInputStream(def content, AspectEngine aspectEngine) {
		contentRepositoryImpl(content, aspectEngine).getContentDataInputStream(content)
	}

	def static InputStream getEntityContentDataInputStream(def entity, AspectEngine aspectEngine) {
		Content currentContent = content(entity, aspectEngine)
		getContentDataInputStream(currentContent, aspectEngine)
	}
	
	
	def static writeEntityContentData(def entity, InputStream inputStream, AspectEngine aspectEngine) {
		Content currentContent = content(entity, aspectEngine)
		def contentRepositoryImplInstance = contentRepositoryImpl(currentContent, aspectEngine)
		def inprogressContent
		try {
			//
			def blockSize = currentContent.contentRepository.blockSize
			byte[] data = new byte[blockSize]
			// Starting multipart writing
			inprogressContent = contentRepositoryImplInstance.initiateMultipartWrite(entity, currentContent)
			Long totalBytesRead = 0
			Boolean eos = false
			while (!eos) {
				// Reading part
				Long bytesRead = inputStream.read(data)
				totalBytesRead += bytesRead
				if (bytesRead > 0) {
					byte[] buffer = new byte[bytesRead]
					for (int i = 0; i < bytesRead; i++) buffer[i] = data[i]
					inprogressContent = appendContentPart(inprogressContent, buffer, aspectEngine)
				}
				if (bytesRead < blockSize)
					eos = true 
			}
			// Finishing multipart writing
			completeMultipartWrite(inprogressContent, aspectEngine)
		} catch (Exception e) {
			if (inprogressContent)
				contentRepositoryImplInstance.abortMultipartWrite(inprogressContent, this)
			throw new AspectException("Exception trying to writeEntityContentDataInputStream. EntityId = ${entity?.id}")
		}
	}
	
	
}
