package org.aspect.grails.operations.contents.repositories

import org.aspect.grails.annotations.AspectInterpreter;
import org.aspect.grails.aspects.ContentData;
import org.aspect.grails.engines.AspectEngine;
import org.aspect.grails.entities.Content;
import org.aspect.grails.entities.ContentRepository;
import org.aspect.grails.entities.ContentStatus;

@AspectInterpreter(type = "domainClassContentRepository")
class DomainClassContentRepository extends AbstractContentRepository {

	def static contentWithData(def entity, AspectEngine aspectEngine) {
		aspectEngine.first("aspect(entity[@id=${entity.id} && parent()].content[@status=${ContentStatus.STABLE.value()}], 'contentData')")
	}

	def contentWithData(def entity) {
		contentWithData(entity, engine)
	}

	@Override	
	def refreshSize(def content, def contentData) {
		content.size = contentData?.data?.size() ?: 0
	}
	
	@Override	
	def refreshHash(def content, def contentData) {
		content.hash = contentData?.data ? generateMD5(contentData.data) : null
	}

	@Override
	def Content createContent(def entity, def contentProperties) {
		// Only one content could be in STABLE state
		if (contentProperties['status'] in [null, "", ContentStatus.STABLE.value()]) {
			deleteContent(entity, contentWithData(entity))
		}
		//
		Content content = new Content()
		def contentData = new ContentData(data:null)
		//
		content.properties = contentProperties
		content.id = 0
		content.contentRepository = contentRepository
		content.aspects["contentData"] = contentData 
		// 
		refreshCalculatedProperties(content, contentData)
		//
		content = create(content)
		link(entity, content)
		content
	}

	@Override
	def deleteContent(def entity, def content) {
		def deleted = true
		if (entity && content) {
			content = contentWithData(entity)
			deleted &= unlink(entity, content)
		}
		if (content) {
			deleted &= delete(content)
		}
		deleted
	}
	
	@Override
	def truncateContent(def content) {
		writeContentData(content, null)
	}
	
	@Override
	def byte[] readContentData(def content) {
		def contentWithData = engine.first("aspect(content[@id=${content.id}], 'contentData')")
		contentWithData.aspects.contentData.data
	}
	
	@Override
	def InputStream getContentDataInputStream(def content) {
		def contentWithData = engine.first("aspect(content[@id=${content.id}], 'contentData')")
		return new ByteArrayInputStream(contentWithData.aspects.contentData.data)
	}

	@Override
	def writeContentData(def content, byte[] data) {
		def contentWithData = engine.first("aspect(content[@id=${content.id}], 'contentData')")
		contentWithData.aspects.contentData.data = data
		refreshCalculatedProperties(contentWithData, contentWithData.aspects.contentData)
		save(contentWithData)
	}

	@Override
	def appendContentData(def content, byte[] data) {
		def contentWithData = engine.first("aspect(content[@id=${content.id}], 'contentData')")
		contentWithData.aspects.contentData.data = (((contentWithData.aspects.contentData.data ?: []) as List) + ((data ?: []) as List)) as byte[]
		refreshCalculatedProperties(contentWithData, contentWithData.aspects.contentData)
		save(contentWithData)
	}
	
	@Override
	def Content initiateMultipartWrite(def entity, def contentProperties) {
		contentProperties['status'] = ContentStatus.INPROGRESS.value()
		createContent(entity, contentProperties)
	}
	
	@Override
	def Content appendContentPart(def content, byte[] part) {
		def contentWithData = engine.first("aspect(content[@id=${content.id}], 'contentData')")
		contentWithData.aspects.contentData.data = (((contentWithData.aspects.contentData.data ?: []) as List) + ((part ?: []) as List)) as byte[]
		refreshSize(contentWithData, contentWithData.aspects.contentData)
		save(contentWithData)
	}
	
	@Override
	def Content completeMultipartWrite(def content) {
		//
		def entity = this.entity(content)
		//
		deleteContent(entity, contentWithData(entity))
		//
		def contentWithData = engine.first("aspect(content[@id=${content.id}], 'contentData')")
		content['status'] = ContentStatus.STABLE.value()
		refreshCalculatedProperties(content, contentWithData.aspects.contentData)
		save(content)
	}
	
	@Override
	def Boolean abortMultipartWrite(def content) {
		def entity = this.entity(content)
		def contentWithData = engine.first("aspect(content[@id=${content.id}], 'contentData')")
		def deleted = unlink(entity, contentWithData)
		deleted &= delete(contentWithData)
		deleted
	}
	
}
