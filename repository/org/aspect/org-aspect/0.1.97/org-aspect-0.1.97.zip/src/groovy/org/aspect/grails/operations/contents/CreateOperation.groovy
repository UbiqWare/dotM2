package org.aspect.grails.operations.contents

import org.aspect.grails.annotations.AspectOperation;

@AspectOperation(signature = "content.create")
class CreateOperation extends ContentOperation {
	
	def contentRepository
	def contentProperties

	@Override
	def execute() {
		contentRepository = contentRepository ?: contentProperties?.contentRepository ?: defaultContentRepository
		createContent(entity, contentProperties, contentRepository)
	}

}
