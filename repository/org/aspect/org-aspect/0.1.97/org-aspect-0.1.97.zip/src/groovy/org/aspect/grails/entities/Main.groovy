package org.aspect.grails.entities
//

/**
 * @author Jorge
 */
class Main {

	//
	static main(args) {
		/*
		println "Hello world!"
		AspectList myList = new AspectList(null, "entity", "{@id ASC}", 1)
		myList.list = [1,2,3]
		myList.each {
			println it
		}
		*/
	}

}


