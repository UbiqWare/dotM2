package org.aspect.grails.annotations

import java.lang.annotation.ElementType
import java.lang.annotation.Retention
import java.lang.annotation.RetentionPolicy
import java.lang.annotation.Target

@Target([ElementType.TYPE])
@Retention(RetentionPolicy.RUNTIME)
public @interface AspectType {
	String name() default ""
	String description() default ""
	boolean entityBase() default false
	boolean typeBase() default false
}

