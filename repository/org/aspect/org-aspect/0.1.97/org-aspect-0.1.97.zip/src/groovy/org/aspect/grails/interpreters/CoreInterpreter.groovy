package org.aspect.grails.interpreters


import org.aspect.grails.annotations.AspectInterpreter;
import org.aspect.grails.entities.AbstractInterpreter;

@AspectInterpreter(type = "core")
class CoreInterpreter extends AbstractInterpreter {

	//
	static String 	ORDER_BY_DEFAULT = "{@id ASC}"
	static Long 	OFFSET_DEFAULT = 0
	static Long 	MAX_DEFAULT = 1000

	@Override
	def execute() {
		super.execute()
	}

}
