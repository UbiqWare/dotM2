package org.aspect.grails.operations.service

import org.aspect.grails.annotations.AspectOperation;
import org.aspect.grails.operations.ServiceOperation


@AspectOperation(signature = "service.first", interpreter="service")
class FirstOperation extends ServiceOperation  {
	
	String q
		
	@Override
	def execute() {
		first(q)
	}

}
