package org.aspect.grails.operations.groups

import org.aspect.grails.annotations.AspectOperation;
import org.aspect.grails.aspects.Permission
import org.aspect.grails.aspects.Security
import org.aspect.grails.entities.UserGroup
import org.aspect.grails.exceptions.AspectException
import org.aspect.grails.operations.security.SecurityOperation
import org.aspect.grails.operations.users.CreateUserOperation;

@AspectOperation(signature = "UserGroup.create")
class CreateGroupOperation extends SecurityOperation {
	
	def group
	
	@Override
	def init() {
		// First, check group already exists
		if (!group?.groupname) throw new AspectException("Group doesn't have groupname")
		def currentGroup = first("usergroup[@groupname='${group?.groupname}']")
		// Check group exists or not
		if (currentGroup) throw new AspectException("User '${group.groupname}' already exists")
	}

	@Override
	def execute() {
		// First permission structure is checked and created if it doesn't exist
		group['aspects'] = group['aspects'] ?: [:] 
		group.aspects['permission'] = group.aspects['permission'] ?: new Permission(permissions:-1L, permissionsMask:-1L, owner:true)
		group.aspects['security'] = group.aspects['security'] ?: new Security(inheritsPermission:false, propagatesPermission:false)
		// User is created so its id can be used
		group = create(group)
		// Permission aspect is updated with the new user id
		group.aspects.permission.each { permission ->
			permission.permissionEntityId = permission.permissionEntityId ?: group.id
			permission.owner = (permission.permissionEntityId == permission.entityId) ? true : permission.owner  
		}
		// Finally all the information is saved
		group = save(group)
		//
		group
	}

}
