package org.aspect.grails.operations.contents

import org.aspect.grails.annotations.AspectOperation;

@AspectOperation(signature = "content.writeData")
class WriteDataOperation  extends ContentOperation {

	byte[] data
	
	@Override
	def execute() {
		writeContentData(content, data)
	}

}
