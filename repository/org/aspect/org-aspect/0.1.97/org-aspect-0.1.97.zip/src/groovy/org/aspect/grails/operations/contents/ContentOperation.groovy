package org.aspect.grails.operations.contents

import org.aspect.grails.annotations.AspectOperation;
import org.aspect.grails.operations.CoreOperation;

@AspectOperation(signature = "content.content")
class ContentOperation extends CoreOperation {
	
	def entity
	def content
	
	@Override
	def execute() {
		content = super.content(entity)
	}

	def getDefaultContentRepository() {
		// TODO if contentRepository is not specified, get default value for it.
		// It depends on user preferences so when user profile will be included, change this default logic
		first("contentRepository[@name='domainClass']")
	}

}
