package org.aspect.grails.operations.service

import org.aspect.grails.annotations.AspectOperation
import org.aspect.grails.operations.ServiceOperation

@AspectOperation(signature = "service.test", interpreter="service", innerAspects = "rights", groups = "all")
class TestOperation extends ServiceOperation  {
	
	String q
		
	@Override
	def execute() {
		first(q)
	}

}
