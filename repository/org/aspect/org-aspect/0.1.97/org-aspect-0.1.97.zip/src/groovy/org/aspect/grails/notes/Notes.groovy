package org.aspect.grails.notes
class Notes {}

/*
	1 - How to iterate classes in a package/directory
		http://dzone.com/snippets/get-all-classes-within-package

TODO
- Clonned defaultAspectEngine (context)
- Add cache Role.roles

Entities to add
- User
- Group
- Content (as entity)
- Version (as entity)
- Role "content"
- Role "version"


Aspect Version
===============
Version, as Content, is modeled as an Entity. This way other aspect can be applied to it.
Relationship between Entities and their version will be modeled through Relationship using "version" role
It will exists a currentVersion property in Version that refers to the entity which has as a current version the one with the property
Operaciones
	- version.create(entity)
	- version.restore(version)
	- version.setCurrentVersion(entity, entityVersion)
	- version.deleteAll(entity)
	...


Aspect Content
===============
Content, as Version, is modeled as an Entity. This way other aspect can be applied to it.
Relationship between Entities and their content will be modeled through Relationship using "content" role
Every content has its own ContentManager thay knows how to deal with content: remote, chunked, database ...
Operaciones
	- content.read(entity)
	- content.write(entity, content)
	- content.delete(entity)
	...

*/
