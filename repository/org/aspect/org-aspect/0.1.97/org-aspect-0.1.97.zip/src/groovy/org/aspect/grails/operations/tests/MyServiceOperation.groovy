package org.aspect.grails.operations.tests

import org.aspect.grails.annotations.AspectOperation;
import org.aspect.grails.operations.ServiceOperation;

@AspectOperation(signature = "test.myServiceOperation", interpreter="service")
class MyServiceOperation extends ServiceOperation {
	def init() {
		log.debug("test.myServiceOperation.init()")
	}
	
	def execute() {
		log.debug("test.myServiceOperation.execute()")
	}
	
	def finish() {
		log.debug("test.myServiceOperation.finish()")
		return "test.myServiceOperation result"
	}
}
