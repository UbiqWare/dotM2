package org.aspect.grails.operations.core

import org.aspect.grails.annotations.AspectOperation;
import org.aspect.grails.operations.CoreOperation


@AspectOperation(signature = "core.first", interpreter = "core")
class FirstOperation extends CoreOperation  {
	
	String q
		
	@Override
	def execute() {
		first(q)
	}

}
