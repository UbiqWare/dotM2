package org.aspect.grails.interpreters

import org.aspect.grails.annotations.AspectInterpreter;
import org.aspect.grails.entities.AbstractInterpreter;

@AspectInterpreter(type = "groovy")
class GroovyClientInterpreter extends AbstractInterpreter {

	@Override
	def execute() {
		//
		def groovyShell = new GroovyShell(engine.grailsApplication.classLoader, binding)
		//
		result = groovyShell.evaluate(operation.script)
	}
	
	@Override
	def buildBinding() {
		//
		binding = new Binding()
		// TODO complete: credentials, url ...
		binding.setVariable("args", args)
		args.each {	binding.setVariable(it.key, it.value) }
		//
		binding
	}

}
