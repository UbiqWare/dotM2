package org.aspect.grails.annotations

import java.lang.annotation.ElementType
import java.lang.annotation.Retention
import java.lang.annotation.RetentionPolicy
import java.lang.annotation.Target

@Target([ElementType.TYPE])
@Retention(RetentionPolicy.RUNTIME)
public @interface AspectOperation {
	// For all operations
	String name()	 			default "" 
	String description()		default "" 
	String localNamespace() 	default ""		
	String localName() 			default "" 
	String signature() 			default ""
	String argsSignature()		default "{}"
	String defaultArgs()		default "{}"
	boolean active()			default true
	boolean deprecated()		default false
	String interpreter() 		default ""
	String innerAspects()		default "false"
	String groups()				default "none"
	String[] before() 			default []
	String[] after() 			default []
	// For processes
	boolean process() 			default false
	String definition() 		default "{}"	//'process { execute signature:signature, args:args }"
	//String onProcessResume() 	default ""
	//String onProcessStart() 	default ""
}

