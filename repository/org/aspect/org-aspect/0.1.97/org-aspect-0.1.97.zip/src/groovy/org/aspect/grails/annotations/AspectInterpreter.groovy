package org.aspect.grails.annotations

import java.lang.annotation.ElementType
import java.lang.annotation.Retention
import java.lang.annotation.RetentionPolicy
import java.lang.annotation.Target

@Target([ElementType.TYPE])
@Retention(RetentionPolicy.RUNTIME)
public @interface AspectInterpreter {
	String type() 				default ""
	String namespace() 			default ""
	String name() 				default ""
	String description()		default ""
	String innerAspects()		default "false"
	String groups()				default "none"
}

