package org.aspect.grails.helpers

class ClassName {
	
	static String conventionMemberName(String originalName) {
		String memberName = originalName
		memberName = memberName.size() > 1 ? (Character.isUpperCase(memberName[1].toCharacter()) ? memberName
																	 	  						 : originalName[0].toLowerCase() + originalName[1..-1])
									   	   : memberName.toLowerCase()
		memberName
	}

}
