package org.aspect.grails.operations.digraphs.linearized

import org.aspect.grails.engines.AspectEngine
import org.aspect.grails.operations.CoreOperation

class LinearizedDigraphOperation extends CoreOperation {	
	//def graph
	//def leaf
	//def parent
	//def root
}
