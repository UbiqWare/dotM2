package org.aspect.grails.operations.security

import org.aspect.grails.annotations.AspectOperation
import org.aspect.grails.entities.LTOperationStatus


@AspectOperation(signature = "security.notifySecurityProcessWatchdogToFinish")
class NotifySecurityProcessWatchdogToFinishOperation extends SecurityOperation  {
	
	// Security Process Watchdog Entity Id
	def processId
	
	def waitUntilFinish = 0
	
	def hasFinish = true
	
	def static long CHECK_PERIOD = 1000
	
	@Override
	def execute() {
		// Getting context info
		def securityProcessWatchdogLTO = first("LongTermOperation[@id=${processId}]")
		def context = deserialize(securityProcessWatchdogLTO.context)
		// Updating LTO so|therefore|thus|hence its context store the request for finishing
		context['requestForFinishing'] = true
		securityProcessWatchdogLTO.context = serialize(context)
		// Saving new status
		save(securityProcessWatchdogLTO)
		//
		if (waitUntilFinish) {
			def timeout = (waitUntilFinish == true) ? 0 : waitUntilFinish  
			def terminate = false
			hasFinish = false
			while (!terminate) {
				securityProcessWatchdogLTO = first("LongTermOperation[@id=${securityProcessWatchdogLTO.id}]")
				this.hasFinish = (!securityProcessWatchdogLTO) || securityProcessWatchdogLTO.status == LTOperationStatus.FINISHED.value() || securityProcessWatchdogLTO.status == LTOperationStatus.FINISHED_WITH_ERROR.value()
				if (waitUntilFinish)
					Thread.sleep(CHECK_PERIOD)
				timeout -= CHECK_PERIOD
				terminate = this.hasFinish || ((waitUntilFinish == true) ? false : timeout <= 0) 
			}
		} else {
			hasFinish = true
		}
		//
		this
	}
	
}
