package org.aspect.grails.operations.tests

import org.aspect.grails.annotations.AspectOperation;
import org.aspect.grails.operations.ServiceOperation;

@AspectOperation(signature = "test.myEchoProcessWithDelay", interpreter="service")
class MyEchoProcessWithDelay extends ServiceOperation {
	
	String message
	Long delay
	
	def execute() {
		Thread.sleep(Math.min(100*1000, delay))
		return message
	}
	
}
