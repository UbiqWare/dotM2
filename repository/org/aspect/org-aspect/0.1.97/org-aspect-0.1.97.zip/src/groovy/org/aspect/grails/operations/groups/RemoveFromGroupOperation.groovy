package org.aspect.grails.operations.groups

import org.aspect.grails.annotations.AspectOperation;
import org.aspect.grails.aspects.Permission
import org.aspect.grails.aspects.Security
import org.aspect.grails.operations.security.SecurityOperation;

@AspectOperation(signature = "UserGroup.remove")
class RemoveFromGroupOperation extends SecurityOperation {
	
	def group
	def user

	@Override 
	def init() {
		user = entity ? checkIsAUser(entity) : checkIsAUser(user)
		group = checkIsAUserGroup(group)
	}
	
	@Override
	def execute() {
		unlink(group, entity)
		user.groups = buildUserGroupList(user)
		save(user)
	}


}
