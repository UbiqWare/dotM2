package org.aspect.grails.exceptions

class TypeNotFoundException extends AspectException {
	TypeNotFoundException(String message = null) {
		super(message)
	}
}
