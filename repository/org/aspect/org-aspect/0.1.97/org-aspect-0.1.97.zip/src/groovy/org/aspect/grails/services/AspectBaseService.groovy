package org.aspect.grails.services

import org.aspect.grails.entities.User

import java.io.InputStream;
import java.util.Map;
import org.aspect.grails.engines.AspectEngine;
import org.aspect.grails.entities.Content;
import org.aspect.grails.entities.ContentRepository;
import org.aspect.grails.entities.Interpreter;
import org.aspect.grails.loaders.DomainClassGrailsLoader;
import org.aspect.core.aql.Aspect;
import org.aspect.core.aql.entites.InnerAspect;
import org.aspect.core.entities.Entity;

class AspectServiceGloblals {
	static AspectEngine defaultAspectEngine
}

abstract class AspectBaseService {

	User currentUser

	public static getDefaultAspectEngine() {
		AspectServiceGloblals.defaultAspectEngine
	}

	public static void setDefaultAspectEngine(AspectEngine value) {
		AspectServiceGloblals.defaultAspectEngine = value
	}

	def private AspectEngine runtimeAspectEngine

	def getAspectEngine() {
		runtimeAspectEngine = runtimeAspectEngine ?: initRuntimeAspectEngine()
		// NOTE use getCurrentUser in order to allow polimorphism to be applied. Accessing currentUser seems not to apply override methods :(
		runtimeAspectEngine.currentUser = getCurrentUser()
		runtimeAspectEngine
	}

	def setAspectEngine(value) {
		runtimeAspectEngine = value
	}

	def setCurrentUser(user) {
		aspectEngine.currentUser = user
	}

	def getCurrentUser() {
		runtimeAspectEngine.currentUser
	}

	def private initRuntimeAspectEngine(Boolean reset = false) {
		if (runtimeAspectEngine && !reset) return runtimeAspectEngine
		initDefaultAspectEngine(reset)
		runtimeAspectEngine = defaultAspectEngine.clone()
		runtimeAspectEngine
	}

	def private initDefaultAspectEngine(Boolean reset = false) {
		if (defaultAspectEngine && !reset) return defaultAspectEngine
		// Check if config has been defined. If not, default config is loaded
		defaultAspectEngine = new AspectEngine(DomainClassGrailsLoader.defaultAspectEngineTarget)
		def domainClassLoader = new DomainClassGrailsLoader(defaultAspectEngine)
		//
		domainClassLoader.include("org.aspect.grails")
		domainClassLoader.include("org.aspect.core")
		defaultAspectEngine
	}

	//
	def methodMissing(String methodName, args) {
		execute(signature:methodName, args:args)
	}

	def execute(Map args) {
		if (args.containsKey("operation") && args.containsKey("interpreter")) {
			aspectEngine.execute(args.operation, args.interpreter, args?.args, args?.modifiers)
		} else if (args.containsKey("operation")) {
			aspectEngine.execute(args.operation, args?.args ?: [:], args?.modifiers ?: [:])
		} else if (args.containsKey("signature")) {
			aspectEngine.execute(args.signature, args?.args ?: [:], args?.modifiers ?: [:])
		} else if (args.containsKey("query")) {
			aspectEngine.executeByQuery(args.query, args?.args ?: [:], args?.modifiers ?: [:])
		}
	}

	def query(String aql, Long offset = aspectEngine.context.offset, Long max = aspectEngine.context.defaultMax, String orderBy = aspectEngine.context.orderBy) {
		aspectEngine.query(aql, offset, max, orderBy)
	}

	def queryMap(String aql, Long offset = aspectEngine.context.offset, Long max = aspectEngine.context.defaultMax, String orderBy = aspectEngine.context.orderBy) {
		aspectEngine.queryMap(aql, offset, max, orderBy)
	}

	def queryAll(String aql, Long offset = aspectEngine.context.offset, Long max = aspectEngine.context.defaultMax, String orderBy = aspectEngine.context.orderBy) {
		aspectEngine.queryAll(aql, offset, max, orderBy)
	}

	def queryMapAll(String aql, Long offset = aspectEngine.context.offset, Long max = aspectEngine.context.defaultMax, String orderBy = aspectEngine.context.orderBy) {
		aspectEngine.queryMapAll(aql, offset, max, orderBy)
	}

	def first(String aql) {
		aspectEngine.first(aql)
	}

	def firstMap(String aql) {
		aspectEngine.firstMap(aql)
	}

	def save(rawEntity) {
		aspectEngine.save(rawEntity)
	}

	def create(def rawEntity, def parent = null, def role = null) {
		aspectEngine.create(rawEntity, parent, role)
	}

	def read(rawEntity) {
		aspectEngine.read(rawEntity)
	}

	def update(rawEntity) {
		aspectEngine.save(rawEntity)
	}

	def delete(rawEntity) {
		aspectEngine.delete(rawEntity)
	}

	def undelete(rawEntity) {
		aspectEngine.undelete(rawEntity)
	}

	def destroy(rawEntity) {
		aspectEngine.destroy(rawEntity)
	}

	def link(parent, child, role = null) {
		aspectEngine.link(parent, child, role)
	}

	def unlink(parent, child, role = null) {
		aspectEngine.unlink(parent, child, role)
	}

	def Map adaptEntityToMapInstance(entity) {
		entity ? aspectEngine.adaptEntityToMapInstance(entity) : [:]
	}

	def Entity adaptMapInstanceToEntity(Map map) {
		map ? aspectEngine.adaptMapInstanceToEntity(map) : null
	}

	public void addQueryAlias(String entityName, String aql) {
		aspectEngine.addQueryAlias(entityName, aql)
	}

	public void addQueryFunction(String functionSignature, String aql) {
		aspectEngine.addQueryFunction(functionSignature, aql)
	}

	def content(def entity) {
		aspectEngine.content(entity)
	}

	def createContent(def entity, def contentProperties, ContentRepository contentRepository = null) {
		contentRepository = contentRepository ?: defaultContentRepository
		aspectEngine.createContent(entity, contentProperties, contentRepository)
	}


	def deleteContent(def entity, def content) {
		aspectEngine.deleteContent(entity, content)
	}

	def deleteContent(def entity) {
		aspectEngine.deleteContent(entity)
	}

	def truncateContent(def entity) {
		aspectEngine.truncateContent(entity)
	}

	def byte[] readContentData(def content) {
		aspectEngine.readContentData(content)
	}

	def InputStream getContentDataInputStream(def content) {
		aspectEngine.getContentDataInputStream(content)
	}

	def InputStream getEntityContentDataInputStream(def entity) {
		aspectEngine.getEntityContentDataInputStream(entity)
	}

	def writeContentData(def content, byte[] data) {
		aspectEngine.writeContentData(content, data)
	}

	def writeEntityContentData(def entity, InputStream inputStream) {
		aspectEngine.writeEntityContentData(entity, inputStream)
	}

	def appendContentData(def content, byte[] data) {
		aspectEngine.appendContentData(content, data)
	}

	def Content initiateMultipartWrite(def entity, def contentProperties) {
		aspectEngine.initiateMultipartWrite(entity, contentProperties)
	}

	def Content appendContentPart(def content, byte[] part) {
		aspectEngine.appendContentPart(content, part)
	}

	def Content completeMultipartWrite(def content) {
		aspectEngine.completeMultipartWrite(content)
	}

	def Boolean abortMultipartWrite(def content) {
		aspectEngine.abortMultipartWrite(content)
	}

	def getDefaultContentRepository() {
		Interpreter.interpreters.domainClassContentRepository
	}

	void removeInnerAspect(String innerAspect) {
		aspectEngine.removeInnerAspect(innerAspect);
	}

	void addInnerAspect(String innerAspectName) {
		aspectEngine.addInnerAspect(innerAspectName);
	}

	void addInnerAspect(String... innerAspectNames) {
		aspectEngine.addInnerAspect(innerAspectNames);
	}

	void addInnerAspect(String innerAspectName, Aspect innerAspect) {
		aspectEngine.addInnerAspect(innerAspectName, innerAspect);
	}

	Map<String, InnerAspect> getInnerAspects() {
		return aspectEngine.getInnerAspects();
	}

	void setInnerAspects(Map<String, InnerAspect> innerAspects) {
		aspectEngine.setInnerAspects(innerAspects);
	}

	InnerAspect newInnerAspect(String aspectName) {
		return aspectEngine.newInnerAspect(aspectName);
	}

	InnerAspect newInnerAspect(Aspect aspect) {
		return aspectEngine.newInnerAspect(aspect);
	}

	def pushInnerAspects(def innerAspects) {
		aspectEngine.pushInnerAspects(innerAspects)
	}

	def popInnerAspects() {
		aspectEngine.popInnerAspects()
	}

	InnerAspect peekInnerAspect() {
		aspectEngine.peekInnerAspects()
	}

	def setVariable(String name, String value) {
		aspectEngine.setVariable(name, value)
	}

	def getVariable(String name) {
		aspectEngine.getVariable(name)
	}

	public void set(String name, Object value) {
		aspectEngine.set(name, value);
	}

	public Object get(String name) {
		return aspectEngine.get(name);
	}

	def findOrSave(def rawEntity, def parent = null, def role = null) {
		aspectEngine.findOrSave(rawEntity, parent, role)
	}

}
