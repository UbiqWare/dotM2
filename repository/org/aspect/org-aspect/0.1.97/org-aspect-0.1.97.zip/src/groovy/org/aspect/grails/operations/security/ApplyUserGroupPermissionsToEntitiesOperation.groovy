package org.aspect.grails.operations.security

import org.aspect.grails.annotations.AspectOperation
import org.aspect.grails.aspects.Permission
import org.aspect.grails.aspects.Security
import org.aspect.grails.operations.CoreOperation

@AspectOperation(signature = "security.applyUserGroupPermissionToEntities", interpreter = 'core')
class ApplyUserGroupPermissionsToEntitiesOperation extends CoreOperation {

    // UserGroup cache
    private def groups = [:]

    @Override
    def execute() {
        //
        ["interpreter[!in(@groups,'none')]", "operation[!in(@groups,'none')]"].each { q ->
            queryAll(q).each { entity ->
                assignGroups(entity, entity.groups)
            }
        }
    }

    def assignGroups(entity, String groupList) {
        groupList.split(",").collect {it.trim()}.each { groupName ->
            groups[groupName] = groups[groupName] ?: first("UserGroup[@groupname = '$groupName']")
            def g = groups[groupName]
            if (!g) return
            // Treat permissions
            entity.aspects["permission"] = Permission.findByPermissionEntityIdAndPermissionEntityId(entity.id, g.id) ?: new Permission(permissionEntityId:g.id, permissions:-1L, permissionsMask:-1L)
            entity.aspects["security"] = Security.findByEntityId(entity.id) ?: new Security(inheritsPermission:true, propagatesPermission:true)
            def e = save(entity)
        }
    }

}
