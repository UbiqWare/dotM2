package org.aspect.grails.operations

import java.util.Map;

import org.aspect.grails.entities.AbstractOperation;

abstract class ClientOperation  extends AbstractOperation {
	
	def aspectClient

	@Override
	public def init() {
		super.init()
	}

	@Override
	public Object execute() {
		super.execute()
	}

	@Override
	public def finish() {
		super.finish()
	}
	
}
