package org.aspect.grails.interpreters

import groovy.lang.Binding;

import org.aspect.grails.annotations.AspectInterpreter;
import org.aspect.grails.dsls.AspectConfigDSL;
import org.aspect.grails.entities.AbstractInterpreter;
import org.aspect.grails.loaders.DomainClassGrailsLoader;

@AspectInterpreter(type = "aspectConfig")
class AspectConfigInterpreter extends AbstractInterpreter {

	@Override
	def execute() {
		//
		def groovyShell = new GroovyShell(engine.grailsApplication.classLoader, binding)
		//
		result = groovyShell.evaluate(operation.script)
	}
	
	@Override
	def buildBinding() {
		//
		binding = new Binding()
		//
		AspectConfigDSL aspectConfigDSL = new AspectConfigDSL(new DomainClassGrailsLoader(engine))
		// TODO complete: credentials, url ...
		binding.setVariable("aspect", aspectConfigDSL)
		binding.setVariable("args", args)
		args.each {	binding.setVariable(it.key, it.value) }
		//
		binding
	}
}

