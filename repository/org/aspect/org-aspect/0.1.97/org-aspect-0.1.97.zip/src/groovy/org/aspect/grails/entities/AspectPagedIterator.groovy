package org.aspect.grails.entities


class AspectPagedIterator extends PagedIterator {
	AspectList aspectList

	AspectPagedIterator(def aspectList = null) {
		this.pageSize = aspectList?.pageSize ?: 1000
		if (!aspectList?.size())
			getNextPage()
	}

	@Override
	protected queryNextPage() {
		aspectList.engine.query(aspectList.query, offset, pageSize, aspectList.orderBy)
	}
}

