package org.aspect.grails.operations.tests

import org.aspect.grails.annotations.AspectOperation;
import org.aspect.grails.operations.BaseOperation;

@AspectOperation(signature = "test.myBaseOperation", interpreter="base")
class MyBaseOperation extends BaseOperation {
	def init() {
		log.debug("test.myBaseOperation.init()")
	}
	
	def execute() {
		log.debug("test.myBaseOperation.execute()")
	}
	
	def finish() {
		log.debug("test.myBaseOperation.finish()")
		return "test.myBaseOperation result"
	}
}
