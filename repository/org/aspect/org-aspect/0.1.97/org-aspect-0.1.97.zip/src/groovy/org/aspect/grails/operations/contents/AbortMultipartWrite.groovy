package org.aspect.grails.operations.contents

import org.aspect.grails.annotations.AspectOperation;

@AspectOperation(signature = "content.abortMultipartWrite")
class AbortMultipartWriteOperation extends ContentOperation {
	
	@Override
	def execute() {
		abortMultipartWrite(content)
	}

}

