package org.aspect.grails.operations.contents.repositories

import org.aspect.model.entities.Content;
import java.io.InputStream;
import java.security.MessageDigest

import org.aspect.grails.annotations.AspectInterpreter;
import org.aspect.grails.entities.Content;
import org.aspect.grails.entities.ContentRepository;
import org.aspect.grails.entities.ContentStatus;
import org.aspect.grails.exceptions.AspectException

@AspectInterpreter(type = "fileSystemContentRepository")
class FileSystemContentRepository extends AbstractContentRepository {
	
	def static generateMD5(File file) {
		MessageDigest digest = MessageDigest.getInstance("MD5")
		byte[] buffer = new byte[8192]
		file.withInputStream() { is ->
			int read = 0
			while( (read = is.read(buffer)) > 0) {
				digest.update(buffer, 0, read);
			}
		}
		byte[] md5sum = digest.digest()
		BigInteger bigInt = new BigInteger(1, md5sum)
		bigInt.toString(16).padLeft(32, '0')
	}

	FileSystemContentRepository() {
	}

	def createDirectory(String diretoryPath) {
		if (!diretoryPath) return null
		File file = new File(diretoryPath)
		if (!file.exists()) {
			if (!file.mkdirs()) {
				throw new AspectException("Error creating repository: ${file.absolutePath}")
			}
		}
	}
	
	@Override	
	def initialize() {
		if (initialized) return true
		createDirectory(contentRepository.repositoryId)
		createDirectory(contentRepository.tempRepositoryId)
		createDirectory(contentRepository.versionRepositoryId)
		initialized = true
	}
	
	@Override	
	def refreshSize(def content, def contentData) {
		// It's assumed contentData is a File object
		content.size = contentData?.size() ?: 0
	}
	
	@Override	
	def refreshHash(def content, def contentData) {
		// It's assumed contentData is a File object
		content.hash = contentData ? generateMD5(contentData as File) : null
	}
	
	def File getFileFromContent(def content) {
		File file
		switch (content['status']) {
			case ContentStatus.STABLE.value():
				file = new File(contentRepository.repositoryId, content.id.toString())
				break	
			case ContentStatus.INPROGRESS.value():
				file = new File(contentRepository.tempRepositoryId, content.id.toString())
				break	
			default:
				file = null
		}
		file
	}
	
	def createFile(def content) {
		File file = getFileFromContent(content)
		file.createNewFile()
		if (!file.exists())
			throw new RuntimeException("Unable to create content <${file.absolutePath}>")
		file
	}
	
	def deleteFile(def content) {
		File file = getFileFromContent(content)
		def deleted = file.delete()
		deleted
	}

	@Override
	def Content createContent(def entity, def contentProperties) {
		// Only one content could be in STABLE state
		if (contentProperties['status'] in [null, "", ContentStatus.STABLE.value()]) {
			deleteContent(entity, content(entity))
		}
		//
		Content content = new Content()
		content.properties = contentProperties
		content.contentRepository = contentRepository
		//
		content = create(content)
		link(entity, content)
		File file = createFile(content)
		refreshCalculatedProperties(content, file)
		content = save(content)
		//
		content
	}

	@Override
	def deleteContent(def entity, def content) {
		def deleted = true
		if (entity && content) deleted &= unlink(entity, content)
		if (content) {
			deleted &= delete(content)
			deleted &= deleteFile(content)
		}
		deleted
	}
	
	@Override
	def truncateContent(def content) {
		writeContentData(content, null)
	}
	
	@Override
	def byte[] readContentData(def content) {
		File file = getFileFromContent(content)
		if (file.size() > contentRepository.blockSize)
			throw new AspectException("Trying to read a full file greater than content reposiroty block size. File size is ${file.size()}. Block size is ${contentRepository.blockSize}")
		def data = file.readBytes()
	}
	
	@Override
	def InputStream getContentDataInputStream(def content) {
		File file = getFileFromContent(content)
		return new FileInputStream(file.absolutePath)
	}

	@Override
	def writeContentData(def content, byte[] data) {
		File file = getFileFromContent(content)
		file.delete()
		file.createNewFile()
		if (data)
			file << data
		refreshCalculatedProperties(content, file)
		save(content)
	}

	@Override
	def appendContentData(def content, byte[] data) {
		if (!data) return content
		File file = getFileFromContent(content)
		file << data
		refreshCalculatedProperties(content, file)
		save(content)
	}
	
	@Override
	def Content initiateMultipartWrite(def entity, def contentProperties) {
		contentProperties['status'] = ContentStatus.INPROGRESS.value()
		createContent(entity, contentProperties)
	}
	
	@Override
	def Content appendContentPart(def content, byte[] part) {
		if (!part) return content
		File file = getFileFromContent(content)
		file << part
		refreshSize(content, file)
		save(content)
	}
	
	@Override
	def Content completeMultipartWrite(def content) {
		//
		def entity = this.entity(content)
		//
		deleteContent(entity, this.content(entity))
		// Moving file
		AntBuilder builder = new AntBuilder()
		File sourceFile = getFileFromContent(content)
		File targetFile = new File(contentRepository.repositoryId, content.id.toString())
		builder.move(file:sourceFile.canonicalPath, tofile:targetFile.canonicalPath)
		if (!targetFile.exists())
			throw new AspectException("File <${sourceFile.canonicalPath}> can't be move to <${targetFile.canonicalPath}>")
		//
		content['status'] = ContentStatus.STABLE.value()
		refreshCalculatedProperties(content, targetFile)
		save(content)
	}
	
	@Override
	def Boolean abortMultipartWrite(def content) {
		def entity = this.entity(content)
		deleteContent(entity, content)
	}
}
