package org.aspect.grails.entities

import java.util.ArrayList;
import java.util.Iterator;
import org.aspect.core.engines.AbstractEngine

class AspectList<E> extends ArrayList<E> {

	AbstractEngine 	engine
	String 	query
	String 	orderBy
	int		pageSize

	AspectList(def engine, String query, String orderBy = '{@id ASC}', int pageSize = 1000) {
		this.engine = engine
		this.query = query
		this.orderBy = orderBy
		this.pageSize = pageSize
	}

	void setList(def source) {
		clear()
		addAll(source)
	}
	
	Iterator<E> iterator() {
		return new AspectPagedIterator(this)
	}

}


