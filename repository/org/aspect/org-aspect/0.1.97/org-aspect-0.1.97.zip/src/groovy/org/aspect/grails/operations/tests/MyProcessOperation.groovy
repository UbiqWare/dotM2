package org.aspect.grails.operations.tests

import org.aspect.grails.annotations.AspectOperation;
import org.aspect.grails.operations.ServiceOperation;

@AspectOperation(signature = "test.myProcessOperation", interpreter="service", process = true)
class MyProcessOperation extends ServiceOperation {
	
	def delay 
	
	def iterationNumber = 0
	
	def init() {
		log.debug("test.myProcessOperation.init()")
	}
	
	def execute() {
		log.debug("test.myProcessOperation.execute()")
		(1..iterationNumber).each {
			Thread.sleep(delay)
			log.debug("Iteration ${it}: test.myProcessOperation")
		}
	}
	
	def finish() {
		log.debug("test.myProcessOperation.finish()")
		return "test.myProcessOperation result"
	}
}
