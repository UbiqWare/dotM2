package org.aspect.grails.operations.digraphs.linearized

import org.aspect.grails.annotations.AspectOperation
import org.aspect.grails.aspects.LinearizedDigraph
import org.aspect.grails.entities.UserGroup

@AspectOperation(signature = "LinearizedDigraph.add")
class AddToLinearizedDigraphOperation extends LinearizedDigraphOperation  {
	
	def graph
	def parent
	def child

	def private rootId = null
	
	@Override
	def init() {
		if (!graph) throw new IllegalArgumentException("graph argument is null")
		if (!child) throw new IllegalArgumentException("child argument is null")
	}

	@Override
	def execute() {
		// First rootId is calculated. If no root exists then root is the child itself
		rootId = parent ? first("aspect(entity[@id=${graph.id}],'linearizedDigraph')[@linearizedDigraph[@childId=${parent.id}]]")?.aspects?.linearizedDigraph?.rootId
						: child.id
		// Then if no parent it's root entity so self-reference is added
		if (!parent) {
			save(new LinearizedDigraph(graphId:graph.id, rootId:rootId, parentId:parent?.id, childId:child.id, ancestorId:child?.id))
		} else {
			// Next all parent entries are copied as new entity aspect entries. First, parent's ancestors
			queryAll("aspect(entity[@id=${graph.id}],'linearizedDigraph')[@linearizedDigraph[@childId=${parent.id}]]").each { ancestor ->
				save(new LinearizedDigraph(	graphId:graph.id, rootId:rootId, parentId:parent?.id, childId:child.id
											, ancestorId:ancestor.aspects.linearizedDigraph.ancestorId))
			}
			// TODO Check if child already has a graph with itself as root
			// Finally aspect for direct parent
			save(new LinearizedDigraph(graphId:graph.id, rootId:rootId, parentId:parent?.id, childId:child.id, ancestorId:parent?.id))
		}
		// Returning this operation
		this
	}

}
