package org.aspect.grails.operations.tests

import org.aspect.grails.annotations.AspectOperation
import org.aspect.grails.operations.ServiceOperation

@AspectOperation(signature = "test.readWithStatusAndSecurity", interpreter="service", innerAspects = 'status,security')
class MyServiceReadWithStatusAndSecurityOperation extends ServiceOperation {
	def entity
	def execute() {
		entity = read(entity)
		entity
	}
}
