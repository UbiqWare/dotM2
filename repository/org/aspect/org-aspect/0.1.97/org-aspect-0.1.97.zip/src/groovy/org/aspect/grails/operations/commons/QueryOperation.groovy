package org.aspect.grails.operations.commons

import org.aspect.grails.annotations.AspectOperation;
import org.aspect.grails.operations.CoreOperation;

@AspectOperation(signature = "common.query")
class QueryOperation extends CoreOperation  {
	
	String q
	
	@Override
	def execute() {
		query(q)
	}
}
