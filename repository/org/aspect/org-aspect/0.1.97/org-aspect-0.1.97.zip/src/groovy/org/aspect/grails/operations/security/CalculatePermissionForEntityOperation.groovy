package org.aspect.grails.operations.security

import org.aspect.grails.annotations.AspectOperation
import org.aspect.grails.entities.AbstractOperation
import org.aspect.grails.aspects.Permission
import org.aspect.grails.aspects.Security

@AspectOperation(signature = "security.calculatePermissionForEntity")
class CalculatePermissionForEntityOperation extends SecurityOperation  {
	
	Boolean atLeastOnePermissionHasChanged
	Boolean hasParents
	
	@Override
	def execute() {
		//
		atLeastOnePermissionHasChanged = false
		hasParents = false
		// Read all the security information from entity if it inherits permission
		entity = first("aspect(entity[@id=${entity.id}], 'security')[@security[@inheritsPermission = true]]")
		if (!entity) return null
		// First, all inherited permissions aspect entry are mark as deleted
		markInheritedPermissionsAsDeletedOrZero(entity)
		// process all parents who propagate permissions and are linked using a role that propagates permission too
		queryAll("aspect(entity[@id=${entity.id}]<-entity, 'security')[@security[@propagatesPermission=true] && @relationship[@role[@propagatesPermission=true || isnull(@propagatesPermission)]]]").each { parent ->
			// processing all the permission info every parent has
			queryAll("aspect(entity[@id=${parent.id}], 'permission')").each { parentPermission ->
				// Getting permission info from entity with the same user of the parent we are processing 
				def entityPermission = first("aspect(entity[@id=${entity.id}], 'permission')[@permission[@permissionEntityId=${parentPermission.aspects.permission.permissionEntityId}]]")
				if (!entityPermission) {
					entity.aspects["permission"] = new Permission(entityId:entity.id, permissionEntityId:parentPermission.aspects.permission.permissionEntityId) 
					entityPermission = entity 
				}
				// Calculate inheritedPermission
				long oldEntityInheritedPermissions = entityPermission.aspects.permission.inheritedPermissions
				def parentEfectivePermission = Permission.calculateEfectivePermissions(parentPermission.aspects.permission)
				def newEntityInheritedPermission = oldEntityInheritedPermissions | parentEfectivePermission
				entityPermission.aspects.permission.inheritedPermissions = newEntityInheritedPermission
				atLeastOnePermissionHasChanged |= oldEntityInheritedPermissions != newEntityInheritedPermission
				// Current aspect entry is mark as processed setting NO_MARK as its status 
				entityPermission.aspects.permission.permissionStatus = NO_MARK
				//
				save(entityPermission.aspects.permission)  
			}
			hasParents = true
		}
		// All aspect entries with MARK_AS_DELETED in their status are deleted
		deletePermissionsMarkedAsDeleted(entity)
		// If there aren't any parent, only the entity has changed. Therefore it is required to check children permissions
		atLeastOnePermissionHasChanged = atLeastOnePermissionHasChanged ?: (hasParents ? false : true)  
		//
		this
	}

}
