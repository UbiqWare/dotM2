package org.aspect.grails.operations.security

import org.aspect.grails.annotations.AspectOperation

@AspectOperation(signature = "security.securityProcessWatchdog"/*, process = true*/)
class SecurityProcessWatchdogOperation extends SecurityOperation  {
	
	Long delay
	
	private Boolean requestForFinishing
	
	def private context

	@Override
	def init() {
		
	}
		
	@Override
	def execute() {
		//
		requestForFinishing = false
		//
		while (!requestForFinishing) {
			// 
			def result = exec(signature:"security.calculateAllPendingPermissions")
			//
			refreshContext()
			//
			requestForFinishing = checkIfFinishingHasBeenRequeried()
			if (!requestForFinishing)
				waitUntilDelay(result)
		}
		//
		true
	}
	
	def refreshContext() {
		def lto = getLongTermOperation()
		context = deserialize(lto?.context)
	}
	
	def checkIfFinishingHasBeenRequeried() {
		context?.requestForFinishing ?: false
	}

	private static final MAX_DELAY = 60 * 1000
	def waitUntilDelay(def calculateAllPendingPermissionInfo) {
		// If there are entities which permission are pending sleep is not done
		calculateAllPendingPermissionInfo.thereIsPendingEntityForCalculatingSecurity ?: Thread.sleep(Math.min(60*1000, Math.max(delay,0)))
	}

}
