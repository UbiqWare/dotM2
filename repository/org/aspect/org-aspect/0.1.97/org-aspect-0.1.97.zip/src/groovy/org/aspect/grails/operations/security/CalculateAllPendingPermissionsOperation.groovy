package org.aspect.grails.operations.security

import org.aspect.grails.annotations.AspectOperation
import org.aspect.grails.entities.AbstractOperation
import org.aspect.grails.aspects.Permission
import org.aspect.grails.aspects.Security
import org.aspect.grails.aspects.SecurityProcessStatus
import org.hibernate.LockMode

@AspectOperation(signature = "security.calculateAllPendingPermissions")
class CalculateAllPendingPermissionsOperation extends SecurityOperation  {
	
	UUID securityProcessId
	
	Long maxEntitiesToProcessPerIteration = 100

	Boolean thereIsPendingEntityForCalculatingSecurity = false
	
	@Override
	def init() {
		maxEntitiesToProcessPerIteration = Math.max(1, maxEntitiesToProcessPerIteration)
	}
	
	@Override
	def execute() {
		// A new and unique security process identifier is generated
		securityProcessId = UUID.randomUUID()
		// It's going to be processed a chunk of entities with PENDIND state in its security aspect
		(1..maxEntitiesToProcessPerIteration).find {
			// Getting an instance of security with atom updated done insecurityProcessId and securityProcessStatus
			def security = tryGetSecurityForPendingEntity(securityProcessId)
			thereIsPendingEntityForCalculatingSecurity = security != null
			// If don't exist entities to be calculated, we finished the iteration returning true to find method in order to stop
			if (!thereIsPendingEntityForCalculatingSecurity) return true
			// Calculate security for the entity gotten
			def calculateOp = exec(signature:"security.calculatePermissionForEntity", args:[entity:[id:security.entityId]])
			// If permission has changed, all its children are likely required to be calculated too
			if (calculateOp?.atLeastOnePermissionHasChanged) {
				// We process all the children not assigned to any current process that inherits permission
				queryAll("aspect(entity[@id=${security.entityId}]->entity,'security')[@security[isnull(@securityProcessId) && @inheritsPermission=true]]").each {
					markSecurityForEntityAsPending(it)
				}
			}
			// So there are entities which security are pending we return false in order to indicate find method to continue 
			false
		}
		// All entities processed are marked so they're available for more calculations
		queryAll("aspect(entity,'security')[@security[@securityProcessId='${securityProcessId}']]").each {
			// Mark security entity as processed
			markSecurityAsProcessed(it.aspects.security)
		}
		//
		this
	}
}
