package org.aspect.grails.interpreters

import org.aspect.grails.annotations.AspectInterpreter;
import org.aspect.grails.entities.AbstractInterpreter;

@AspectInterpreter(type = "base")
class BaseInterpreter extends AbstractInterpreter {

}
