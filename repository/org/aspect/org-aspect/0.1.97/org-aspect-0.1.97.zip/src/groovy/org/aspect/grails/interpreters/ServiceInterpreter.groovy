package org.aspect.grails.interpreters

import org.aspect.grails.annotations.AspectInterpreter;
import org.aspect.grails.entities.AbstractInterpreter;

@AspectInterpreter(type = "service"/*, innerAspects = "rights"*/)
class ServiceInterpreter extends AbstractInterpreter {

	//
	static String 	ORDER_BY_DEFAULT = "{@id ASC}"
	static Long 	OFFSET_DEFAULT = 0
	static Long 	MAX_DEFAULT = 1000

	def protected executeApplyingInnerAspects(Map innerAspects, Closure closure) {
		engine.pushInnerAspects(innerAspects)
		def r
		try {
			r = closure()
		} finally {
			engine.popInnerAspects()
		}
		r
	}

	@Override
	def handle() {
		executeApplyingInnerAspects(getOperationInnerAspects(operation, interpreter)) {
			super.handle()
		}
	}

	def getOperationInnerAspects(operation, interpreter) {
		Map innerAspectsMap = [:]
		innerAspectsMap.putAll((operation?.innerAspects != "false") ? buildInnerAspectsMap(operation.innerAspects) : [:])
		innerAspectsMap.putAll((interpreter?.innerAspects != "false") ? buildInnerAspectsMap(interpreter.innerAspects) : [:])
		innerAspectsMap
	}

	// Convert an aspect list contained in a string into an aspect list in Map format, as aspectEngine expect
	def buildInnerAspectsMap(String innerAspectString) {
		def innerAspectsMap = [:]
		List<String> innerAspects = innerAspectString.split(",")?.collect {	it.trim() }
		engine.buildInnerAspectsMap(innerAspects)
	}

	@Override
	def exec(Map args) {
		executeApplyingInnerAspects(getInterpreterInnerAspects(interpreter)) {
			super.exec(args)
		}
	}

	def getInterpreterInnerAspects(interpreter) {
		def innerAspectsMap = (interpreter?.innerAspects != "false") ? buildInnerAspectsMap(interpreter.innerAspects) : [:]
		innerAspectsMap
	}
}

