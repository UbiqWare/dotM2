package org.aspect.grails.engines

import org.aspect.core.aql.AqlContext;
import org.aspect.core.aql.Aspect;
import org.aspect.core.aql.entites.EntityType;
import org.aspect.core.aql.entites.InnerAspect;
import org.aspect.core.aql.entites.PersistentEntityType;
import org.aspect.core.engines.AbstractContext

class AspectContext extends AbstractContext {

	static final String	DEFAULT_TARGET = "com.mysql.jdbc.Driver" // "org.h2.Driver" | "com.mysql.jdbc.Driver"

	String target = DEFAULT_TARGET

	//
	def static final aspectTargetToAqlTargetMap = [
			"org.h2.Driver": "H2"
			, "com.microsoft.sqlserver.jdbc.SQLServerDriver": "MS_SQL"
			, "com.mysql.jdbc.Driver": "MYSQL"
	]

	String getAqlTarget() {
		aspectTargetToAqlTargetMap[target]
	}

	//
	String 		entityClassName
	String 		typeClassName
	AqlContext 	aqlContext

	Boolean 	pagination = true
	Long 		offset = 0
	Long 		max = 1000
	Long 		defaultMax = 100
	String 		orderBy = "{@id ASC}"


	AspectContext(String target) {
		this.target = target
	}

	AspectContext(AspectContext sourceAspectContext, AqlContext sourceAqlContext) {
		copyPropertiesFrom(sourceAspectContext)
		this.aqlContext = sourceAqlContext
	}

	AspectContext clone() {
		def newAspectContext = new AspectContext(target)
		newAspectContext.copyPropertiesFrom(this)
		newAspectContext
	}

	void copyPropertiesFrom(def sourceAspectContext) {
		this.properties.each { propertyName, propertyValue ->
			if (propertyName in ['aqlTarget', 'class', 'metaClass', 'aspectTargetToAqlTargetMap', 'DEFAULT_TARGET', 'orderBySpecified']) return
			this[propertyName] = sourceAspectContext.hasProperty(propertyName) ? sourceAspectContext[propertyName] : null
		}
	}

	Boolean isOrderBySpecified() {
		orderBy == null || orderBy == ""
	}

	public void set(String name, Object value) {
		aqlContext.set(name, value);
	}

	public Object get(String name) {
		return aqlContext.get(name);
	}

	PersistentEntityType getPersistentEntityType(String name) {
		return aqlContext.getPersistentEntityType(name);
	}

	void setPersistentEntityType(String name, PersistentEntityType persistentEntityType) {
		aqlContext.setPersistentEntityType(name, persistentEntityType);
	}

	EntityType getEntityType(String name) {
		return aqlContext.getEntityType(name);
	}

	void setEntityType(String name, EntityType entityType) {
		aqlContext.setEntityType(name, entityType);
	}

	def getEntityTypeMetadata(String name) {
		return aqlContext.get("__entity_type_metada__$name");
	}

	public void setEntityTypeMetadata(entityTypeMetadata) {
		aqlContext.set("__entity_type_metada__${entityTypeMetadata.name}", entityTypeMetadata);
	}

	Aspect getAspect(String name) {
		return aqlContext.getAspect(name);
	}

	void setAspect(String name, Aspect aspect) {
		aqlContext.setAspect(name, aspect);
	}

	public EntityType getBaseEntityType() {
		return aqlContext.getBaseEntityType();
	}

	public void setBaseEntityType(EntityType entityType) {
		aqlContext.setBaseEntityType(entityType);
	}

	public void removeInnerAspect(String innerAspect) {
		aqlContext.removeInnerAspect(innerAspect);
	}

	public void addInnerAspect(String innerAspectName) {
		aqlContext.addInnerAspect(innerAspectName);
	}

	public void addInnerAspect(String innerAspectName, Aspect innerAspect) {
		aqlContext.addInnerAspect(innerAspectName, innerAspect);
	}

	public Map<String, InnerAspect> getInnerAspects() {
		return aqlContext.getInnerAspects();
	}

	public void setInnerAspects(Map<String, InnerAspect> innerAspects) {
		aqlContext.setInnerAspects(innerAspects);
	}

	public InnerAspect newInnerAspect(String aspectName) {
		return aqlContext.newInnerAspect(aspectName);
	}

	public InnerAspect newInnerAspect(Aspect aspect) {
		return aqlContext.newInnerAspect(aspect);
	}

	// TODO Move to core
	def setVariable(String name, String value) {
		aqlContext.setVariable(name, value)
	}

	// TODO Move to core
	def getVariable(String name) {
		aqlContext.getVariable(name)
	}

}
