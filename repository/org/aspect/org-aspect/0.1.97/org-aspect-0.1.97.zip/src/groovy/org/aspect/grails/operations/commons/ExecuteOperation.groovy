package org.aspect.grails.operations.commons

import org.aspect.grails.annotations.AspectOperation;
import org.aspect.grails.entities.Interpreter;
import org.aspect.grails.entities.Operation;
import org.aspect.grails.operations.CoreOperation;


// Core operation that allows execute an operation selecting the interpreter. It extends aspectEngine functionality at core tier
// Both, interpreter and operation are queried so right permissions are applied
// This way, it is possible to change default operation interpreter, who is a property of an operation. Even, compile the operation and execute
// in a different platform. 
// Example: Make a DSL who generate R code which will be execute by R interpreter

// TODO implement
@AspectOperation(signature = "common.execute")
class ExecuteOperation extends CoreOperation  {
	
	def interpreter
	def operation
	def args
	
	def interpreterInstance
	def operationInstance

	@Override
	def init() {
		// TODO check args
		if (interpreter instanceof Map || interpreter instanceof Interpreter) {
			interpreterInstance = read(interpreter)
		} else {
			interpreterInstance = first("interpreter[@interpreterType='${interpreter}']")
		}
		//
		if (operation instanceof Map || operation instanceof Operation) {
			operationInstance = read(operation)
		} else {
			operationInstance = first("operation[@signature='${operation}']")
		}
	}

	@Override
	def execute() {
		exec(operation:operationInstance, interpreter:interpreterInstance, args:args)
	}

}