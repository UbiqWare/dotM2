package org.aspect.grails.engines
//
import java.util.Map;
import org.aspect.core.engines.AbstractEngine
import org.aspect.core.engines.AbstractOperationExecutionEngine
import org.aspect.core.entities.Interpreter
import org.aspect.core.entities.Operation
import org.aspect.grails.entities.LTOperationStatus;
import org.aspect.grails.entities.LongTermOperation;
import org.aspect.grails.entities.Process;


class OperationExecutionEngine extends AbstractOperationExecutionEngine {
	
	def execute(AbstractEngine runtimeEngine, def operation, def interpreter, Map args = null, Map executeModifiers = null) {
		if (executeModifiers?.longTerm || operation instanceof Process) {
			executeLongTermOperation(runtimeEngine, operation, interpreter, args)
		} else {
			executeOperation(runtimeEngine, operation, interpreter, args)
		}
	}
	
	def protected executeOperation(AbstractEngine runtimeEngine, def operation, def interpreter, Map args = null, Map executeModifiers = null) {
		def interpreterImpl = runtimeEngine.newInstance(interpreter?.localFullName())
		interpreterImpl.engine = runtimeEngine
		interpreterImpl.interpreter = interpreter ?: operation.interpreter
		interpreterImpl.args = args
		interpreterImpl.operation = operation
		interpreterImpl?.handle()
	}

	// 
	Map taskList = [:]
		
	//
	def protected executeLongTermOperation(AbstractEngine engine, def operation, def interpreter, Map args = null, Map executeModifiers = null) {
		def newLTO = new LongTermOperation(name:java.util.UUID.randomUUID() as String, operation:operation, interpreter:interpreter, args:engine.serialize(args))
		newLTO = engine.save(newLTO)
		synchronized(taskList) {
			def thread = Thread.start { 
				longTermOperationExecute()	
			}
			taskList[thread] = [ltoId:newLTO.id, engine:engine.clone()]
		}
		newLTO
	}
	
	def protected longTermOperationExecute() {
		def runtimeEngine
		def lto, result
		def threadContext 
		//
		try {
			//
			synchronized(taskList) {
				threadContext = taskList[Thread.currentThread()]
				runtimeEngine = threadContext.engine
			}
			// Reload info. Hibernate is not thread safe so we get other instance copy for the current thread
			lto = runtimeEngine.first("LongTermOperation[@id=${threadContext.ltoId}]")
			// Status is updated
			lto.status = LTOperationStatus.RUNNING.value()
			runtimeEngine.save(lto)
			// Preparing args for the long term operation
			def args = runtimeEngine.deserialize(lto.args)
			args["longTermOperationId"] = lto.id
			// Operation is executed
			executeOperation(runtimeEngine, lto.operation, lto.interpreter, args)
		} catch (Exception e) {
			lto.result = e.toString()
			lto.status = LTOperationStatus.FINISHED_WITH_ERROR.value()
			runtimeEngine.save(lto)
		} finally {
			// Persist status
			lto.status = LTOperationStatus.FINISHED.value()
			runtimeEngine.save(lto)
			synchronized(taskList) {
				taskList.remove(Thread.currentThread())
			}
		}

	}

}
