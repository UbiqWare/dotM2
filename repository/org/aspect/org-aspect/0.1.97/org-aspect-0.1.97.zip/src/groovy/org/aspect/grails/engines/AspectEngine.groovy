package org.aspect.grails.engines
//
import org.apache.commons.logging.LogFactory
import grails.util.Holders
import org.hibernate.SessionFactory
import org.codehaus.groovy.grails.commons.GrailsApplication
import org.aspect.core.aql.AqlEngine;
import org.aspect.core.aql.Aspect;
import org.aspect.core.aql.entites.InnerAspect;
import org.aspect.core.engines.AbstractEngine
import org.aspect.core.engines.AbstractContext
import org.aspect.grails.aspects.Relationship;
import org.aspect.grails.entities.AbstractOperation
import org.aspect.grails.entities.AspectList
import org.aspect.grails.entities.Content;
import org.aspect.grails.entities.ContentRepository;
import org.aspect.grails.entities.Entity;
import org.aspect.grails.entities.Type;
import org.aspect.grails.exceptions.NotFoundException
import org.aspect.grails.exceptions.TypeNotFoundException
import org.aspect.grails.operations.contents.repositories.AbstractContentRepository;

//
class AspectEngine extends AbstractEngine {

	//
	GrailsApplication 	grailsApplication
	SessionFactory 		sessionFactory

	// Aql engine through which execute AQL queries
	AqlEngine aqlEngine

	// AspectContext for passing args, modifiers and flags
	AspectContext aspectContext

	//
	List innerAspectStack = []

	//
	String 	ORDER_BY_DEFAULT = "{@id ASC}"
	Long 	OFFSET_DEFAULT = 0
	Long 	NUMBER_MAX = 100
	Long 	NUMBER_DEFAULT = 10

	protected static final log = LogFactory.getLog(AspectEngine)

	AspectEngine() {
		this(AspectContext.DEFAULT_TARGET)
	}

	//
	AspectEngine(String targetId) {
		//
		targetId = targetId ?: AspectContext.DEFAULT_TARGET
		aspectContext = new AspectContext(targetId)
		aqlEngine = new AqlEngine(aspectContext.aqlTarget)
		aspectContext.aqlContext = aqlEngine.aqlContext
		operationExecutionEngine = new OperationExecutionEngine()
		loadBeans()
	}

	@Override
	def clone() {
		AspectEngine newAspectEngine = new AspectEngine(this.target)
		newAspectEngine.aspectContext = this.aspectContext.clone()
		newAspectEngine.aqlEngine = this.aqlEngine.clone()
		newAspectEngine.aspectContext.aqlContext = newAspectEngine.aqlEngine.aqlContext
		newAspectEngine.innerAspects = buildInnerAspectsMap(innerAspects)
		//
		newAspectEngine.ORDER_BY_DEFAULT = ORDER_BY_DEFAULT
		newAspectEngine.OFFSET_DEFAULT = OFFSET_DEFAULT
		newAspectEngine.NUMBER_MAX = NUMBER_MAX
		newAspectEngine.NUMBER_DEFAULT = NUMBER_DEFAULT
		newAspectEngine
	}

	def buildInnerAspectsMap(Map sourceInnerAspectMap) {
		Map localInnerAspectsMap = [:]
		sourceInnerAspectMap?.each { String key, value ->
			localInnerAspectsMap[key] = newInnerAspect(key)
		}
		localInnerAspectsMap
	}

	def buildInnerAspectsMap(List<String> innerAspectList) {
		Map localInnerAspectsMap = [:]
		innerAspectList?.each { String aspectName ->
			localInnerAspectsMap[aspectName] = newInnerAspect(aspectName)
		}
		localInnerAspectsMap
	}

	// Adding an alias to aspectContext
	AbstractContext getContext() {
		aspectContext
	}

	def void setContext(value) {
		this.aspectContext = value
	}

	//
	protected void loadBeans() {
		grailsApplication = grailsApplication ?: Holders.grailsApplication
		sessionFactory = sessionFactory ?: grailsApplication.mainContext.getBean("sessionFactory")
	}

	//
	String getTarget() {
		return aspectContext.target
	}

	//	
	def adaptEntityId(id) {
		if (id instanceof Long || id instanceof Integer)
			id = [id:id]
		else
			id = id.toString().isNumber() ? [id:Long.parseLong(id.toString())] : id
		id
	}

	def static getClass(String className) {
		if (!className)
			throw new IllegalArgumentException('className')
		GrailsApplication.classLoader.loadClass(className)
	}

	def static newInstance(String className) {
		getClass(className).newInstance()
	}

	def static newInstance(String className, args) {
		getClass(className).newInstance(args)
	}

	def private attach(instanceObject) {
		if (!instanceObject) return
		def instance = instanceObject
		//if (!instanceObject.metaClass.respondsTo(instanceObject, "isAttached")) return instance
		if (!instanceObject.isAttached()) {
			instance = instanceObject.merge()
			if (!instance) {
				instance = sessionFactory.currentSession.get(instanceObject.class.name, instanceObject.id)
				if (instance)
					instance.refresh()
			}
		}
		instance
	}

	def org.aspect.core.entities.Entity newGenericEntityInstance(String className) {
		try {
			def instance = newInstance(className)
			attach(instance)
			instance
		} catch (ClassNotFoundException e) {
			throw new TypeNotFoundException("could not load class '${className}'")
		}
	}

	def Entity newInstanceFromType(Type type) {
		if (!type) {
			newGenericEntityInstance(Entity.class.name)
		} else {
			Entity entityInstance = newGenericEntityInstance(type.localFullName())
			entityInstance.type = type
			entityInstance
		}
	}

	def static Type getType(data) {
		if (data)
			getTypeById(data?.type?.id)
		else
			null
	}

	def static Type getTypeById(def typeId) {
		// TODO check if it is required a query here
		// TODO Use a cache
		//
		if (!typeId) return null
		def type = Type.get(typeId)
		if (type == null)
			throw new TypeNotFoundException()
		type
	}

	def newInstance(Map rawInstance) {
		if (!(rawInstance instanceof Map && rawInstance.containsKey("className"))) return
		def newInstance = newGenericEntityInstance(rawInstance.className)
		setProperties(newInstance, rawInstance)
	}

	def rawInstanceToEntityWithType(Type type, Map rawInstance) {
		if (!rawInstance)
			throw new NotFoundException('rawInstance is null or empty')
		//
		Entity entity = newInstanceFromType(type)
		setProperties(entity, rawInstance)
		entity.aspects = [:]
		// Last, aspects
		rawInstance?.aspects?.each { aspectName, aspectNameValue ->
			def aspect = rawInstance[aspectName]
			entity.aspects[aspectName] = (aspect instanceof List) ? aspect.collect { newInstance(it) } : newInstance(aspect)
		}
		//
		entity
	}

	def setProperties(instance, Map rawInstance) {
		if (!instance) throw new IllegalArgumentException('instance')
		instance.properties = rawInstance ?: instance.properties
		instance.id = rawInstance['id'] ? rawInstance['id'].toString().toLong() : instance.id
		if (instance.properties.containsKey('version'))
			instance.version =  rawInstance.containsKey('version') ? rawInstance['version'] : instance.version
		instance
	}

	def setProperties(target, org.aspect.core.entities.Entity source) {
		if (!target) throw new IllegalArgumentException('instance')
		target.properties = source ? source.properties : target.properties
		target.id = source['id'] ? source['id'].toString().toLong() : target.id
		if (target.properties.containsKey('version'))
			target.version = source.properties.containsKey('version') ? source['version'] : target.version
		target
	}


	@Override
	def public getOperation(Map args) {
		def operation = (args?.signature) ? first("operation[@signature='${args.signature}']")
				: first(args?.query)
		//
		if (!operation) throw new RuntimeException("Operation '${args?.signature ?: args?.query}' not found")
		// Full operation is readed. It could be a Script or other type with specific properties, not just operation's properties
		operation = read(operation)
	}

	def execute(def operation, def interpreter, Map args = null, Map executeModifiers = null) {
		operationExecutionEngine.execute(this, operation, interpreter, args, executeModifiers)
	}

	def execute(def operation, Map args = null, Map executeModifiers = null) {
		execute(operation, operation?.interpreter, args, executeModifiers)
	}

	def execute(String signature, def interpreter, Map args = null, Map executeModifiers = null) {
		def operation = interpreter ? executeByQuery("operation[@signature='${signature}']", interpreter, args, executeModifiers)
				: executeByQuery("operation[@signature='${signature}']", args as Map, executeModifiers as Map)
	}

	def execute(String signature, Map args = null, Map executeModifiers = null) {
		def operation = executeByQuery("operation[@signature='${signature}']", args, executeModifiers)
	}

	def executeByQuery(String aql, def interpreter, Map args = null, Map executeModifiers = null) {
		//
		execute(getOperation(query:aql), interpreter, args, executeModifiers)
	}

	def executeByQuery(String aql, Map args = null, Map executeModifiers = null) {
		//
		execute(getOperation(query:aql), args, executeModifiers)
	}

	def query(String aql, Long offset = context.offset, Long max = context.defaultMax, String orderBy = context.orderBy) {
		query(aql, offset, max, orderBy, false)
	}

	def queryMap(String aql, Long offset = context.offset, Long max = context.defaultMax, String orderBy = context.orderBy) {
		query(aql, offset, max, orderBy, true)
	}

	def queryAll(String aql, Long offset = context.offset, Long max = context.defaultMax, String orderBy = context.orderBy) {
		query(aql, offset, max, orderBy, false, true)
	}

	def queryMapAll(String aql, Long offset = context.offset, Long max = context.defaultMax, String orderBy = context.orderBy) {
		query(aql, offset, max, orderBy, true, true)
	}

	def query(String aql, Long offset = context.offset, Long max, String orderBy, Boolean asMap, Boolean all = false) {
		//
		if (!aql) throw new IllegalArgumentException('aql cannot be null or empty')
		offset = offset ?: 0
		max = Math.min(max ?: 1000, 1000)
		orderBy = orderBy ?: "{@id ASC}"
		String q = aql
		//
		if (context?.orderBy && context?.pagination) {
			q = context?.pagination ? "page(${q}, ${offset}, ${max}, ${orderBy})" : q
		} else {
			q = context?.orderBy ? "orderby(${q}, ${orderBy})" : q
			q = context?.pagination ? "page(${q}, ${offset}, ${max})" : q
		}
		log.trace "aql query: $q"
		String translatedQuery = aqlEngine.translate(q)
		log.trace "sql query: $translatedQuery"
		aqlEngine.interpreter.applicationContext = grailsApplication.mainContext
		aqlEngine.interpreter.interpret(translatedQuery);
		def entityList = aqlEngine.interpreter.resultList.collect { rawEntity ->
			fillAspects(rawEntity)
			asMap ? rawEntity : adaptMapInstanceToEntity(rawEntity)
		}
		// if all are required, an AspectList with an AspectPagedIterator is returned
		if (all) {
			def aspectEntityList = new AspectList(this, q, orderBy, max.intValue())
			aspectEntityList.list = entityList
		} else {
			entityList
		}
	}

	// Just for tests
	def translate(String aql, Long offset = context.offset, Long max= context.defaultMax, String orderBy = context.orderBy, Boolean asMap = false, Boolean all = false) {
		//
		if (!aql) throw new IllegalArgumentException('aql cannot be null or empty')
		offset = offset ?: 0
		max = Math.min(max ?: 1000, 1000)
		orderBy = orderBy ?: "{@id ASC}"
		String q = aql
		//
		if (context?.orderBy && context?.pagination) {
			q = context?.pagination ? "page(${q}, ${offset}, ${max}, ${orderBy})" : q
		} else {
			q = context?.orderBy ? "orderby(${q}, ${orderBy})" : q
			q = context?.pagination ? "page(${q}, ${offset}, ${max})" : q
		}
		log.trace "aql query: $q"
		String translatedQuery = aqlEngine.translate(q)
		log.trace "sql query: $translatedQuery"
		[aql:q, translatedQuery:translatedQuery]
	}

	def private fillAspects(mapEntity) {
		mapEntity["aspects"] = [:]
		mapEntity.findAll { k, v ->
			def isAspect = v instanceof Map && v.containsKey("className")
			isAspect ?: v instanceof List && v[0] instanceof Map && v[0].containsKey("className")
		}.each { k, v ->
			mapEntity.aspects[k] = v
		}
	}

	def first(String aql, String orderBy = context.orderBy) {
		def query = query("top($aql, 1)", 0, 1, orderBy)
		query ? query[0] : null
	}

	def firstMap(String aql, String orderBy = context.orderBy) {
		def query = queryMap("top($aql, 1)", 0, 1, orderBy)
		query ? query[0] : null
	}

	def private getEntityFromAspect(org.aspect.core.entities.Aspect aspect) {
		if (!aspect) return null
		def leftPropertyName = getAspectLeftPropertyName(aspect)
		def entity = [id:aspect[leftPropertyName]]
		entity = read(entity)
		setAspectLeftFromEntity(aspect, entity)
		entity
	}

	def setAspectLeftFromEntity(def aspect, def entity) {
		if (!aspect) return null
		aspect[getAspectLeftPropertyName(aspect)] = entity.id
		aspect
	}

	def getAspectLeftPropertyName(def aspect) {
		if (!aspect) return null
		if (aspect instanceof org.aspect.core.entities.Aspect) {
			aspect.class.getAnnotation(org.aspect.grails.annotations.Aspect.class).left()
		} else {
			def clazz = getClass(aspect.className)
			clazz.getAnnotation(org.aspect.grails.annotations.Aspect.class).left()
		}
	}

	def getAspectRightPropertyName(def aspect) {
		if (!aspect) return null
		if (aspect instanceof org.aspect.core.entities.Aspect) {
			aspect.class.getAnnotation(org.aspect.grails.annotations.Aspect.class).right()
		} else {
			def clazz = getClass(aspect.className)
			clazz.getAnnotation(org.aspect.grails.annotations.Aspect.class).right()
		}
	}

	// Check left and right property are not changed programmatically if the aspect already exists
	def private validateAspectIntegrity(def savedInstance, def newInstance) {
		// If it's not aspect and it hasn't an id specified, we return
		if (!(savedInstance instanceof org.aspect.core.entities.Aspect) || !newInstance?.id) return
		def left = getAspectLeftPropertyName(savedInstance)
		def right = getAspectRightPropertyName(savedInstance)
		def validate = savedInstance[left] == newInstance[left] && right != "null" ? savedInstance[right] == newInstance[right] : true
		if (!validate)
			throw new RuntimeException("Unable to change left or right aspect property one it has been created: Ids: ${savedInstance.id}, ${savedInstance[left]}, ${newInstance[left]}")
	}

	def save(def rawInstance, def aspectEntity = null) {
		if (aspectEntity == null && rawInstance instanceof org.aspect.core.entities.Aspect) {
			// If an aspect is tried to be save without an entity, we check entity is accesible
			aspectEntity = getEntityFromAspect(rawInstance)
			if (!aspectEntity) return null
		}
		//
		def instance = rawInstance
		def clazz = rawInstance instanceof org.aspect.core.entities.Aspect ? rawInstance.class : Entity
		def currentInstance = null
		//
		if (rawInstance instanceof Map) {
			if (rawInstance.containsKey("className")) {
				// An aspect is expected
				instance = setProperties(newGenericEntityInstance(rawInstance.className), rawInstance)
			} else if (rawInstance.containsKey("type")) {
				// An entity is expected
				instance = adaptMapInstanceToEntity(rawInstance)
			} else {
				throw new TypeNotFoundException("Unexpected Map format for ${rawInstance}")
			}
		} else if (!(rawInstance instanceof Entity || rawInstance instanceof org.aspect.core.entities.Aspect)) {
			throw new TypeNotFoundException("Unexpected type ${rawInstance}")
		}
		//
		if (instance.id != 0) {
			currentInstance = clazz.get(instance.id)
			validateAspectIntegrity(currentInstance, instance)
			instance = copyPropertiesFrom(instance, currentInstance)
		}
		instance.save(flush:true, failOnError: true)
		//
		if (!instance.hasProperty("aspects")) return instance
		def aspectCreated
		instance?.aspects?.each { aspectName, aspectValue ->
			if (isAggregatedAspect(aspectName)) return
			if (!aspectValue) return
			if (aspectValue instanceof List) {
				aspectValue.each { aspectInstance ->
					setAspectLeftFromEntity(aspectInstance, instance)
					aspectCreated = save(aspectInstance, instance)
					copyPropertiesFrom(aspectCreated, aspectInstance)
				}
			} else {
				setAspectLeftFromEntity(aspectValue, instance)
				save(aspectValue, instance)
			}
		}
		//
		instance
	}

	private boolean isAggregatedAspect(String aspectName) {
		Aspect aspect = aspectContext.getAspect(aspectName)
		aspect ? aspect.isAggregateOf() : false
	}

	def create(def rawInstance, def parent = null, def role = null) {
		// TODO Add logic here to manage update in a different way of create
		def newInstance = save(rawInstance)
		def r = (newInstance && parent) ? link(parent, newInstance, role) : null
		parent == null ? newInstance : (r ? newInstance : null)
	}

	private def readFullEntity(rawEntity) {
		//
		pushInnerAspects([:])
		//
		def typeData = (rawEntity?.type?.id) ? first("type[@id=${rawEntity.type.id}]")
											 : first("entity[@id=${rawEntity.id}]")?.type
		def aql = "entity[@id=${rawEntity.id}]"
		if (typeData?.name) {
			String typeName = (typeData.isBaseType()) ? Type.types.base.name : typeData.name
			aql = "${typeName}[@id=${rawEntity.id}]"
		}
		//
		popInnerAspects()
		//
		first(aql)
	}

	def read(rawEntity) {
		// TODO check and test
		rawEntity = adaptEntityId(rawEntity)
		def instance
		if (rawEntity instanceof Map) {
			if (rawEntity.containsKey("className")) {
				// An aspect is expected
				def clazz = getClass(rawEntity.className)
				instance = clazz.get(rawEntity.id)
				attach(instance)
			} else if (rawEntity.containsKey("id")) {
				instance = readFullEntity(rawEntity)
			} else {
				throw new TypeNotFoundException("Unexpected Map format for ${rawEntity}")
			}
		} else if (!(rawEntity instanceof Entity || rawEntity instanceof org.aspect.core.entities.Aspect)) {
			throw new TypeNotFoundException("Unexpected type ${rawEntity}")
		} else {
			if (rawEntity instanceof org.aspect.core.entities.Aspect) {
				instance = rawEntity.class.get(rawEntity.id)
				instance = attach(instance)
			} else {
				instance = readFullEntity(rawEntity)
			}
		}
		instance
	}

	def update(rawEntity) {
		// TODO	check and test
		// TODO Add logic here to manage update in a different way of create
		save(rawEntity)
	}

	def delete(rawEntity, def aspectEntity = null) {
		if (aspectEntity == null && rawEntity instanceof org.aspect.core.entities.Aspect) {
			// If an aspect is tried to be save without an entity, we check entity is accesible
			aspectEntity = getEntityFromAspect(rawEntity)
			if (!aspectEntity) return null
		}
		//
		rawEntity = adaptEntityId(rawEntity)
		def internalRawEntity = rawEntity
		def instance
		if (rawEntity instanceof Map) {
			if (rawEntity.containsKey("className")) {
				// An aspect is expected
				def clazz = getClass(rawEntity.className)
				instance = clazz.get(rawEntity.id)
			} else if (rawEntity.containsKey("id")) {
				// An entity is expected
				instance = Entity.get(rawEntity.id)
				internalRawEntity = internalRawEntity.containsKey("aspects") ? adaptMapInstanceToEntity(rawEntity) : internalRawEntity
			} else {
				throw new TypeNotFoundException("Unexpected Map format for ${rawEntity}")
			}
		} else if (!(rawEntity instanceof Entity || rawEntity instanceof org.aspect.core.entities.Aspect)) {
			throw new TypeNotFoundException("Unexpected type ${rawEntity}")
		} else {
			instance = rawEntity.class.get(rawEntity.id)
		}
		//
		if (internalRawEntity.hasProperty("aspects")) {
			rawEntity.aspects.each { aspectName, aspectValue ->
				if (!aspectValue) return
				if (aspectValue instanceof List) {
					aspectValue.each { aspectInstance ->
						delete(aspectInstance, instance)
					}
				} else {
					delete(aspectValue, instance)
				}
			}
		}
		//
		validateAspectIntegrity(instance, rawEntity)
		instance.delete(flush:true, failOnError: true)
		true
	}

	def undelete(rawEntity) {
		// TODO	implement, check and test
		throw new RuntimeException("undelete operation not implemented yet")
	}

	def destroy(rawEntity) {
		// TODO	implement, check and test
		throw new RuntimeException("destroy operation not implemented yet")
	}

	def private getRelationshipInstance(parentRawEntity, childRawEntity, roleRawEntity = null) {
		// TODO check and test
		parentRawEntity = adaptEntityId(parentRawEntity)
		childRawEntity = adaptEntityId(childRawEntity)
		roleRawEntity = adaptEntityId(roleRawEntity)
		//
	}


	def link(parent, child, role = null) {
		def (parentList, childList, roleInstance) = adaptParentChildAndRoleData(parent, child, role)
		def rList = []
		parentList.each { p -> childList.each { c ->
			def parentInstance = adaptEntityId(p)
			def childInstance = adaptEntityId(c)
			role = adaptEntityId(roleInstance)
			def r = Relationship.findWhere(parentId:parentInstance.id, childId:childInstance.id, roleId:role?.id)
			r = r ?: new Relationship(parentId:parentInstance.id, childId:childInstance.id, role:role).save(flush:true, failOnError:true)
			rList << [parent:p, child:c, role:role, relationship:r]
		}}
		rList.size() == 1 ? rList[0].relationship : rList
	}

	def unlink(parent, child, role = null) {
		def (parentList, childList, roleInstance) = adaptParentChildAndRoleData(parent, child, role)
		def rList = []
		parentList.each { p -> childList.each { c ->
			def parentInstance = adaptEntityId(p)
			def childInstance = adaptEntityId(c)
			role = adaptEntityId(roleInstance)
			def r = Relationship.findWhere(parentId:parentInstance.id, childId:childInstance.id, roleId:role?.id)
			if (r) {
				r.delete(flush:true, failOnError: true)
				rList << [parent:p, child:c, role:role, unlinked:true]
			} else {
				rList << [parent:p, child:c, role:role, unlinked:false]
			}
		}}
		rList.size() == 1 ? rList[0].unlinked : rList
	}

	def adaptParentChildAndRoleData(parent, child, role) {
		def parentList = parent instanceof String ? queryAll(parent).collect() : [parent]
		def childList = child instanceof String ? queryAll(child).collect() : [child]
		role = role instanceof String ? first(role) : role
		[parentList, childList, role]
	}

	def copyPropertiesFrom(source, target = [:]) {
		source.properties.findAll { k, v ->	!(k in ['class', 'metaClass']) }.each { k, v ->	target[k] = v }
		target
	}

	def Map adaptEntityToMapInstance(def source) {
		if (!source) throw new NotFoundException('rawInstance is null or empty')
		//
		def map = copyPropertiesFrom(source)
		map["aspects"] = [:]
		map["id"] = source.id
		//
		source.aspects.each { aspectName, aspectValue ->
			if (aspectValue instanceof List) {
				map[aspectName] = aspectValue.collect {
					def target = copyPropertiesFrom(it)
					target["id"] = it.id
					target["className"] = it.class.name
					target
				}
			} else if (aspectValue) {
				map[aspectName] = copyPropertiesFrom(aspectValue)
			}
			map.aspects[aspectName] = null
		}
		//
		map
	}

	def org.aspect.core.entities.Entity adaptMapInstanceToEntity(Map map) {
		rawInstanceToEntityWithType(getTypeById(map?.type?.id), map)
	}

	def addQueryAlias(String entityName, String aql) {
		aqlEngine.addEntityByQuery(entityName, aql)
	}

	def addQueryFunction(String functionSignature, String aql) {
		aqlEngine.setFunctionByQuery(functionSignature, aql)
	}

	def content(def entity) {
		AbstractContentRepository.content(entity, this)
	}

	def createContent(def entity, def contentProperties, ContentRepository contentRepository) {
		AbstractContentRepository.createContent(entity, contentProperties, contentRepository, this)
	}

	def deleteContent(def entity) {
		AbstractContentRepository.deleteContent(entity, this)
	}

	def truncateContent(def entity) {
		AbstractContentRepository.truncateContent(entity, this)
	}

	def byte[] readContentData(def content) {
		AbstractContentRepository.readContentData(content, this)
	}

	def InputStream getContentDataInputStream(def content) {
		AbstractContentRepository.getContentDataInputStream(content, this)
	}

	def InputStream getEntityContentDataInputStream(def entity) {
		AbstractContentRepository.getEntityContentDataInputStream(entity, this)
	}

	def writeContentData(def content, byte[] data) {
		AbstractContentRepository.writeContentData(content, data, this)
	}

	def writeEntityContentData(def entity, InputStream inputStream) {
		AbstractContentRepository.writeEntityContentData(entity, inputStream, this)
	}

	def appendContentData(def content, byte[] data) {
		AbstractContentRepository.appendContentData(content, data, this)
	}

	def Content initiateMultipartWrite(def entity, def contentProperties) {
		AbstractContentRepository.initiateMultipartWrite(entity, contentProperties, this)
	}

	def Content appendContentPart(def content, byte[] part) {
		AbstractContentRepository.appendContentPart(content, part, this)
	}

	def Content completeMultipartWrite(def content) {
		AbstractContentRepository.completeMultipartWrite(content, this)
	}

	def Boolean abortMultipartWrite(def content) {
		AbstractContentRepository.abortMultipartWrite(content, this)
	}

	// TODO Move to core
	public void removeInnerAspect(String innerAspect) {
		aspectContext.removeInnerAspect(innerAspect)
	}

	// TODO Move to core
	public void addInnerAspect(String innerAspectName) {
		aspectContext.addInnerAspect(innerAspectName)
	}

	// TODO Move to core
	public void addInnerAspect(String... innerAspectNames) {
		innerAspectNames?.each {
			addInnerAspect(it.toString())
		}
	}

	// TODO Move to core
	public void addInnerAspect(String innerAspectName, Aspect innerAspect) {
		aspectContext.addInnerAspect(innerAspectName, innerAspect)
	}

	// TODO Move to core
	public Map<String, InnerAspect> getInnerAspects() {
		return aspectContext.getInnerAspects()
	}

	// TODO Move to core
	public void setInnerAspects(Map<String, InnerAspect> innerAspects) {
		aspectContext.setInnerAspects(innerAspects);
	}

	// TODO Move to core
	public InnerAspect newInnerAspect(String aspectName) {
		return aspectContext.newInnerAspect(aspectName);
	}

	// TODO Move to core
	public InnerAspect newInnerAspect(Aspect aspect) {
		return aspectContext.newInnerAspect(aspect);
	}

	def pushInnerAspects(def newInnerAspects) {
		newInnerAspects = newInnerAspects ?: [:]
		innerAspectStack.push(newInnerAspects)
		setInnerAspects(newInnerAspects)
	}

	def popInnerAspects() {
		if (innerAspectStack.size() == 0) return null
		def currentInnerAspect = innerAspectStack.pop()
		setInnerAspects(peekInnerAspects())
		currentInnerAspect
	}

	def peekInnerAspects() {
		if (innerAspectStack.size() == 0)
			return null
		innerAspectStack.last()
	}

	// TODO Move to core
	def setVariable(String name, String value) {
		aspectContext.setVariable(name, value)
	}

	// TODO Move to core
	def getVariable(String name) {
		aspectContext.getVariable(name)
	}

	// TODO Move to core
	public void set(String name, Object value) {
		aspectContext.set(name, value);
	}

	// TODO Move to core
	public Object get(String name) {
		return aspectContext.get(name);
	}

	def setCurrentUser(def user) {
		set('$$currentUser$$', user)
		setVariable("userId", user?.id?.toString() ?: "")
		setVariable("userGroups", user?.groups ? user.groupsForInList() : "")
	}

	def getCurrentUser() {
		get('$$currentUser$$')
	}


	// TODO Move to org.aspect.core.operations.AbstractOperation in AspectCore
	def static serialize(def o) {
		AbstractOperation.serialize(o)
	}

	// TODO Move to org.aspect.core.operations.AbstractOperation in AspectCore
	def static deserialize(String s) {
		AbstractOperation.deserialize(s)
	}

	// TODO Move to org.aspect.core.operations.AbstractOperation in AspectCore
	def findOrSave(def rawEntity, def parent = null, def role = null) {
		def typeId = rawEntity?.typeId ?: rawEntity
		def currentEntity = null
		if (rawEntity?.id) {
			currentEntity = first("entity[@id = ${rawEntity.id}]")
		} else if (rawEntity?.typeId) {
			currentEntity = first("entity[@name = '${rawEntity.name} && @typeId = ${rawEntity.typeId}']")
		} else if (rawEntity?.type?.id) {
			currentEntity = first("entity[@name = '${rawEntity.name} && @typeId = ${rawEntity.type.id}']")
		} else {
			currentEntity = first("entity[@name = '${rawEntity.name}']")
		}
		currentEntity = currentEntity ? read(currentEntity) : create(rawEntity, parent, role)
	}

}

