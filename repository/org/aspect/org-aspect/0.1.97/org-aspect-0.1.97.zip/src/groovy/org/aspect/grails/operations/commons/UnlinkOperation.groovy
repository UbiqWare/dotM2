package org.aspect.grails.operations.commons

import org.aspect.grails.annotations.AspectOperation;

@AspectOperation(signature = "common.unlink")
class UnlinkOperation extends LinkOperation {

	@Override
	def execute() {
		unlink(parent, child, role)
	}

}
