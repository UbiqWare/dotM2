package org.aspect.grails.operations.security

import org.aspect.grails.engines.AspectEngine
import org.aspect.grails.operations.CoreOperation
import org.aspect.grails.aspects.SecurityProcessStatus
import org.aspect.grails.aspects.Security
import org.aspect.grails.aspects.Permission
import org.hibernate.LockMode
import org.aspect.grails.entities.User
import org.aspect.grails.entities.UserGroup


class SecurityOperation extends CoreOperation {	
	
	def entity
	
	def checkIsAUser(def e) {
		def u = e instanceof User ? e : first("user[@id=${e?.id}]")
		if (!u) throw new Exception("Entity provided is not a User: id=${entity?.id}")
		u
	}

	def checkIsAUserGroup(def e) {
		def u = e instanceof UserGroup ? e : first("userGroup[@id=${e?.id}]")
		if (!u) throw new Exception("Entity provided is not a UserGroup: id=${entity?.id}")
		u
	}

	String buildUserGroupList(def entity) {
		Boolean c = false
		StringBuilder list = new StringBuilder().append(entity.id).append(",")
		list.append(queryAll("aspect(usergroup,'relationship')[@relationship[@childId = ${entity.id}]]").collect{ c = true; it.id}.join(","))
		list.append(c ? "," : "").toString()
	}

	def static final Long MARK_AS_DELETED = 1
	def static final Long NO_MARK = 0
	
	def markInheritedPermissionsAsDeletedOrZero(def entity) {
		boolean eol = false
		long offset = 0
		while (!eol) {
			def entityListToDelete = query("aspect(entity[@id=${entity.id}], 'permission')[@permission[@permissionStatus = $NO_MARK]]", offset)
			entityListToDelete?.each { e ->
				if (e.aspects.permission.permissionsMask > 0) {
					e.aspects.permission.inheritedPermissions = 0
					offset++
				} else {
					e.aspects.permission.permissionStatus = MARK_AS_DELETED
				}
				save(e.aspects.permission)
			}
			eol = !entityListToDelete
		}
	}

	def deletePermissionsMarkedAsDeleted(def entity) {
		def eol = false
		while (!eol) {
			def entityList = query("aspect(entity[@id=${entity.id}], 'permission')[@permission[@entityId = ${entity.id} && @permissionStatus = $MARK_AS_DELETED]]", 0).each { e ->
				delete(e.aspects.permission)
			}
			eol = !entityList
		}
	}
	
	/*
	//
	def tryUpdateSecurityProcessIdForEntity(def entity, def securityProcessId) {
		//
		Security.withTransaction { txn ->
			def security = null
			try {
				security = Security.findByEntityId(entity.id, [lock:true, lockMode:LockMode.UPGRADE_NOWAIT])
				if (!security || security?.securityProcessId) {
					entity = null
				} else {
					security.securityProcessId = securityProcessId
					security.save(flush:true, failOnError: true)
				}
			} catch (Exception e) {
				entity = null
			}
		}
		entity
	}
	*/

	//
	def tryGetSecurityForPendingEntity(def securityProcessId) {
		def security = null
		//
		Security.withTransaction { txn ->
			try {
				security = Security.findBySecurityProcessStatus(SecurityProcessStatus.PENDING.value(), [lock:true, lockMode:LockMode.UPGRADE_NOWAIT])
				if (security) {
					security.securityProcessId = securityProcessId
					security.securityProcessStatus = SecurityProcessStatus.INPROGRESS.value()
					security.save(flush:true, failOnError: true)
				}
			} catch (Exception e) {
				security = null
			}
			// TODO: If security is null, could exist an entity with a process assigned but interrupted. 
		}
		security
	}
	
	def markSecurityAsProcessed(def security) {
		security.securityProcessId = ""
		security.securityProcessStatus = SecurityProcessStatus.DONE.value()
		//save(security)
		security = security.merge()
		def result = security.save(flush:true, failOnError: true)
		result
	}

	def markSecurityForEntityAsPending(def entity) {
		def security = null
		//
		Security.withTransaction { txn ->
			// A lock from datasource is gotten. If not an exception is throw it
			security = Security.findByEntityId(entity.id, [lock:true, lockMode:LockMode.PESSIMISTIC_WRITE])
			if (!security) throw new RuntimeException("Unable to lock entityId=${entity.id} in markSecurirtyForEntityAsPending")
			security.securityProcessStatus = SecurityProcessStatus.PENDING.value()
			security.save(flush:true, failOnError: true)
		}
		security
	}

}
