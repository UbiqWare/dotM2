package org.aspect.grails.operations.users

import org.aspect.grails.annotations.AspectOperation;
import org.aspect.grails.aspects.Permission
import org.aspect.grails.aspects.Security
import org.aspect.grails.entities.UserGroup
import org.aspect.grails.exceptions.AspectException
import org.aspect.grails.operations.security.SecurityOperation;

@AspectOperation(signature = "User.create")
class CreateUserOperation extends SecurityOperation {
	
	def user
	def groups
	
	@Override
	def init() {
		// First, check user already exists
		if (!user?.username) throw new AspectException("User doesn't have username")
		def currentUser = first("user[@username='${user?.username}']")
		// Check user exists or not
		if (currentUser) throw new AspectException("User '${user.username}' already exists")
	}
	
	@Override
	def execute() {
		// First permission structure is checked and created if it doesn't exist
		user['aspects'] = user['aspects'] ?: [:] 
		user.aspects['permission'] = user.aspects['permission'] ?: new Permission(permissions:-1L, permissionsMask:-1L, owner:true)
		user.aspects['security'] = user.aspects['security'] ?: new Security(inheritsPermission:false, propagatesPermission:false)
		// User is created so its id can be used
		user = create(user)
		// Permission aspect is updated with the new user id
		user.aspects.permission.each { permission ->
			permission.permissionEntityId = permission.permissionEntityId ?: user.id
			permission.owner = (permission.permissionEntityId == permission.entityId) ? true : permission.owner  
		}
		// Finally all the information is saved
		user = save(user)
		//
		addUserToUserGroups()
		//
		user
	}
	
	// Default groups are all groups linked with this operation
	def addUserToUserGroups() {
		groups?.each { group ->
			exec(signature:"UserGroup.add", args:[user: user, group:group])
		}
	}
}
