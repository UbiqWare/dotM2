package org.aspect.grails.exceptions

class NotFoundException extends AspectException {
	NotFoundException(String message = null) {
		super(message)
	}
}
