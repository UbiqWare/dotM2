package org.aspect.grails.operations

import org.aspect.core.aql.entites.EntityType;
import org.aspect.grails.entities.AbstractOperation;
import org.aspect.grails.entities.Entity;

/**
 * Low level, very basic, and the most efficient, operation in Aspect framework. It follows Command design pattern
 * @author Jorge
 *
 */
abstract class BaseOperation extends AbstractOperation {
	
	def static void copyPropertiesFromArgs(Map args) {
		// TODO tests
		args?.each { key, value ->
			if (this.properties.hasProperty(key)) {
				this."$key" = value
			}
		}
	}

	def static adapt(def row) {
		// TODO test
		// A map will be returned
		def rows = [:]
		// Entity instantiation
		rows.put('entity', instanceEntity(row))
		// Classes instantiation inside row
		row.findAll {column -> column.key != 'type' && column.value instanceof Map && column.value.className}.each { subclass ->
			rows.put(subclass.key, instance(subclass.value))
		}
		rows
	}

	def static protected Entity instanceEntity(Map row) {
		// TODO test
		//
		def type
		if (row.type && row.type instanceof Map) {
			type = instanceEntity(row.type)
		}
		Entity entity = convertToEntityWithType(type, row)
		attach(entity)
	}

	def static Entity convertToEntityWithType(EntityType type, Map data) {
		// TODO test
		//
		if (!data) throw new IllegalArgumentException()
		Entity entityInstance = instanceEntity(type)
		copyProperties(entityInstance, data)
	}

	def static copyProperties(Object instance, Map data) {
		// TODO test
		//
		if (!instance) throw new IllegalArgumentException('instance')
		instance.properties = (data) ?: instance.properties
		instance.id = data?.id?.toString()?.toLong()
		instance.version = data?.version
		instance
	}

	/*
	def static protected static attach(def object) {
		// TODO test
		def result = object
		if (!object.isAttached()) {
			result = object.merge()
			if (!result) {
				result = sessionFactory.currentSession.get(object.class.name, object.id)
				if (result)
					result.refresh()
			}
		}
		result
	}
	*/
	
	def void checkAndGetArgs(Map args) {
		copyPropertiesFromArgs(args)
	}

}
