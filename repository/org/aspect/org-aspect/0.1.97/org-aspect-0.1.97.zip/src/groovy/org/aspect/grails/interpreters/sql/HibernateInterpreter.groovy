package org.aspect.grails.interpreters.sql
//
//



import java.sql.ResultSetMetaData
import java.util.ArrayList
import java.util.HashMap
import java.util.Map
//






import org.aspect.core.aql.SymbolTable;
import org.aspect.core.aql.interpreters.AbstractIntepreter;
import org.aspect.core.aql.interpreters.sql.SqlInterpreter;
import org.hibernate.SQLQuery
import org.hibernate.SessionFactory
import org.hibernate.transform.AliasToEntityMapResultTransformer
//

// http://mrhaki.blogspot.com.es/2014/03/grails-goodness-using-hibernate-native.html
class HibernateInterpreter extends org.aspect.core.aql.interpreters.sql.SqlInterpreter {

	SessionFactory sessionFactory

	public HibernateInterpreter(SymbolTable symbolTable) {
		super(symbolTable);
	}

	@Override
	public void setApplicationContext(Object applicationContext) {
		sessionFactory = applicationContext.getBean("sessionFactory");
	}

	@Override
	public void interpret(String query) {
		def session = sessionFactory.currentSession
		SQLQuery sqlQuery = session.createSQLQuery(query)
		resultList = new ArrayList<HashMap<String, Object>>();
		def result = sqlQuery.with {
			resultTransformer = AliasToEntityMapResultTransformer.INSTANCE
			list()
		}
		result.each { record ->
			resultList.add(transformRecord(record))
		}
	}


}
