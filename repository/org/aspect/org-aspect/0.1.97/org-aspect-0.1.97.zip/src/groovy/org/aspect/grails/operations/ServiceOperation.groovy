package org.aspect.grails.operations

import org.aspect.grails.aspects.Security
import org.aspect.grails.aspects.SecurityProcessStatus
import org.aspect.grails.entities.AbstractOperation;


class ServiceOperation extends AbstractOperation {

    def markEntityAsPending(entityId) {
        Security s = Security.findByEntityId(entityId)
        if (!s) return s
        if (s.securityProcessStatus == SecurityProcessStatus.INPROGRESS.value()) return s
        s.securityProcessStatus = SecurityProcessStatus.PENDING.value()
        s.save()
    }

}
