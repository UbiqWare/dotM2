package org.aspect.grails.operations.contents

import org.aspect.grails.annotations.AspectOperation;

@AspectOperation(signature = "content.truncateData")
class TruncateOperation  extends ContentOperation {

	@Override
	def execute() {
		truncateContent(entity)
	}

}
