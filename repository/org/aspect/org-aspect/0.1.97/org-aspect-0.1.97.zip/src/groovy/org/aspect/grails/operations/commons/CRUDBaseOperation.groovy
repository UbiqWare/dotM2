package org.aspect.grails.operations.commons

import org.aspect.grails.annotations.AspectOperation;
import org.aspect.grails.operations.CoreOperation;

class CRUDBaseOperation extends CoreOperation {
	
	def entity

}
