package org.aspect.grails.dsls

import groovy.lang.Closure;

import java.util.Map;

import org.aspect.grails.engines.AspectEngine;
import org.aspect.grails.entities.LTOperationStatus;
import org.aspect.grails.entities.LongTermOperation;
import org.aspect.grails.helpers.ClassUtils;
import org.aspect.grails.loaders.DomainClassGrailsLoader;
//
import org.aspect.core.aql.entites.EntityType;
import org.aspect.core.dsls.AbstractDSL
//


class AspectConfigDSL extends AbstractDSL {
	//
	DomainClassGrailsLoader loader
	Closure configClosure
	
	//
	AspectConfigDSL(DomainClassGrailsLoader loader, Closure configClosure = null) {
		this.loader = loader
		this.configClosure = configClosure
	}
	
	//
	def config() {
		if (!configClosure) return null
		configClosure.delegate = this
		configClosure.resolveStrategy = Closure.DELEGATE_ONLY
		configClosure()
		loader.aspectEngine
	}

	//
	def function(Map args) {
		loader.function(args?.signature, args?.body)
	}
	
	//
	def alias(Map args) {
		loader.alias(args?.name, args?.body)
	}

	//
	def target(String target) {
		loader.target(target)
	}
	
	//
	def include(String packageName) {
		loader.include(packageName)
	}

	// TODO test
	def baseTypes(Map args) {
		// args: String entity, String type
		loader.baseTypes(args?.entity, args?.type)
	}

	// TODO test
	def type(Map args) {
		// args: String name, String className, Long typeId = EntityType.DEFAULT_ENTITY_TYPE_ID
		// if name is not specified, get default from className (simpleName)
		String name = args.containsKey("name") ? args.name : ClassUtil.getSimpleName(args?.className)
		loader.type(args?.name, args?.className, args?.id)
	}
	
	// TODO
	def defaults(String target) {
		this.target(target)
		this.include("org.aspect.grails")
		this.include("org.aspect.core")
	}

}
